# CENTURION2 — versione browser mobile

Questa è l'app web statica, aggiornata per Chrome Android e Safari iPhone. Non è un APK.

## Avvio

Pubblica **tutti i file estratti** nella stessa cartella su un sito HTTPS (GitHub Pages, Netlify o hosting statico).
Apri l'indirizzo del sito direttamente nel browser dello smartphone. Scegli TRAINER, BLUE o RED.

La pagina non necessita di server di elaborazione. Le funzioni che usano API locali (/api/) restano non disponibili
su hosting statici; gli scenari e i salvataggi usano localStorage e download/importazione.
Le mappe di base online, le risorse 3D remote e il meteo remoto richiedono rete.

## Ottimizzazioni smartphone (15 novembre 2026)

- Barra comandi compatta e fasi scorribili orizzontalmente; niente scorrimento orizzontale dell'intera pagina.
- Mappa ampliata; livelli nascosti fino al tocco di "Livelli".
- Pannelli missione e log a scomparsa con pulsanti Chiudi e sfondo di chiusura.
- Schermata iniziale scorrevole anche sugli schermi bassi e orientamento orizzontale.
- Altezza dinamica (dvh) e rispetto delle aree di sicurezza dei telefoni con notch.
- Campi con caratteri abbastanza grandi per evitare zoom automatico su iOS, tabelle a scorrimento, modali adattive.
- Versione cache PWA aggiornata per ricaricare CSS/JS nuovi.

## Verifica

Verificate in Chromium con emulazione touch le larghezze 320, 360, 390 e 844 pixel: inizializzazione,
selezione ruolo, livelli mappa, pannelli, fasi, avanzamento orologio, play/pausa e assenza di scorrimento orizzontale.
Non è stato eseguito un test su dispositivo fisico iOS/Android né su un URL HTTPS pubblicato.
