/* CENTURION – service worker: app installabile e uso offline.
   - "shell" dell'app (html, css, js, librerie, icone): network-first con copia in cache (così gli aggiornamenti arrivano subito, ma offline funziona)
   - tile 3D (/tile/...), tile mappe esterne, clip audio, modelli: cache-first (dopo la prima visita restano sul dispositivo)
   - /api/: solo rete (salvataggi, meteo)
*/
const VERSIONE = "centurion-v7";
const SHELL = ["./", "index.html", "css/style.css", "vendor/leaflet.css", "vendor/leaflet.js", "vendor/xlsx.full.min.js", "vendor/three.min.js",
  "js/modelli3d.js", "js/vista3d.js", "js/mondo3d.js", "js/highlights.js", "js/meteo.js", "js/audio.js", "js/scenario_default.js", "js/geo.js", "js/physics.js",
  "js/engine.js", "js/map.js", "js/dataio.js", "js/ui.js", "js/demo.js", "js/rete.js", "js/volo.js", "js/app.js", "manifest.json", "audio/manifest.json", "modelli/manifest.json", "assets/reali/clip.json",
  "assets/icon-192.png", "assets/icon-512.png", "assets/apple-touch-icon.png", "assets/icons/f15.png", "assets/icons/f16.png", "assets/icons/f16b.png", "assets/icons/f22.png",
  "assets/icons/typhoon.png", "assets/icons/su35.png", "assets/icons/su57.png", "assets/icons/kc30.png", "assets/icons/su_black.png"];
const CACHE_DATI = VERSIONE + "-dati";

self.addEventListener("install", e => {
  e.waitUntil(caches.open(VERSIONE).then(c => Promise.allSettled(SHELL.map(u => c.add(u).catch(() => null)))).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSIONE && k !== CACHE_DATI).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
const isDati = url => /\/tile\/|\/audio\/|\/modelli\/|\/assets\/|arcgisonline|elevation-tiles|openstreetmap|opentopomap|cartocdn/.test(url);
self.addEventListener("fetch", e => {
  const req = e.request; if (req.method !== "GET") return; const url = req.url;
  if (/\/api\//.test(url)) return;                        // API: solo rete
  if (isDati(url)) {                                       // dati pesanti: cache-first
    // una risposta "opaca" (salvata da una richiesta senza CORS, es. la mappa 2D) non va mai data a una richiesta CORS (texture/quote del 3D):
    // il 3D non potrebbe leggerla e il terreno resterebbe piatto. Si mettono in cache solo risposte leggibili.
    e.respondWith(caches.open(CACHE_DATI).then(c => c.match(req).then(hit => {
      if (hit && !(hit.type === "opaque" && req.mode === "cors")) return hit;
      return fetch(req).then(r => { if (r && r.ok && r.type !== "opaque") c.put(req, r.clone()); return r; }).catch(() => hit);
    })));
    return;
  }
  // shell: rete, con copia in cache; offline → cache
  e.respondWith(fetch(req).then(r => { if (r && r.ok && new URL(url).origin === self.location.origin) caches.open(VERSIONE).then(c => c.put(req, r.clone())); return r; })
    .catch(() => caches.match(req).then(hit => hit || (req.mode === "navigate" ? caches.match("index.html") : undefined))));
});
