# Modelli 3D reali (glTF) per il simulatore

Metti qui i file `.glb` / `.gltf` dei velivoli e dichiarali in `manifest.json`: la vista 3D della missione e la cinematica
dell'attacco li usano al posto dei modelli procedurali (che restano come riserva per i tipi non dichiarati).

Serve anche `app/vendor/GLTFLoader.js` (loader ufficiale di Three.js r150, file `examples/js/loaders/GLTFLoader.js`).

## manifest.json
```json
{
  "F16":   { "file": "f16.glb", "rot": [0, 180, 0], "lunghezza_m": 15.0, "ugelli": [[0, -0.05, -7.3]], "autore": "…", "licenza": "CC-BY 4.0", "url": "…" },
  "F15":   { "file": "f15e.glb", "rot": [0, 0, 0], "lunghezza_m": 19.4, "ugelli": [[-0.75, -0.15, -9.3], [0.75, -0.15, -9.3]] },
  "KC30":  { "file": "a330.glb", "lunghezza_m": 59.0 }
}
```
- chiavi: `F15 F16 F2000 F22 EA18 SU35 SU57 KC30 E7` (gli id dei velivoli dell'Excel);
- `rot` (gradi, assi X Y Z): ruota il modello finché il **muso punta verso +Z** e l'**alto è +Y** (prova 180 su Y se vola all'indietro, −90 su X se è "in piedi");
- `lunghezza_m`: il modello viene scalato a questa lunghezza reale (in alternativa `scala`);
- `offset` [x, y, z] in metri per centrare; `ugelli` posizioni in metri per la fiamma del postbruciatore;
- il colore della squadra RED viene applicato come tinta sui materiali (stella/coccarda del modello restano quelle originali).

## Dove trovare modelli con licenza libera
- Sketchfab, filtro "Downloadable" + licenza CC-BY (serve un account gratuito; scarica in formato glTF), ad esempio
  F-16 di iedalton (CC-BY, 4k triangoli), F-16C di Carlos.Maciel (CC-BY), Su-35 di Chenzoss (CC-BY), e la collezione "Fighter Jets" di bohmerang (attenzione: alcuni sono CC-BY-NC, solo uso non commerciale).
- Modelli con licenza CC-BY richiedono di citare l'autore: compila `autore`, `licenza`, `url` nel manifest e riportali nei crediti del workshop.
- Peso consigliato: sotto i 60k triangoli e 15 MB per modello (in scena ci possono essere 40 velivoli).
