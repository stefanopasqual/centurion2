/* CENTURION2 · Pilota 3D
   Modello del pilota da caccia (assets/pilota.glb, tuta di volo, casco, imbracatura) caricato una volta sola e
   usato al posto delle figure semplificate: il pilota sul seggiolino eiettabile e sotto il paracadute del volo
   libero, l'equipaggio di DUDE 44 nella missione dei monti Zagros. Il modello è statico (senza scheletro):
   compare nelle pose in piedi o appese; nelle pose rannicchiate resta la figura articolata originale.
   Nessun file del simulatore viene modificato: il modello si aggiunge ai gruppi esistenti e ne nasconde le parti. */
window.PILOTA3D = (() => {
  const URL = "assets/pilota.glb", ALTEZZA = 1.78;
  let base = null, prom = null;
  function carica() {
    if (prom) return prom;
    prom = new Promise(ok => {
      const leggi = () => {
        try {
          new THREE.GLTFLoader().load(URL, g => {
            const s = g.scene, b = new THREE.Box3().setFromObject(s), dim = b.getSize(new THREE.Vector3());
            s.scale.multiplyScalar(ALTEZZA / Math.max(0.01, dim.y)); s.updateMatrixWorld(true);
            const b2 = new THREE.Box3().setFromObject(s), c = b2.getCenter(new THREE.Vector3());
            s.position.x -= c.x; s.position.z -= c.z; s.position.y -= b2.min.y;
            s.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = false; o.raycast = () => {}; } });
            const w = new THREE.Group(); w.name = "PILOTA3D"; w.add(s); base = w; ok(w);
          }, undefined, () => ok(null));
        } catch (e) { ok(null); }
      };
      if (typeof THREE === "undefined") { ok(null); return; }
      if (THREE.GLTFLoader) leggi();
      else { const sc = document.createElement("script"); sc.src = "vendor/GLTFLoader.js"; sc.onload = leggi; sc.onerror = () => ok(null); document.head.appendChild(sc); }
    });
    return prom;
  }
  const nuovo = () => base ? base.clone(true) : null;
  // aggiunge il pilota 3D a un gruppo esistente e nasconde le parti originali (restano disponibili per le pose rannicchiate)
  function veste(g, opz) {
    if (!g || g.userData.p3d) return !!(g && g.userData.p3d);
    const p = nuovo(); if (!p) return false; opz = opz || {};
    const orig = g.children.slice(); orig.forEach(o => { o.visible = false; });
    if (opz.y) p.position.y = opz.y; if (opz.yaw) p.rotation.y = opz.yaw; g.add(p);
    g.userData.p3d = p; g.userData.p3dOrig = orig; return true;
  }
  // mostra il modello 3D o la figura articolata a seconda della posa
  function posa(g, nome) {
    const p = g && g.userData.p3d; if (!p) return;
    const statico = !/rannicchiato|seduto|ginocchio|cura/.test(nome || "");
    p.visible = statico; g.userData.p3dOrig.forEach(o => { o.visible = !statico; });
  }
  // volo libero: il pilota sul seggiolino e sotto il paracadute dopo l'eiezione
  function sorveglia() {
    try { const S = window.VOLO && VOLO.stato, E = S && S.eiez; if (E && E.pil && !E.pil.userData.p3d) veste(E.pil); } catch (e) {}
    requestAnimationFrame(sorveglia);
  }
  carica().then(m => { if (m) sorveglia(); });
  return { carica, nuovo, veste, posa, get pronto() { return !!base; } };
})();
