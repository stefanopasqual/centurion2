/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA · 3 – LUCE, OMBRE, TONE MAPPING, BLOOM
   - Pipeline HDR: la scena si disegna in un render target a mezza precisione (con MSAA su WebGL2),
     poi bloom a cascata (4 livelli, filtro "dual" a 13 campioni), tone mapping ACES con l'esposizione
     del Free Flight (anche quella del visore NVG), lieve curva di contrasto, vignettatura e dithering
     contro le bande nel cielo. Il sole, i riflessi e le fiamme "sbordano" come in una ripresa vera.
   - Ombre morbide del sole sull'aereo del giocatore: mappa d'ombra che segue l'aereo (riquadro di 90 m),
     PCF morbido; l'aereo proietta ombra su sé stesso e sulla pista o sul terreno quando vola basso.
   - Qualità: MEDIA = bloom + ombre 1024 px (MSAA solo su desktop); ALTA = MSAA 4× + ombre 2048 px.
     Non attivo di notte (il cielo notturno e il visore di volo.js restano quelli originali) né in BASSA.
   Nessuna riga di volo.js è modificata: il render a schermo della scena principale passa da qui.
   ===================================================================== */
window.CENTURION_LUCE = window.CENTURION_LUCE || (() => {
  "use strict";
  const T = window.THREE, G = window.CENTURION_GFX; if (!T || !G) return null;
  const P = { soglia: 1.6, ginocchio: 1.2, forza: 0.085, vignetta: 0.16, contrasto: 1.0, saturazione: 1.04 };

  /* ---------- quad a tutto schermo ---------- */
  const camQ = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1), scenaQ = new T.Scene();
  const quad = new T.Mesh(new T.PlaneGeometry(2, 2), null); quad.frustumCulled = false; scenaQ.add(quad);
  const VS = "varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }";
  function passo(r, mat, dest) { quad.material = mat; r.setRenderTarget(dest); r.render(scenaQ, camQ); }
  const matBright = new T.ShaderMaterial({ uniforms: { tSrc: { value: null }, uSoglia: { value: P.soglia }, uGin: { value: P.ginocchio }, uTexel: { value: new T.Vector2() } }, vertexShader: VS, depthTest: false, depthWrite: false, toneMapped: false,
    fragmentShader: `uniform sampler2D tSrc; uniform float uSoglia, uGin; uniform vec2 uTexel; varying vec2 vUv;
      vec3 pr(vec2 o){ vec3 c = min(texture2D(tSrc, vUv + o * uTexel).rgb, vec3(60.0)); float l = max(c.r, max(c.g, c.b)); float s = clamp(l - uSoglia + uGin, 0.0, 2.0 * uGin); s = s * s / (4.0 * uGin + 1e-4); return c * max(s, l - uSoglia) / max(l, 1e-4); }
      void main(){ vec3 c = pr(vec2(-1.0,-1.0)) + pr(vec2(1.0,-1.0)) + pr(vec2(-1.0,1.0)) + pr(vec2(1.0,1.0)); gl_FragColor = vec4(c * 0.25, 1.0); }` });
  const matGiu = new T.ShaderMaterial({ uniforms: { tSrc: { value: null }, uTexel: { value: new T.Vector2() } }, vertexShader: VS, depthTest: false, depthWrite: false, toneMapped: false,
    fragmentShader: `uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
      void main(){ vec2 t = uTexel; vec3 c = texture2D(tSrc, vUv).rgb * 4.0;
        c += texture2D(tSrc, vUv + vec2(-t.x, -t.y)).rgb + texture2D(tSrc, vUv + vec2(t.x, -t.y)).rgb + texture2D(tSrc, vUv + vec2(-t.x, t.y)).rgb + texture2D(tSrc, vUv + vec2(t.x, t.y)).rgb;
        gl_FragColor = vec4(c / 8.0, 1.0); }` });
  const matSu = new T.ShaderMaterial({ uniforms: { tSrc: { value: null }, uTexel: { value: new T.Vector2() } }, vertexShader: VS, depthTest: false, depthWrite: false, toneMapped: false, blending: T.AdditiveBlending, transparent: true,
    fragmentShader: `uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
      void main(){ vec2 t = uTexel; vec3 c = vec3(0.0);
        c += texture2D(tSrc, vUv + vec2(-2.0*t.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(2.0*t.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(0.0, -2.0*t.y)).rgb + texture2D(tSrc, vUv + vec2(0.0, 2.0*t.y)).rgb;
        c += (texture2D(tSrc, vUv + vec2(-t.x, t.y)).rgb + texture2D(tSrc, vUv + vec2(t.x, t.y)).rgb + texture2D(tSrc, vUv + vec2(-t.x, -t.y)).rgb + texture2D(tSrc, vUv + vec2(t.x, -t.y)).rgb) * 2.0;
        gl_FragColor = vec4(c / 12.0, 1.0); }` });
  const matFinale = new T.ShaderMaterial({ uniforms: { tScena: { value: null }, tBloom: { value: null }, uForza: { value: P.forza }, uVign: { value: P.vignetta }, uContr: { value: P.contrasto }, uSat: { value: P.saturazione }, uAsp: { value: 1 } }, vertexShader: VS, depthTest: false, depthWrite: false,
    fragmentShader: `uniform sampler2D tScena, tBloom; uniform float uForza, uVign, uContr, uSat, uAsp; varying vec2 vUv;
      float rnd(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
      void main(){
        vec3 c = texture2D(tScena, vUv).rgb + texture2D(tBloom, vUv).rgb * uForza;
        // grading leggero in lineare: saturazione e contrasto attorno al grigio medio
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722)); c = max(vec3(0.0), mix(vec3(l), c, uSat));
        c = 0.18 * pow(c / 0.18 + 1e-5, vec3(uContr));
        vec2 q = (vUv - 0.5) * vec2(uAsp, 1.0); c *= 1.0 - uVign * smoothstep(0.35, 1.05, length(q) * 1.25);
        gl_FragColor = vec4(c, 1.0);
        #include <tonemapping_fragment>
        #include <encodings_fragment>
        gl_FragColor.rgb += (rnd(gl_FragCoord.xy) - 0.5) / 255.0;
      }` });

  /* ---------- render target ---------- */
  const st = { rt: null, bloom: [], w: 0, h: 0, campioni: -1, ombre: null, cambiati: new Set(), tScan: 0 };
  function libera() { if (st.rt) st.rt.dispose(); st.bloom.forEach(b => b.dispose()); st.rt = null; st.bloom = []; st.w = st.h = 0; }
  function prepara(r, livello) {
    const v = r.getDrawingBufferSize(new T.Vector2()); const w = Math.max(2, v.x | 0), h = Math.max(2, v.y | 0);
    const touch = matchMedia("(pointer:coarse)").matches;
    const campioni = r.capabilities.isWebGL2 ? (livello >= 3 ? 4 : (touch ? 0 : 4)) : 0;
    if (st.rt && st.w === w && st.h === h && st.campioni === campioni) return;
    libera(); st.w = w; st.h = h; st.campioni = campioni;
    const hf = r.capabilities.isWebGL2 && (r.extensions.has("EXT_color_buffer_float") || r.extensions.has("EXT_color_buffer_half_float"));
    const tipo = hf ? T.HalfFloatType : T.UnsignedByteType;
    st.rt = new T.WebGLRenderTarget(w, h, { type: tipo, samples: campioni, depthBuffer: true, stencilBuffer: false, minFilter: T.LinearFilter, magFilter: T.LinearFilter });
    let bw = w, bh = h; for (let i = 0; i < 5; i++) { bw = Math.max(2, bw >> 1); bh = Math.max(2, bh >> 1); st.bloom.push(new T.WebGLRenderTarget(bw, bh, { type: tipo, depthBuffer: false, stencilBuffer: false, minFilter: T.LinearFilter, magFilter: T.LinearFilter })); }
    st.hdr = hf;
  }

  /* ---------- ombre dell'aereo ---------- */
  function sole(S) { let l = null; (S.cieloObj || []).forEach(o => { if (o.isDirectionalLight && !l) l = o; }); return l; }
  function marca(o, cast, recv) { if (!st.cambiati.has(o)) { st.cambiati.add(o); o.userData.__gfxOmbra = [o.castShadow, o.receiveShadow]; } o.castShadow = cast; o.receiveShadow = recv; }
  function aggiornaOmbre(ctx) {
    const S = ctx.S, r = ctx.renderer, l = sole(S), liv = ctx.livello; if (!l) return;
    if (!st.ombre) {
      st.ombre = { luce: l, prima: { cast: l.castShadow, map: r.shadowMap.enabled, tipo: r.shadowMap.type, pos: l.position.clone(), target: l.target } };
      r.shadowMap.enabled = true; r.shadowMap.type = T.PCFSoftShadowMap;
      l.castShadow = true; const dim = liv >= 3 ? 2048 : 1024; l.shadow.mapSize.set(dim, dim); if (l.shadow.map) { l.shadow.map.dispose(); l.shadow.map = null; }
      Object.assign(l.shadow.camera, { left: -45, right: 45, top: 45, bottom: -45, near: 10, far: 2000 }); l.shadow.camera.updateProjectionMatrix();
      l.shadow.bias = -0.0004; l.shadow.normalBias = 0.03; l.shadow.radius = 3;
      l.target = new T.Object3D(); ctx.scene.add(l.target);
    }
    const P = S.pl, d = ctx.sunDir || S.sunDir; if (!P || !d) return;
    // la luce si sposta con l'aereo (stessa direzione: l'illuminazione non cambia)
    l.target.position.copy(P.pos); l.position.copy(P.pos).addScaledVector(d, 1000); l.target.updateMatrixWorld();
    l.castShadow = d.y > 0.01;
    // ogni secondo: aereo del giocatore proietta e riceve; terreno e pista ricevono
    const now = performance.now(); if (now - st.tScan < 1000) return; st.tScan = now;
    if (P.obj) P.obj.traverse(o => { if (o.isMesh && !o.isInstancedMesh && !(o.material && o.material.transparent)) marca(o, true, true); });
    const vicino = (o) => { const p = o.getWorldPosition(new T.Vector3()); return Math.hypot(p.x - P.pos.x, p.z - P.pos.z) < 30000; };
    if (S.root) S.root.traverse(o => { if (o.isMesh && !o.castShadow && o.geometry && o.geometry.type === "PlaneGeometry" && !st.cambiati.has(o) && vicino(o)) marca(o, false, true); });
  }
  function togliOmbre(ctx) {
    st.cambiati.forEach(o => { const v = o.userData.__gfxOmbra; if (v) { o.castShadow = v[0]; o.receiveShadow = v[1]; delete o.userData.__gfxOmbra; } }); st.cambiati.clear();
    if (st.ombre) { const o = st.ombre, l = o.luce, r = ctx.renderer;
      if (l.target && l.target !== o.prima.target) { if (l.target.parent) l.target.parent.remove(l.target); l.target = o.prima.target; }
      l.castShadow = o.prima.cast; l.position.copy(o.prima.pos); if (l.shadow.map) { l.shadow.map.dispose(); l.shadow.map = null; }
      if (r) { r.shadowMap.enabled = o.prima.map; r.shadowMap.type = o.prima.tipo; }
      st.ombre = null; }
  }

  const mod = G.registra({
    nome: "luce", min: 2, ordine: 20,
    monta(ctx) { st.tScan = 0; },
    smonta(ctx) { togliOmbre(ctx); libera(); },
    prima(ctx) { aggiornaOmbre(ctx); },
    // render a schermo: scena in HDR → bloom → tone mapping
    rendi(ctx, orig) {
      const r = ctx.renderer; prepara(r, ctx.livello); if (!st.hdr) return false;     // senza mezza precisione: pipeline originale
      // in three r150 il tone mapping dei materiali vale anche sui render target: qui la scena deve restare lineare (HDR),
      // il tone mapping si fa una volta sola nel passaggio finale
      const tm = r.toneMapping; r.toneMapping = T.NoToneMapping;
      try { r.setRenderTarget(st.rt); orig(ctx.scene, ctx.camera); } finally { r.toneMapping = tm; }
      const b = st.bloom;
      matBright.uniforms.tSrc.value = st.rt.texture; matBright.uniforms.uTexel.value.set(0.5 / st.w, 0.5 / st.h); matBright.uniforms.uSoglia.value = P.soglia; matBright.uniforms.uGin.value = P.ginocchio;
      passo(r, matBright, b[0]);
      for (let i = 1; i < b.length; i++) { matGiu.uniforms.tSrc.value = b[i - 1].texture; matGiu.uniforms.uTexel.value.set(1 / b[i - 1].width, 1 / b[i - 1].height); passo(r, matGiu, b[i]); }
      const ac = r.autoClear; r.autoClear = false;
      for (let i = b.length - 1; i > 0; i--) { matSu.uniforms.tSrc.value = b[i].texture; matSu.uniforms.uTexel.value.set(1 / b[i].width, 1 / b[i].height); passo(r, matSu, b[i - 1]); }
      r.autoClear = ac;
      const u = matFinale.uniforms; u.tScena.value = st.rt.texture; u.tBloom.value = b[0].texture; u.uForza.value = P.forza; u.uVign.value = P.vignetta; u.uContr.value = P.contrasto; u.uSat.value = P.saturazione; u.uAsp.value = st.w / st.h;
      passo(r, matFinale, null);
      return true;
    }
  });
  return { P, mod, get rt() { return st.rt; } };
})();
