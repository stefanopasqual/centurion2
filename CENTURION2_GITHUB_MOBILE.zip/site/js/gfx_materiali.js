/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA · 4 – MATERIALI DI JET ED ELICOTTERI
   - Riflessi d'ambiente veri: una mappa d'ambiente (PMREM, 128 px) costruita dal cielo fisico del
     modulo atmosfera (stessa tabella del cielo) e da un suolo del colore medio del terreno illuminato.
     Si rifà solo quando cambiano sole, quota o meteo (al massimo ogni 1,5 s). I materiali PBR dei GLB
     e dei modelli procedurali (MeshStandard/Physical) la usano: il metallo non è più nero, la vernice
     prende il cielo sul dorso e il terreno sul ventre, il tettuccio riflette l'orizzonte.
   - Tettuccio: vetro con riflesso di Fresnel più deciso (clearcoat sui MeshPhysical trasparenti).
   - Luci di navigazione dei modelli procedurali (sprite senza texture, che apparivano come quadratini):
     ricevono un alone rotondo.
   - Solo velivoli (giocatore, avversari, elicotteri, missili): terreno ed edifici restano come sono.
     MEDIA e ALTA; spento di notte e con qualità BASSA/SPENTA (si torna ai materiali originali).
   ===================================================================== */
window.CENTURION_MATERIALI = window.CENTURION_MATERIALI || (() => {
  "use strict";
  const T = window.THREE, G = window.CENTURION_GFX; if (!T || !G) return null;
  const P = { intensita: 0.7, metallo: 1.3, vetro: 1.8, saturazione: 0.7 };

  /* ---------- scena d'ambiente: cielo dalla LUT + suolo ---------- */
  let envScena = null, cubo = null, cuboCam = null, pmrem = null, envRT = null, matCielo = null, matSuolo = null, alone = null;
  function creaAmbiente(r) {
    envScena = new T.Scene();
    matCielo = new T.ShaderMaterial({
      uniforms: { uLut: { value: null }, uSole: { value: new T.Vector3(0, 1, 0) }, uEsp: { value: 1 }, uScala: { value: 1 }, uSuolo: { value: new T.Vector3(0.1, 0.1, 0.1) }, uSat: { value: P.saturazione } },
      vertexShader: "varying vec3 vD; void main(){ vD = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform sampler2D uLut; uniform vec3 uSole, uSuolo; uniform float uEsp, uScala, uSat; varying vec3 vD;
        void main(){ vec3 d = normalize(vD); float el = asin(clamp(d.y, -1.0, 1.0));
          vec2 dh = d.xz, sh = uSole.xz; float ld = length(dh), ls = length(sh); float ca = (ld > 1e-5 && ls > 1e-5) ? dot(dh / ld, sh / ls) : 1.0;
          float u = acos(clamp(ca, -1.0, 1.0)) / 3.14159265, v = 0.5 + 0.5 * sqrt(max(el, 0.0) / 1.5707963);
          vec3 cielo = texture2D(uLut, vec2(u, max(v, 0.5))).rgb / uScala * uEsp;
          // sotto l'orizzonte: terreno illuminato, sfumato nella foschia vicino all'orizzonte
          vec3 oriz = texture2D(uLut, vec2(u, 0.5)).rgb / uScala * uEsp;
          vec3 c = d.y >= 0.0 ? cielo : mix(uSuolo, oriz, exp(-(-d.y) * 14.0) * 0.85);
          // un po' meno saturo: la vernice grigia non deve diventare azzurra
          c = mix(vec3(dot(c, vec3(0.2126, 0.7152, 0.0722))), c, uSat); gl_FragColor = vec4(c, 1.0); }`,
      side: T.BackSide, depthWrite: false, depthTest: false, toneMapped: false
    });
    envScena.add(new T.Mesh(new T.SphereGeometry(10, 48, 24), matCielo));
    const hf = r.capabilities.isWebGL2 && (r.extensions.has("EXT_color_buffer_float") || r.extensions.has("EXT_color_buffer_half_float"));
    cubo = new T.WebGLCubeRenderTarget(64, { type: hf ? T.HalfFloatType : T.UnsignedByteType, generateMipmaps: false });
    cuboCam = new T.CubeCamera(0.1, 100, cubo); envScena.add(cuboCam);
    pmrem = new T.PMREMGenerator(r);
  }
  function aggiornaAmbiente(ctx) {
    const r = ctx.renderer, atmo = window.CENTURION_ATMO, col = atmo && atmo.colori;
    const lutMat = ctx.S.cupola && ctx.S.cupola.material && ctx.S.cupola.material.uniforms && ctx.S.cupola.material.uniforms.uLut;
    if (!lutMat || !col) return false;
    const u = matCielo.uniforms; u.uLut.value = lutMat.value; u.uSole.value.copy(ctx.sunDir); u.uEsp.value = ctx.esposizione || 1.3; u.uScala.value = ctx.S.cupola.material.uniforms.uScala.value;
    // suolo: albedo medio di prati, rocce e boschi (~0,12) sotto sole + cielo
    const si = (ctx.soleInt || 1.4) * Math.max(0, ctx.sunDir.y), sc = ctx.soleCol || [1, 1, 1], alb = [0.11, 0.12, 0.09];
    u.uSuolo.value.set(alb[0] * (sc[0] * si + 0.6), alb[1] * (sc[1] * si + 0.65), alb[2] * (sc[2] * si + 0.75));
    const prec = r.getRenderTarget(), tm = r.toneMapping; r.toneMapping = T.NoToneMapping;
    cuboCam.update(r, envScena);
    const nuovo = pmrem.fromCubemap(cubo.texture);
    r.toneMapping = tm; r.setRenderTarget(prec);
    if (envRT) envRT.dispose(); envRT = nuovo; return true;
  }

  /* ---------- applicazione ai velivoli ---------- */
  const st = { orig: new Map(), sprite: new Map(), tScan: 0, tEnv: 0, chiave: "" };
  function velivoli(ctx) {
    const S = ctx.S, out = [];
    if (S.pl && S.pl.obj) out.push(S.pl.obj);
    (S.nemici || []).forEach(e => e.obj && out.push(e.obj));
    (S.missili || []).forEach(m => m.mesh && out.push(m.mesh));
    // elicotteri e velivoli dei filmati: gruppi figli della scena con un modello caricato
    ctx.scene.children.forEach(o => { if (o !== S.root && o.isGroup && o.userData && (o.userData.mdl || o.userData.rotore || /heli|uh60|elic/i.test(o.name || "")) && !out.includes(o)) out.push(o); });
    return out;
  }
  function applica(ctx) {
    if (!envRT) return;
    const env = envRT.texture;
    velivoli(ctx).forEach(root => root.traverse(o => {
      if (o.isSprite && o.material && !o.material.map && o.material.blending === T.AdditiveBlending) {
        if (!alone && typeof VISTA3D !== "undefined" && VISTA3D.puffTexture) alone = VISTA3D.puffTexture(true);
        if (alone && !st.sprite.has(o.material)) { st.sprite.set(o.material, null); o.material.map = alone; o.material.needsUpdate = true; }
        return;
      }
      if (!o.isMesh) return;
      [].concat(o.material).forEach(m => {
        if (!m || !(m.isMeshStandardMaterial || m.isMeshPhysicalMaterial)) return;
        if (!st.orig.has(m)) {
          st.orig.set(m, { env: m.envMap, ei: m.envMapIntensity, cc: m.clearcoat, ccr: m.clearcoatRoughness });
          const vetro = m.transparent && m.opacity < 0.8;
          m.envMapIntensity = P.intensita * (vetro ? P.vetro : 1) * (m.metalness > 0.5 ? P.metallo : 1);
          if (m.isMeshPhysicalMaterial && vetro) { m.clearcoat = 1; m.clearcoatRoughness = 0.04; }
        }
        if (m.envMap !== env) { m.envMap = env; m.needsUpdate = true; }
      });
    }));
  }
  function ripristina() {
    st.orig.forEach((o, m) => { m.envMap = o.env; m.envMapIntensity = o.ei; if (m.isMeshPhysicalMaterial) { m.clearcoat = o.cc; m.clearcoatRoughness = o.ccr; } m.needsUpdate = true; });
    st.orig.clear();
    st.sprite.forEach((v, m) => { m.map = v; m.needsUpdate = true; }); st.sprite.clear();
  }

  const mod = G.registra({
    nome: "materiali", min: 2, ordine: 30,
    monta(ctx) { if (!envScena) creaAmbiente(ctx.renderer); st.tScan = 0; st.tEnv = 0; st.chiave = ""; },
    smonta(ctx) { ripristina(); if (envRT) { envRT.dispose(); envRT = null; } },
    prima(ctx) {
      const now = performance.now(), d = ctx.sunDir; if (!d) return;
      const chiave = [Math.round(d.x * 200), Math.round(d.y * 400), Math.round(d.z * 200), Math.round(ctx.camera.position.y / 400), Math.round((ctx.esposizione || 0) * 20), Math.round((G.ctx.copertura || 0) * 10)].join(",");
      if ((chiave !== st.chiave && now - st.tEnv > 1500) || !envRT) { if (aggiornaAmbiente(ctx)) { st.chiave = chiave; st.tEnv = now; st.tScan = 0; } }
      if (now - st.tScan > 1000) { st.tScan = now; applica(ctx); }
    }
  });
  return { P, mod, get env() { return envRT && envRT.texture; } };
})();
