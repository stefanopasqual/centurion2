/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA · 1 – CIELO E ATMOSFERA FISICI
   - Cielo a diffusione singola Rayleigh (aria) + Mie (foschia) + assorbimento dell'ozono, calcolato
     in una piccola tabella (sky-view LUT, 192×108) e letto dalla cupola: costa poco anche sui telefoni.
     Il sole ha disco con oscuramento al bordo e colore dato dall'aria che attraversa: tramonto arancio,
     ombra della Terra e cintura di Venere vengono dal modello, non da colori scelti a mano.
   - Prospettiva aerea: la nebbia lineare di three.js diventa estinzione per canale (il blu si perde prima)
     con densità che cala con la quota (Rayleigh 8 km, Mie ~1,2 km) più la luce diffusa verso l'osservatore.
     Montagne lontane azzurrate, valli velate, orizzonte che si fonde col cielo.
   - Sole, luce del cielo e ora del giorno: la luce del sole prende il colore trasmesso, quella emisferica
     il colore medio del cielo. L'ora si sceglie nel pannello GFX (default 14:30, come volo.js).
   Si spegne da sola di notte (resta il cielo notturno di volo.js) e con la qualità SPENTA.
   Nessuna riga di volo.js è modificata: la nebbia passa da un ramo in più dei pezzi di shader di three.js,
   attivo solo durante il rendering del Free Flight (uniforme atmoM a zero altrove = comportamento originale).
   ===================================================================== */
window.CENTURION_ATMO = window.CENTURION_ATMO || (() => {
  "use strict";
  const T = window.THREE, G = window.CENTURION_GFX; if (!T || !G) return null;

  /* ---------- costanti fisiche (Bruneton/Hillaire, unità SI) ---------- */
  const RG = 6360e3, RA = 6460e3, HR = 8000, HO = 25000, WO = 15000;
  const BR = [5.802e-6, 13.558e-6, 33.1e-6], BO = [0.650e-6, 1.881e-6, 0.085e-6];
  const SOLE = 20;                       // irradianza solare (scala arbitraria)
  const P = { mie: 2.2e-5, hm: 1200, g: 0.80, esp: 1.3, coperto: 0 };   // foschia e taratura, cambiano col meteo

  /* ---------- uniforme condivisa: 16 numeri letti dal ramo "atmosfera" della nebbia ---------- */
  // [0] acceso, [1-3] sole | [4-6] luce d'orizzonte verso il sole, [7] Mie al livello del mare
  // [8-10] luce d'orizzonte a 90°, [11] quota di scala Mie | [12-14] luce d'orizzonte opposta al sole, [15] riserva
  const M = new Float32Array(16);
  function aggiungiUniforme(u) { if (u && u.fogColor && !u.atmoM) u.atmoM = { value: M }; }
  aggiungiUniforme(T.UniformsLib.fog); Object.keys(T.ShaderLib).forEach(k => aggiungiUniforme(T.ShaderLib[k].uniforms));
  // (UniformsUtils.clone non copia i Float32Array: tutti i materiali vedono lo stesso array)

  const C = T.ShaderChunk;
  C.fog_pars_vertex = C.fog_pars_vertex.replace("varying float vFogDepth;", "varying float vFogDepth;\n\tvarying vec3 vAtmoRay;");
  // raggio camera→vertice in orientamento mondo: R^T · mvPosition (trasposta della rotazione di vista, vale anche in WebGL1)
  C.fog_vertex = C.fog_vertex.replace("vFogDepth = - mvPosition.z;", "vFogDepth = - mvPosition.z;\n\tvAtmoRay = vec3( dot( viewMatrix[0].xyz, mvPosition.xyz ), dot( viewMatrix[1].xyz, mvPosition.xyz ), dot( viewMatrix[2].xyz, mvPosition.xyz ) );");
  C.fog_pars_fragment = C.fog_pars_fragment.replace("varying float vFogDepth;", "varying float vFogDepth;\n\tvarying vec3 vAtmoRay;\n\tuniform mat4 atmoM;\n\tfloat atmoOd( float h0, float h1, float H ) { float x = ( h1 - h0 ) / H; float a = exp( - h0 / H ); return abs( x ) < 1e-3 ? a * ( 1.0 - 0.5 * x ) : a * ( 1.0 - exp( - x ) ) / x; }");
  C.fog_fragment = C.fog_fragment.replace("#ifdef USE_FOG", `#ifdef USE_FOG
	if ( atmoM[0][0] > 0.5 ) {
		float aD = length( vAtmoRay );
		float h0 = max( cameraPosition.y, 0.0 ), h1 = max( cameraPosition.y + vAtmoRay.y, 0.0 );
		vec3 tau = vec3( 5.802e-6, 13.558e-6, 33.1e-6 ) * aD * atmoOd( h0, h1, 8000.0 ) + vec3( atmoM[1][3] * aD * atmoOd( h0, h1, atmoM[2][3] ) );
		vec3 aT = exp( - tau );
		vec2 aH = normalize( vAtmoRay.xz + vec2( 1e-4, 0.0 ) ), aS = normalize( atmoM[0].yw + vec2( 1e-4, 0.0 ) );
		float aC = dot( aH, aS );
		vec3 aL = aC >= 0.0 ? mix( atmoM[2].xyz, atmoM[1].xyz, aC ) : mix( atmoM[2].xyz, atmoM[3].xyz, - aC );
		float aMu = max( dot( vAtmoRay / max( aD, 1e-3 ), atmoM[0].yzw ), 0.0 );
		aL *= 1.0 + 2.2 * pow( aMu, 12.0 ) + 0.45 * aMu * aMu * aMu;
		#ifdef TONE_MAPPING
			aL = toneMapping( aL );
		#endif
		aL = linearToOutputTexel( vec4( aL, 1.0 ) ).rgb;
		// in HDR velo vicino attenuato (k = 0,35): il cielo infinito è molto più luminoso del terreno in scala lineare,
		// così i primi chilometri restano limpidi e il terreno lontano si fonde ugualmente con l'orizzonte
		#ifdef TONE_MAPPING
			vec3 aW = 1.0 - aT;                                     // senza HDR la miscela è già compressa dal tone mapping
		#else
			vec3 aW = ( 1.0 - aT ) * ( 0.35 + 0.65 * ( 1.0 - aT ) );
		#endif
		gl_FragColor.rgb = gl_FragColor.rgb * aT + aL * aW;
	} else {`).replace(/#endif$/, "}\n#endif");
  // nota: atmoM[0].yw = (sole.x, sole.z) perché [0]=(acceso, sx, sy, sz)

  /* ---------- modello di diffusione, identico in JS e GLSL ---------- */
  const GLSL_ATMO = `
    const float RG = ${RG.toFixed(1)}, RA = ${RA.toFixed(1)};
    const vec3 BR = vec3(${BR.map(x => x.toExponential(4)).join(",")}), BO = vec3(${BO.map(x => x.toExponential(4)).join(",")});
    uniform float uMie, uHm, uG;
    float raySfera(vec3 o, vec3 d, float R) { float b = dot(o, d), c = dot(o, o) - R * R, h = b * b - c; if (h < 0.0) return -1.0; h = sqrt(h); float t = -b - h; if (t < 0.0) t = -b + h; return t; }
    float terra(vec3 o, vec3 d) { float b = dot(o, d), c = dot(o, o) - RG * RG, h = b * b - c; if (h < 0.0) return -1.0; float t = -b - sqrt(h); return t > 0.0 ? t : -1.0; }
    vec3 dens(float h) { return vec3(exp(-h / ${HR.toFixed(1)}), exp(-h / uHm), max(0.0, 1.0 - abs(h - ${HO.toFixed(1)}) / ${WO.toFixed(1)})); }
    vec3 estinz(vec3 d) { return BR * d.x + vec3(uMie * 1.11) * d.y + BO * d.z; }
    vec3 trasmSole(vec3 p, vec3 s) {
      if (terra(p, s) > 0.0) return vec3(0.0);
      float L = raySfera(p, s, RA); vec3 od = vec3(0.0); float ds = L / 6.0;
      for (int j = 0; j < 6; j++) { vec3 q = p + s * (float(j) + 0.5) * ds; od += dens(length(q) - RG) * ds; }
      return exp(-estinz(od));
    }
    vec3 cielo(float hc, vec3 v, vec3 s, out vec3 trasm) {
      vec3 o = vec3(0.0, RG + max(hc, 1.0), 0.0);
      float tA = raySfera(o, v, RA), tG = terra(o, v), tm = tG > 0.0 ? tG : tA;
      float mu = dot(v, s), pr = 3.0 / (16.0 * 3.14159265) * (1.0 + mu * mu);
      float g2 = uG * uG, pm = 3.0 / (8.0 * 3.14159265) * ((1.0 - g2) * (1.0 + mu * mu)) / ((2.0 + g2) * pow(max(1e-4, 1.0 + g2 - 2.0 * uG * mu), 1.5));
      vec3 L = vec3(0.0), od = vec3(0.0); float tPrec = 0.0;
      for (int i = 0; i < 24; i++) {
        float f = (float(i) + 1.0) / 24.0; float t = tm * f * f; float ds = t - tPrec; float tc = t - 0.5 * ds; tPrec = t;
        vec3 p = o + v * tc; float h = length(p) - RG; vec3 d = dens(h); od += d * ds;
        vec3 Tv = exp(-estinz(od)); vec3 Ts = trasmSole(p, s);
        vec3 sc = BR * d.x * pr + vec3(uMie * d.y * pm);
        L += Tv * Ts * sc * ds;
        // diffusione multipla approssimata: un velo isotropo proporzionale alla luce che arriva
        L += Tv * (BR * d.x + vec3(uMie * d.y)) * ds * 0.06 * max(0.0, s.y + 0.1) * vec3(0.6, 0.75, 1.0);
      }
      trasm = exp(-estinz(od));
      if (tG > 0.0) { vec3 pg = o + v * tG; L += trasm * trasmSole(pg, s) * max(0.0, dot(normalize(pg), s)) * 0.08 / 3.14159265; }
      return L * ${SOLE.toFixed(1)};
    }`;
  // gemello JS (per luci e colori della nebbia: pochi raggi, solo quando cambiano sole o quota)
  const v3 = (x, y, z) => [x, y, z], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  function raySfera(o, d, R) { const b = dot(o, d), c = dot(o, o) - R * R; let h = b * b - c; if (h < 0) return -1; h = Math.sqrt(h); let t = -b - h; if (t < 0) t = -b + h; return t; }
  function terra(o, d) { const b = dot(o, d), c = dot(o, o) - RG * RG, h = b * b - c; if (h < 0) return -1; const t = -b - Math.sqrt(h); return t > 0 ? t : -1; }
  const dens = h => [Math.exp(-h / HR), Math.exp(-h / P.hm), Math.max(0, 1 - Math.abs(h - HO) / WO)];
  const estinz = d => [0, 1, 2].map(k => BR[k] * d[0] + P.mie * 1.11 * d[1] + BO[k] * d[2]);
  function trasmSole(p, s) {
    if (terra(p, s) > 0) return [0, 0, 0];
    const L = raySfera(p, s, RA), ds = L / 6, od = [0, 0, 0];
    for (let j = 0; j < 6; j++) { const t = (j + 0.5) * ds, q = [p[0] + s[0] * t, p[1] + s[1] * t, p[2] + s[2] * t]; const d = dens(Math.hypot(q[0], q[1], q[2]) - RG); od[0] += d[0] * ds; od[1] += d[1] * ds; od[2] += d[2] * ds; }
    return estinz(od).map(x => Math.exp(-x));
  }
  function cielo(hc, v, s, gMie) {
    const o = [0, RG + Math.max(hc, 1), 0], tA = raySfera(o, v, RA), tG = terra(o, v), tm = tG > 0 ? tG : tA;
    const mu = dot(v, s), pr = 3 / (16 * Math.PI) * (1 + mu * mu), g = gMie == null ? P.g : gMie, g2 = g * g;
    const pm = 3 / (8 * Math.PI) * ((1 - g2) * (1 + mu * mu)) / ((2 + g2) * Math.pow(Math.max(1e-4, 1 + g2 - 2 * g * mu), 1.5));
    const L = [0, 0, 0], od = [0, 0, 0]; let tp = 0;
    for (let i = 0; i < 24; i++) {
      const f = (i + 1) / 24, t = tm * f * f, ds = t - tp, tc = t - 0.5 * ds; tp = t;
      const p = [o[0] + v[0] * tc, o[1] + v[1] * tc, o[2] + v[2] * tc], d = dens(Math.hypot(p[0], p[1], p[2]) - RG);
      od[0] += d[0] * ds; od[1] += d[1] * ds; od[2] += d[2] * ds;
      const ex = estinz(od), Ts = trasmSole(p, s), ms = 0.06 * Math.max(0, s[1] + 0.1), tint = [0.6, 0.75, 1];
      for (let k = 0; k < 3; k++) { const Tv = Math.exp(-ex[k]); L[k] += Tv * Ts[k] * (BR[k] * d[0] * pr + P.mie * d[1] * pm) * ds + Tv * (BR[k] * d[0] + P.mie * d[1]) * ds * ms * tint[k]; }
    }
    return L.map(x => x * SOLE);
  }

  /* ---------- tabella del cielo (LUT) e cupola ---------- */
  let lut = null, lutScena = null, lutCam = null, lutMat = null;
  function creaLut(r) {
    const hf = r.capabilities.isWebGL2 && (r.extensions.has("EXT_color_buffer_float") || r.extensions.has("EXT_color_buffer_half_float"));
    const tipo = hf ? T.HalfFloatType : T.UnsignedByteType;
    lut = new T.WebGLRenderTarget(192, 108, { type: tipo, minFilter: T.LinearFilter, magFilter: T.LinearFilter, depthBuffer: false, stencilBuffer: false, generateMipmaps: false });
    lut.texture.wrapS = T.ClampToEdgeWrapping; lut.texture.wrapT = T.ClampToEdgeWrapping;
    lutMat = new T.ShaderMaterial({
      uniforms: { uSole: { value: new T.Vector3(0, 1, 0) }, uH: { value: 1000 }, uMie: { value: P.mie }, uHm: { value: P.hm }, uG: { value: P.g }, uScala: { value: hf ? 1 : 0.5 } },
      vertexShader: "varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",
      fragmentShader: `precision highp float; varying vec2 vUv; uniform vec3 uSole; uniform float uH, uScala; ${GLSL_ATMO}
        void main(){
          // u = azimut rispetto al sole (0..pi), v = elevazione con passo fitto vicino all'orizzonte
          float az = vUv.x * 3.14159265; float w = vUv.y * 2.0 - 1.0; float el = sign(w) * w * w * 1.5707963;
          vec3 v = vec3(cos(el) * cos(az), sin(el), cos(el) * sin(az));
          vec3 s = normalize(vec3(sqrt(max(0.0, 1.0 - uSole.y * uSole.y)), uSole.y, 0.0));
          vec3 tr; vec3 L = cielo(uH, v, s, tr);
          gl_FragColor = vec4(L * uScala, 1.0);
        }`, depthTest: false, depthWrite: false, toneMapped: false
    });
    lutScena = new T.Scene(); const q = new T.Mesh(new T.PlaneGeometry(2, 2), lutMat); q.frustumCulled = false; lutScena.add(q);
    lutCam = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  }
  function materialeCupola() {
    return new T.ShaderMaterial({
      uniforms: { uLut: { value: lut.texture }, uSole: { value: new T.Vector3(0, 1, 0) }, uSoleCol: { value: new T.Vector3(1, 1, 1) }, uEsp: { value: P.esp }, uScala: { value: lutMat.uniforms.uScala.value } },
      vertexShader: "varying vec3 vW; void main(){ vW = (modelMatrix * vec4(position,1.0)).xyz; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",
      fragmentShader: `uniform sampler2D uLut; uniform vec3 uSole, uSoleCol; uniform float uEsp, uScala; varying vec3 vW;
        void main(){
          vec3 d = normalize(vW - cameraPosition);
          float el = asin(clamp(d.y, -1.0, 1.0));
          vec2 dh = d.xz, sh = uSole.xz; float ld = length(dh), ls = length(sh);
          float ca = (ld > 1e-5 && ls > 1e-5) ? dot(dh / ld, sh / ls) : 1.0;
          float u = acos(clamp(ca, -1.0, 1.0)) / 3.14159265;
          float v = 0.5 + 0.5 * sign(el) * sqrt(abs(el) / 1.5707963);
          vec3 L = texture2D(uLut, vec2(u, v)).rgb / uScala;
          // disco solare (0,53° allargato a 1° per leggerlo sullo schermo) con oscuramento al bordo
          float c = dot(d, uSole), rr = clamp((1.0 - c) / (1.0 - cos(0.0085)), 0.0, 1.0);
          if (rr < 1.0) L += uSoleCol * (1.0 - 0.6 * (1.0 - sqrt(1.0 - rr))) * smoothstep(1.0, 0.85, rr) * 60.0;
          // aureola: diffusione in avanti molto stretta delle goccioline (più stretta del Mie della tabella)
          float cc = max(c, 0.0); L += uSoleCol * (0.35 * pow(cc, 3000.0) + 0.04 * pow(cc, 300.0));
          gl_FragColor = vec4(L * uEsp, 1.0);
          #include <tonemapping_fragment>
          #include <encodings_fragment>
        }`, side: T.BackSide, depthWrite: false, fog: false
    });
  }

  /* ---------- stato del modulo ---------- */
  const st = { orig: null, chiave: "", sunDir: new T.Vector3(), sunOrig: null, luci: [], sole: null, cupMat: null, tUlt: 0 };
  function meteo() {
    const m = (typeof APP !== "undefined" && APP.sc && APP.sc.meteo) || {};
    const vis = m.visibilita_sm != null ? Math.max(1, +m.visibilita_sm) * 1609 : 60000;   // visibilità al livello del mare
    const umid = m.umidita != null ? Math.max(0, Math.min(1, m.umidita / 100)) : 0.55;
    const cop = G.ctx.copertura || 0;
    P.mie = Math.max(4e-6, 3.912 / vis - 13.5e-6) * (0.6 + 0.5 * umid) * (1 + 1.5 * cop);
    P.hm = 1200 + 900 * cop;
    P.coperto = cop;
  }
  function luciScena(S) {
    const out = { sun: null, hemi: null };
    (S.cieloObj || []).forEach(o => { if (o.isDirectionalLight && !out.sun) out.sun = o; if (o.isHemisphereLight && !out.hemi) out.hemi = o; });
    return out;
  }
  const mod = G.registra({
    nome: "atmosfera", min: 1, ordine: 10,
    monta(ctx) {
      const S = ctx.S; if (!S.cupola) throw new Error("cupola assente");
      if (!lut) creaLut(ctx.renderer);
      st.orig = { cupMat: S.cupola.material, soleVis: S.sole ? S.sole.visible : null, sunDir: S.sunDir ? S.sunDir.clone() : null, bg: ctx.scene.background };
      const l = luciScena(S); st.luci = l;
      st.origLuci = { sunCol: l.sun && l.sun.color.clone(), sunI: l.sun && l.sun.intensity, sunPos: l.sun && l.sun.position.clone(), hSky: l.hemi && l.hemi.color.clone(), hGnd: l.hemi && l.hemi.groundColor.clone(), hI: l.hemi && l.hemi.intensity };
      st.cupMat = materialeCupola(); S.cupola.material = st.cupMat;
      if (S.sole) S.sole.visible = false;
      st.chiave = ""; ctx.sunDir = st.sunDir;
    },
    smonta(ctx) {
      const S = ctx.S; M[0] = 0;
      if (st.orig) {
        if (S && S.cupola && st.cupMat && S.cupola.material === st.cupMat) S.cupola.material = st.orig.cupMat;
        if (S && S.sole && st.orig.soleVis != null) S.sole.visible = st.orig.soleVis;
        if (S && S.sunDir && st.orig.sunDir) S.sunDir.copy(st.orig.sunDir);
        const l = st.luci || {}, o = st.origLuci || {};
        if (l.sun && o.sunCol) { l.sun.color.copy(o.sunCol); l.sun.intensity = o.sunI; l.sun.position.copy(o.sunPos); }
        if (l.hemi && o.hSky) { l.hemi.color.copy(o.hSky); l.hemi.groundColor.copy(o.hGnd); l.hemi.intensity = o.hI; }
      }
      if (st.cupMat) { st.cupMat.dispose(); st.cupMat = null; }
      st.orig = null; ctx.sunDir = null;
    },
    prima(ctx) {
      const S = ctx.S, r = ctx.renderer, cam = ctx.camera; meteo();
      // sole all'ora scelta
      const m = (typeof APP !== "undefined" && APP.sc && APP.sc.meteo) || {};
      const lat = (APP.sc && APP.sc.mappa && APP.sc.mappa.centro) ? APP.sc.mappa.centro[0] : 45;
      const ora = G.imp.ora == null ? 14.5 : G.imp.ora;
      const so = G.sole(ora, lat, m.giorno || 165); let d = so.dir;
      if (d.y < -0.07) d = new T.Vector3(d.x, -0.07, d.z).normalize();          // al massimo crepuscolo civile
      st.sunDir.copy(d); if (S.sunDir) S.sunDir.copy(d);
      const hc = Math.max(0, cam.position.y);
      // la tabella del cielo si rifà solo se sole, quota o foschia cambiano davvero
      const chiave = [Math.round(d.x * 500), Math.round(d.y * 2000), Math.round(d.z * 500), Math.round(hc / 150), Math.round(P.mie * 1e7), Math.round(P.hm / 50)].join(",");
      if (chiave !== st.chiave && performance.now() - st.tUlt > 120) {
        st.chiave = chiave; st.tUlt = performance.now();
        const u = lutMat.uniforms; u.uSole.value.copy(d); u.uH.value = hc; u.uMie.value = P.mie; u.uHm.value = P.hm; u.uG.value = P.g;
        const prec = r.getRenderTarget(); r.setRenderTarget(lut); r.render(lutScena, lutCam); r.setRenderTarget(prec);
        // colori per luci e nebbia (stesso modello, in JS)
        const s = [d.x, d.y, d.z], hs = Math.hypot(d.x, d.z) || 1, sx = d.x / hs, sz = d.z / hs, e = 0.03;
        const ce = Math.cos(e), se = Math.sin(e);
        // Mie isotropa: il picco in avanti dipende dall'angolo vero fra sguardo e sole e si aggiunge pixel per pixel
        const verso = cielo(hc, [sx * ce, se, sz * ce], s, 0), lato = cielo(hc, [-sz * ce, se, sx * ce], s, 0), contro = cielo(hc, [-sx * ce, se, -sz * ce], s, 0);
        const zen = cielo(hc, [0, 1, 0], s);
        const Ts = trasmSole([0, RG + Math.max(hc, 1), 0], s);
        st.col = { verso, lato, contro, zen, Ts };
      }
      const c = st.col, cop = P.coperto;
      // luce del cielo = media fra zenit e orizzonte (il cielo intero è meno saturo dello zenit)
      const media = col => [0, 1, 2].map(k => 0.5 * col.zen[k] + 0.25 * (col.lato[k] + col.contro[k]) * 0.35);
      const lumi = v => 0.3 * v[0] + 0.55 * v[1] + 0.15 * v[2];
      if (!st.rif) { const s60 = [0, Math.sin(1.05), Math.cos(1.05)]; st.rif = lumi(media({ zen: cielo(1000, [0, 1, 0], s60), lato: cielo(1000, [1, 0.03, 0], s60, 0), contro: cielo(1000, [0, 0.03, -1], s60, 0) })); }
      const zs = media(c), lum = Math.max(1e-5, lumi(zs));
      // adattamento dell'occhio: col sole basso la scena si scurisce meno di quanto cali la luce (max ×4)
      const adatta = Math.min(4, Math.max(1, Math.pow(st.rif / lum, 0.45)));
      const esp = P.esp * adatta; ctx.esposizione = esp; ctx.adatta = adatta;
      // nebbia (ramo atmosfera): luce d'orizzonte già moltiplicata per l'esposizione
      const grigio = (L) => { const y = lumi(L); return [0, 1, 2].map(k => (L[k] * (1 - cop) + y * cop * 0.85) * esp); };
      const a = grigio(c.verso), b = grigio(c.lato), q = grigio(c.contro);
      M[0] = 1; M[1] = d.x; M[2] = d.y; M[3] = d.z;
      M[4] = a[0]; M[5] = a[1]; M[6] = a[2]; M[7] = P.mie * 1.11;
      M[8] = b[0]; M[9] = b[1]; M[10] = b[2]; M[11] = P.hm;
      M[12] = q[0]; M[13] = q[1]; M[14] = q[2]; M[15] = 0;
      // cupola
      const cu = st.cupMat.uniforms; cu.uSole.value.copy(d); cu.uEsp.value = esp; cu.uSoleCol.value.set(c.Ts[0], c.Ts[1], c.Ts[2]).multiplyScalar(SOLE * (1 - 0.97 * cop));
      // luce del sole: colore trasmesso, intensità tarata perché a mezzogiorno resti come prima (1,35)
      const l = st.luci; const tm = Math.max(c.Ts[0], c.Ts[1], c.Ts[2], 1e-4);
      ctx.soleCol = [c.Ts[0] / tm, c.Ts[1] / tm, c.Ts[2] / tm]; ctx.soleInt = 1.55 * tm * Math.max(0, Math.min(1, d.y * 6 + 0.15)) * (1 - 0.85 * cop) * adatta;
      if (l.sun) { l.sun.color.setRGB(ctx.soleCol[0], ctx.soleCol[1], ctx.soleCol[2]); l.sun.intensity = ctx.soleInt; l.sun.position.copy(d).multiplyScalar(100000); }
      if (l.hemi) {
        const mz = Math.max(zs[0], zs[1], zs[2], 1e-4);
        l.hemi.color.setRGB(zs[0] / mz, zs[1] / mz, zs[2] / mz).lerp(new T.Color(1, 1, 1), 0.35).lerp(new T.Color(0.85, 0.88, 0.92), cop);
        l.hemi.groundColor.setRGB(0.29, 0.25, 0.19).multiplyScalar(0.4 + 0.6 * tm);
        l.hemi.intensity = Math.min(1.1, 0.75 * (lum / st.rif) * adatta) * (1 + 0.5 * cop);
      }
    },
    dopo() { M[0] = 0; }     // le altre viste (missione 3D, cinematiche) restano con la nebbia originale
  });
  return { P, mod, cielo, trasmSole, get sunDir() { return st.sunDir; }, get colori() { return st.col; } };
})();
