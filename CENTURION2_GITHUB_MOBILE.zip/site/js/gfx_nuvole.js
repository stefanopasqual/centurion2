/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA · 2 – NUVOLE A IMPOSTOR ILLUMINATE
   - Cumuli fatti di "sbuffi" (billboard) disegnati in UN solo draw call (InstancedMesh), ordinati dal
     più lontano al più vicino ogni pochi decimi di secondo. Ogni sbuffo ha una normale sferica finta,
     base più scura (autoombra), bordo argentato controsole (diffusione Mie in avanti, Henyey-Greenstein),
     luce del cielo presa dall'atmosfera e prospettiva aerea (le nuvole lontane si sbiadiscono nel cielo).
   - Tre situazioni: sereno, nubi sparse (cumuli), coperto (strato continuo di sbuffi piatti + soffitto
     a rumore frattale visto da sotto). "Dal meteo dello scenario" usa APP.sc.meteo.copertura e nubi_base_ft.
   - Sotto il coperto il sole si spegne e la foschia sale; sopra lo strato si torna al sole pieno
     (comunicato all'atmosfera con CENTURION_GFX.ctx.copertura).
   - Qualità: BASSA ~500 sbuffi, MEDIA ~1200, ALTA ~2200; gli sbuffi vicinissimi alla camera svaniscono
     (niente schermo pieno di trasparenze, che sui telefoni costa).
   ===================================================================== */
window.CENTURION_NUVOLE = window.CENTURION_NUVOLE || (() => {
  "use strict";
  const T = window.THREE, G = window.CENTURION_GFX; if (!T || !G) return null;
  const MAXP = [0, 500, 1200, 2200];
  const LATO = 110000;                      // area coperta (m), centrata sulla mappa

  /* ---------- texture degli sbuffi: 4 varianti in un atlante 2×2, generate al volo ---------- */
  let atlas = null;
  function creaAtlante() {
    const N = 256, H = 128, c = document.createElement("canvas"); c.width = c.height = N; const g = c.getContext("2d");
    const img = g.createImageData(N, N), d = img.data; let seme = 7;
    const rnd = () => { seme = (seme * 16807) % 2147483647; return seme / 2147483647; };
    for (let v = 0; v < 4; v++) {
      const ox = (v % 2) * H, oy = Math.floor(v / 2) * H; const blob = [];
      for (let k = 0; k < 9 + v * 2; k++) { const a = rnd() * 6.283, r = Math.sqrt(rnd()) * 0.42; blob.push([0.5 + Math.cos(a) * r, 0.52 + Math.sin(a) * r * 0.75, 0.16 + rnd() * 0.2]); }
      for (let y = 0; y < H; y++) for (let x = 0; x < H; x++) {
        const u = (x + 0.5) / H, w = (y + 0.5) / H; let s = 0;
        for (const [bx, by, br] of blob) { const q = ((u - bx) ** 2 + (w - by) ** 2) / (br * br); if (q < 1) s += (1 - q) * (1 - q); }
        // rumore a due scale per bordi frastagliati
        const n = 0.5 + 0.25 * Math.sin(u * 37 + v * 3) * Math.sin(w * 41 + v) + 0.25 * Math.sin(u * 91 + w * 13 + v * 7) * Math.sin(w * 83 - u * 17);
        const r2 = ((u - 0.5) ** 2 + (w - 0.5) ** 2) * 4; const bordo = Math.max(0, 1 - r2);
        const a = Math.max(0, Math.min(1, (s * 1.6 - 0.25 + (n - 0.5) * 0.5) * bordo * 1.4));
        const i = ((oy + y) * N + ox + x) * 4; d[i] = 255; d[i + 1] = Math.round(255 * Math.min(1, s * 0.8)); d[i + 2] = Math.round(255 * n); d[i + 3] = Math.round(255 * a);
      }
    }
    g.putImageData(img, 0, 0);
    const t = new T.CanvasTexture(c); t.generateMipmaps = true; t.minFilter = T.LinearMipmapLinearFilter; t.magFilter = T.LinearFilter; return t;
  }

  /* ---------- materiale ---------- */
  function materiale() {
    const u = T.UniformsUtils.merge([T.UniformsLib.fog, {
      uMap: { value: null }, uSole: { value: new T.Vector3(0, 1, 0) }, uSoleCol: { value: new T.Vector3(1, 1, 1) },
      uCielo: { value: new T.Vector3(0.5, 0.6, 0.8) }, uFondo: { value: new T.Vector3(0.3, 0.3, 0.32) }, uVicino: { value: 220 }, uOpac: { value: 1 }
    }]);
    u.uMap.value = atlas; if (T.UniformsLib.fog.atmoM) u.atmoM = T.UniformsLib.fog.atmoM;   // stesso array dell'atmosfera
    return new T.ShaderMaterial({
      uniforms: u, fog: true, transparent: true, depthWrite: false, depthTest: true, premultipliedAlpha: false,
      vertexShader: `
        attribute vec4 iPos;  // xyz centro, w rotazione
        attribute vec4 iDim;  // larghezza, altezza, quota relativa nella nuvola (0 base, 1 cima), variante
        varying vec2 vUv; varying vec3 vN; varying float vH, vFade; varying vec3 vVista;
        uniform float uVicino;
        #include <common>
        #include <fog_pars_vertex>
        #include <logdepthbuf_pars_vertex>
        void main(){
          vec4 c = viewMatrix * vec4(iPos.xyz, 1.0);
          float cr = cos(iPos.w), sr = sin(iPos.w); vec2 p = vec2(position.x * cr - position.y * sr, position.x * sr + position.y * cr);
          vec4 mvPosition = c + vec4(p.x * iDim.x, p.y * iDim.y, 0.0, 0.0);
          float vr = iDim.w; vec2 off = vec2(mod(vr, 2.0), floor(vr / 2.0)) * 0.5;
          vUv = off + (position.xy + 0.5) * 0.5;
          // normale finta della "palla" di vapore, in coordinate mondo
          vec3 nv = normalize(vec3(position.x * 1.6, position.y * 1.6, 0.6));
          vN = normalize((vec4(nv, 0.0) * viewMatrix).xyz);
          vH = clamp(iDim.z + position.y * 0.35, 0.0, 1.0);
          float dist = -c.z; vFade = smoothstep(uVicino * 0.4, uVicino, dist) * (1.0 - smoothstep(60000.0, 75000.0, dist));
          vVista = normalize((vec4(mvPosition.xyz, 0.0) * viewMatrix).xyz);
          gl_Position = projectionMatrix * mvPosition;
          #include <logdepthbuf_vertex>
          #include <fog_vertex>
        }`,
      fragmentShader: `
        uniform sampler2D uMap; uniform vec3 uSole, uSoleCol, uCielo, uFondo; uniform float uOpac;
        varying vec2 vUv; varying vec3 vN; varying float vH, vFade; varying vec3 vVista;
        #include <common>
        #include <fog_pars_fragment>
        #include <logdepthbuf_pars_fragment>
        void main(){
          #include <logdepthbuf_fragment>
          vec4 tx = texture2D(uMap, vUv);
          float a = tx.a * vFade * uOpac; if (a < 0.01) discard;
          float dens = tx.g;                                    // spessore locale: il centro è più denso
          float lamb = clamp(dot(vN, uSole) * 0.6 + 0.4, 0.0, 1.0);
          float mu = dot(vVista, uSole); float g = 0.55, hg = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * mu, 1.5) / 12.566;
          float auto_ombra = mix(0.28, 1.0, smoothstep(0.0, 0.9, vH)) * (1.0 - 0.4 * dens);
          vec3 sole = uSoleCol * (lamb * auto_ombra + hg * 6.0 * (1.0 - dens) * (0.4 + 0.6 * (1.0 - a)));
          vec3 cielo = mix(uFondo, uCielo, smoothstep(0.0, 1.0, vH));
          gl_FragColor = vec4(sole + cielo, a);
          #include <tonemapping_fragment>
          #include <encodings_fragment>
          #include <fog_fragment>
        }`
    });
  }

  /* ---------- soffitto del coperto (visto da sotto) ---------- */
  function materialeSoffitto() {
    const u = T.UniformsUtils.merge([T.UniformsLib.fog, { uSole: { value: new T.Vector3() }, uSoleCol: { value: new T.Vector3() }, uCielo: { value: new T.Vector3() }, uFondo: { value: new T.Vector3() }, uOff: { value: new T.Vector2() }, uSopra: { value: 0 } }]);
    if (T.UniformsLib.fog.atmoM) u.atmoM = T.UniformsLib.fog.atmoM;
    return new T.ShaderMaterial({
      uniforms: u, fog: true, transparent: true, depthWrite: false, side: T.DoubleSide,
      vertexShader: `varying vec2 vP; uniform vec2 uOff;
        #include <common>
        #include <fog_pars_vertex>
        #include <logdepthbuf_pars_vertex>
        void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vP = w.xz / 4000.0 + uOff; vec4 mvPosition = viewMatrix * w; gl_Position = projectionMatrix * mvPosition;
          #include <logdepthbuf_vertex>
          #include <fog_vertex>
        }`,
      fragmentShader: `uniform vec3 uSoleCol, uCielo, uFondo; uniform float uSopra; varying vec2 vP;
        #include <common>
        #include <fog_pars_fragment>
        #include <logdepthbuf_pars_fragment>
        float h2(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
        float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(h2(i), h2(i + vec2(1, 0)), f.x), mix(h2(i + vec2(0, 1)), h2(i + vec2(1, 1)), f.x), f.y); }
        void main(){
          #include <logdepthbuf_fragment>
          float n = 0.0, a = 0.5; vec2 p = vP; for (int i = 0; i < 4; i++) { n += a * vn(p); p = p * 2.03 + 1.7; a *= 0.5; }
          float spessore = smoothstep(0.25, 0.75, n);
          // da sotto: soffitto grigio con zone più spesse e scure; da sopra: tetto di nubi al sole
          vec3 col = uSopra > 0.5 ? uSoleCol * (0.62 + 0.3 * n) + uCielo * 0.75 : mix(uCielo * 1.05, uFondo * 0.75, spessore) + uSoleCol * 0.08 * (1.0 - spessore);
          gl_FragColor = vec4(col, 0.98);
          #include <tonemapping_fragment>
          #include <encodings_fragment>
          #include <fog_fragment>
        }`
    });
  }

  /* ---------- campo di nuvole ---------- */
  function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  // quota mediana del terreno già caricato (i riquadri non ancora arrivati valgono 0 e si scartano)
  function quotaMedia(suolo) { let q = []; for (let i = -6; i <= 6; i++) for (let j = -6; j <= 6; j++) q.push(suolo(i * 7000, j * 7000)); const pos = q.filter(v => Math.abs(v) > 0.5); if (pos.length >= 12) q = pos; q.sort((a, b) => a - b); return { med: q[Math.floor(q.length / 2)], max: q[q.length - 1] }; }
  function genera(tipo, maxP, suolo, meteo) {
    const P = [], R = rng(tipo === "coperto" ? 4242 : 1717), qm = quotaMedia(suolo);
    const baseAgl = meteo.nubi_base_ft ? meteo.nubi_base_ft * 0.3048 : (tipo === "coperto" ? 1100 : 1700);
    const base = Math.max(qm.med + baseAgl, 600);
    if (tipo === "coperto") {
      // strato continuo: griglia di sbuffi piatti e larghi, cima ondulata
      const passo = Math.sqrt(LATO * LATO / (maxP * 0.92));
      for (let x = -LATO / 2; x < LATO / 2; x += passo) for (let z = -LATO / 2; z < LATO / 2; z += passo) {
        if (P.length >= maxP) break;
        const w = passo * (1.7 + R() * 0.8), cx = x + (R() - 0.5) * passo, cz = z + (R() - 0.5) * passo;
        const top = R() * 260;
        P.push([cx, base + 220 + top, cz, R() * 6.28, w, w * 0.42, 0.55 + R() * 0.45, Math.floor(R() * 4)]);
      }
      return { P, base, cima: base + 650, tipo };
    }
    // cumuli: gruppi a cupola con base piatta, 1,5–4 km di diametro
    const nNubi = Math.max(10, Math.floor(maxP / 14));
    for (let k = 0; k < nNubi && P.length < maxP; k++) {
      const cx = (R() - 0.5) * LATO, cz = (R() - 0.5) * LATO, sc = 0.7 + R() * 1.0, rag = 1000 * sc, alt = 1100 * sc;
      const b = Math.max(base + (R() - 0.5) * 300, suolo(cx, cz) + 400);
      const n = 10 + Math.floor(R() * 8);
      for (let i = 0; i < n && P.length < maxP; i++) {
        const a = R() * 6.28, r = Math.sqrt(R()) * rag, h = Math.pow(R(), 0.8);
        // cupola: in alto gli sbuffi stanno verso il centro, in basso si allargano e appiattiscono
        const y = b + 250 * sc + h * alt * (1 - 0.7 * (r / rag) ** 2);
        const w = (650 + R() * 600) * sc * (1 - 0.3 * h);
        P.push([cx + Math.cos(a) * r * 1.25, y, cz + Math.sin(a) * r, R() * 6.28, w, w * (0.75 - 0.2 * (1 - h)), Math.min(1, (y - b) / (alt + 250 * sc)), Math.floor(R() * 4)]);
      }
    }
    return { P, base, cima: base + 1500, tipo };
  }

  /* ---------- stato del modulo ---------- */
  const st = { mesh: null, soff: null, campo: null, chiave: "", tOrd: 0, camOrd: new T.Vector3(1e9, 0, 0), ord: null };
  function copertura() {
    const m = (typeof APP !== "undefined" && APP.sc && APP.sc.meteo) || {}; const s = G.imp.nuvole || "auto";
    if (s === "sereno") return 0; if (s === "sparse") return 0.4; if (s === "coperto") return 1;
    return m.copertura != null ? +m.copertura : 0.35;
  }
  function tipoDa(c) { return c < 0.1 ? "sereno" : c > 0.8 ? "coperto" : "sparse"; }
  function costruisci(ctx, tipo) {
    smontaMesh(ctx);
    if (tipo === "sereno") { st.campo = { P: [], tipo }; return; }
    const suolo = (VOLO._acc && VOLO._acc.suolo) ? VOLO._acc.suolo : () => 0;
    const meteo = (APP.sc && APP.sc.meteo) || {};
    const maxP = Math.round(MAXP[ctx.livello] * (tipo === "coperto" ? 0.9 : 1 * Math.min(1, 0.5 + copertura())));
    const campo = genera(tipo, maxP, suolo, meteo); st.campo = campo;
    if (!atlas) atlas = creaAtlante();
    const g = new T.InstancedBufferGeometry(); const q = new T.PlaneGeometry(1, 1);
    g.index = q.index; g.setAttribute("position", q.attributes.position);
    const n = campo.P.length; g.instanceCount = n;
    g.setAttribute("iPos", new T.InstancedBufferAttribute(new Float32Array(n * 4), 4).setUsage(T.DynamicDrawUsage));
    g.setAttribute("iDim", new T.InstancedBufferAttribute(new Float32Array(n * 4), 4).setUsage(T.DynamicDrawUsage));
    const mesh = new T.Mesh(g, materiale()); mesh.frustumCulled = false; mesh.renderOrder = 5; mesh.name = "gfx_nuvole";
    ctx.scene.add(mesh); st.mesh = mesh; st.ord = new Uint32Array(n).map((_, i) => i); st.camOrd.set(1e9, 0, 0);
    if (tipo === "coperto") {
      const s = new T.Mesh(new T.PlaneGeometry(160000, 160000, 1, 1).rotateX(Math.PI / 2), materialeSoffitto());
      s.position.y = campo.base + 320; s.frustumCulled = false; s.renderOrder = 4; s.name = "gfx_soffitto"; ctx.scene.add(s); st.soff = s;
    }
  }
  function smontaMesh(ctx) {
    [st.mesh, st.soff].forEach(m => { if (m) { if (m.parent) m.parent.remove(m); m.geometry.dispose(); m.material.dispose(); } });
    st.mesh = st.soff = null;
  }
  // ordina dal più lontano: la trasparenza "sopra" vuole lo sfondo disegnato prima
  function ordina(cam) {
    const P = st.campo.P, n = P.length, d = new Float32Array(n), cx = cam.position.x, cy = cam.position.y, cz = cam.position.z;
    for (let i = 0; i < n; i++) { const p = P[i]; d[i] = (p[0] - cx) ** 2 + (p[1] - cy) ** 2 + (p[2] - cz) ** 2; }
    const o = st.ord; o.sort((a, b) => d[b] - d[a]);
    const ip = st.mesh.geometry.attributes.iPos, id = st.mesh.geometry.attributes.iDim;
    for (let k = 0; k < n; k++) { const p = P[o[k]]; ip.array.set([p[0], p[1], p[2], p[3]], k * 4); id.array.set([p[4], p[5], p[6], p[7]], k * 4); }
    ip.needsUpdate = id.needsUpdate = true;
  }

  const mod = G.registra({
    nome: "nuvole", min: 1, ordine: 5,    // prima dell'atmosfera: le passa la copertura del fotogramma
    monta(ctx) { st.chiave = ""; },
    smonta(ctx) { smontaMesh(ctx); st.campo = null; st.chiave = ""; G.ctx.copertura = 0; },
    prima(ctx) {
      const S = ctx.S;
      // il campo si rifà quando arrivano altri riquadri di terreno (le basi seguono le quote vere)
      const ter = (VOLO.debug && /^(\d+)\/(\d+)$/.exec(VOLO.debug.terreno)) || [0, 0, 1]; const fase = Math.min(4, Math.floor(+ter[1] / 18));
      const cop = copertura(), tipo = tipoDa(cop), chiave = tipo + "|" + ctx.livello + "|" + fase + "|" + (APP.sc && APP.sc.mappa5 ? APP.sc.mappa5.id : "");
      if (chiave !== st.chiave) { st.chiave = chiave; costruisci(ctx, tipo); }
      const cam = ctx.camera, campo = st.campo;
      // sotto lo strato coperto: sole spento e foschia (per l'atmosfera); sopra: sole pieno
      if (campo && campo.tipo === "coperto") { const k = 1 - Math.max(0, Math.min(1, (cam.position.y - campo.base) / (campo.cima - campo.base))); G.ctx.copertura = k; }
      else G.ctx.copertura = campo && campo.tipo === "sparse" ? 0.12 : 0;
      if (!st.mesh) return;
      const now = performance.now();
      if (now - st.tOrd > 250 || cam.position.distanceToSquared(st.camOrd) > 150 * 150) { st.tOrd = now; st.camOrd.copy(cam.position); ordina(cam); }
      // luce: dal modulo atmosfera se c'è, altrimenti valori fissi di mezzogiorno
      const sd = ctx.sunDir || (S.sunDir) || new T.Vector3(0, 1, 0), esp = ctx.esposizione || 1.3, sc = ctx.soleCol || [1, 0.96, 0.9], si = ctx.soleInt || 1.4;
      const col = (typeof CENTURION_ATMO !== "undefined" && CENTURION_ATMO && CENTURION_ATMO.colori) || null;
      const cieloV = col ? [0, 1, 2].map(k => (0.55 * col.zen[k] + 0.45 * col.lato[k] * 0.45) * esp) : [0.45, 0.55, 0.75];
      const fondoV = col ? [0, 1, 2].map(k => (0.3 * col.zen[k] + 0.3 * col.contro[k] * 0.3) * esp) : [0.28, 0.3, 0.34];
      const sotto = G.ctx.copertura || 0;
      for (const m of [st.mesh, st.soff]) { if (!m) continue; const u = m.material.uniforms;
        u.uSole.value.copy(sd); u.uSoleCol.value.set(sc[0], sc[1], sc[2]).multiplyScalar(si * 0.9);
        u.uCielo.value.set(cieloV[0], cieloV[1], cieloV[2]).multiplyScalar(1 + 0.8 * sotto); u.uFondo.value.set(fondoV[0], fondoV[1], fondoV[2]).multiplyScalar(1 + 0.6 * sotto); }
      if (st.soff) { st.soff.position.x = cam.position.x; st.soff.position.z = cam.position.z; st.soff.material.uniforms.uSopra.value = cam.position.y > st.soff.position.y ? 1 : 0; }
    }
  });
  return { mod, get campo() { return st.campo; }, copertura };
})();
