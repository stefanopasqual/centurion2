/* =====================================================================
   CENTURION – POD DI DESIGNAZIONE (targeting pod) · volo libero e vista 3D delle missioni
   Ispirato ai pod moderni (FLIR + TV CCD + designatore laser). Non riproduce un sistema reale certificato:
   firme termiche, guadagno e portate sono modelli visivi plausibili.
   - immagine: seconda telecamera stabilizzata sulla linea di mira (verso un punto a terra, SPI),
     in un display multifunzione (MFD) o a tutto schermo
   - sensori: FLIR bianco caldo / nero caldo (guadagno automatico logaritmico, esaltazione dei dettagli,
     rumore temporale e di colonna, alone dei punti caldi, foschia) e TV CCD (inservibile di notte)
   - campi: WIDE 4°, NARROW 1°, zoom digitale ×2 e ×4 (si vedono i pixel)
   - inseguimento: AREA (punto a terra), POINT (veicolo, edificio, velivolo), RATES mentre si sposta, mascheramento
   - immagini satellitari Esri ad alta risoluzione (z14–z18) proiettate sul terreno attorno al punto osservato
   - bersagli 3D dettagliati: batterie SA-10, radar, aeroporti, depositi, comandi C2, convogli, treni, navi
   - laser: codice, distanza laser, "L" lampeggiante durante la guida delle armi; TTI di bombe e Maverick
   - missioni: le GBU cadono davvero sul bersaglio (sincronizzate con il motore), esplosioni, incendi, macerie
   ===================================================================== */
const POD = (() => {
  const D2R = Math.PI / 180, R2D = 180 / Math.PI, NM = 1852, FT = 3.28084;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const mobile = () => matchMedia("(pointer: coarse)").matches || window.innerWidth < 900;
  const V3 = (x, y, z) => new THREE.Vector3(x || 0, y || 0, z || 0);
  const V2 = (x, y) => new THREE.Vector2(x, y);
  // campi ottici WIDE 4°, NARROW 1°, SUPER NARROW 0,35°; poi zoom digitale ×2 e ×4 sul super narrow (si vedono i pixel)
  const CAMPI = [{ nome: "WIDE", deg: 4.0, exp: 1 }, { nome: "NARO", deg: 1.0, exp: 1 }, { nome: "SNAR", deg: 0.35, exp: 1 }, { nome: "SNAR", deg: 0.175, exp: 2 }, { nome: "SNAR", deg: 0.0875, exp: 4 }];
  const MODI = ["WHOT", "BHOT", "CCD"];
  const CODICE = 1688;
  // posizione del pod sul velivolo (m, assi del velivolo: x = sinistra, y = alto, z = avanti)
  const MONTAGGIO = { F16: [0.75, -1.35, 3.6], F15: [0.0, -1.6, 4.4], F2000: [0.0, -1.35, 2.6], F22: [0.0, -1.2, 3.0], EA18: [0.0, -1.4, 3.2] };
  const HOSTS = {}; const KEYS = {};
  let H = null, S = null, R = null;

  /* ---------- stato (uno per scena: una sortita del volo libero o un'apertura della vista 3D) ---------- */
  function nuovoStato(scena) {
    return { scena, on: 0, campo: 0, modo: 0, track: "AREA", spi: null, item: null, sito: null, pfId: null, slew: { x: 0, y: 0 }, rates: 0, laserMan: false, laser: false, maschera: 0, limite: false, noGnd: false,
      sfoc: 0, agc: { lo: -5, hi: 1, tlo: -5, thi: 1, alto: 0 }, rum: 0.04, msg: null, siti: [], sitiPronti: false, sitiT: 0, sedeT: 0, rilasci: new Set(), bombe: [], fuochi: [], persone: [], mezzi: [], pozze: [], simT: null, cls: null, clsT: 0,
      cam: new THREE.PerspectiveCamera(4, 1, 2, 2.5e5), dir: V3(0, -0.3, 1).normalize(), pos: V3(), range: 0, az: 0, el: 0, tti: null, tgtI: -1, fn: 0, rect: null, aereiT: 0, sincT: 0 };
  }
  function avviso(t, dur) { if (S) S.msg = { t, fino: performance.now() + (dur || 1.6) * 1000 }; }

  /* ---------- materiali condivisi: userData.calore = firma termica (0 freddo … 1 scarico motore) ---------- */
  const MAT = {}, GEO = {};
  function tavolozza() {
    if (MAT.ok) return; MAT.ok = true;
    const m = (n, c, cal, extra) => { const x = new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.85, metalness: 0.1 }, extra || {})); x.userData.calore = cal || 0; x.name = "pod_" + n; MAT[n] = x; };
    m("oliva", 0x4b5320, 0.06); m("oliva2", 0x5d6648, 0.06); m("sabbia", 0x8b8066, 0.06); m("grigioMil", 0x5f666b, 0.06);
    m("gomma", 0x1b1b1b, 0.12, { roughness: 0.95 }); m("vetro", 0x0d1418, 0.03, { roughness: 0.15, metalness: 0.6 });
    m("motore", 0x2f3133, 0.85); m("scarico", 0x262626, 1.0); m("telo", 0x6a6a4e, 0.05);
    m("canister", 0x6b7350, 0.08); m("antenna", 0x9aa093, 0.22, { metalness: 0.5, roughness: 0.5 }); m("elettronica", 0x4f5640, 0.55);
    m("muro", 0xa9a397, 0.1); m("muro2", 0x8f8a80, 0.1); m("mattone", 0x8a6c58, 0.12); m("tetto", 0x6c6c66, 0.2); m("tetto2", 0x55585a, 0.22); m("clima", 0xb0b3b3, 0.6, { metalness: 0.4 });
    m("lamiera", 0x9ea4a8, 0.16, { metalness: 0.55, roughness: 0.45 }); m("cemento", 0xa3a097, 0.12); m("terra", 0x6e5c45, 0.04, { roughness: 1 });
    m("serbatoio", 0xcfd0cb, 0.22, { metalness: 0.3, roughness: 0.5 }); m("jet", 0x76838d, 0.08, { metalness: 0.35, roughness: 0.55 }); m("jetScuro", 0x4c5660, 0.08, { metalness: 0.35, roughness: 0.55 }); m("ugello", 0x3a3530, 0.3, { metalness: 0.6, roughness: 0.4 });
    m("elicottero", 0x5a6747, 0.08); m("scafo", 0x5b6168, 0.08, { metalness: 0.3 }); m("ponte", 0x6f747a, 0.1); m("vagone", 0x5a4637, 0.06); m("loco", 0x2f4a3a, 0.5);
    m("auto1", 0xd8d8d8, 0.15, { metalness: 0.5, roughness: 0.4 }); m("auto2", 0x2a2d33, 0.15, { metalness: 0.5, roughness: 0.4 }); m("auto3", 0x7b2a24, 0.15, { metalness: 0.5, roughness: 0.4 });
    // persone: pelle a ~33 °C, vestiti scaldati dal corpo (nel FLIR risaltano anche di giorno)
    m("pelle", 0xb88a66, 0.8, { roughness: 0.9 }); m("pelle2", 0x8d5f3f, 0.8, { roughness: 0.9 }); m("pelle3", 0xd9b08e, 0.8, { roughness: 0.9 }); m("capelli", 0x2a1f18, 0.5, { roughness: 1 }); m("camicia1", 0xcfd2d6, 0.42, { roughness: 1 }); m("camicia2", 0x6e2b2b, 0.42, { roughness: 1 }); m("camicia3", 0x2f4f6e, 0.42, { roughness: 1 }); m("camicia4", 0x5c6b3d, 0.42, { roughness: 1 }); m("jeans", 0x2c3b55, 0.4, { roughness: 1 }); m("giubbotto", 0x3a3d2c, 0.38, { roughness: 1 }); m("divisa2", 0x535a3e, 0.42, { roughness: 1 }); m("divisa", 0x4c5138, 0.45, { roughness: 1 }); m("civile", 0x3b4256, 0.42, { roughness: 1 }); m("civile2", 0x7a6a55, 0.42, { roughness: 1 });
    m("ferita", 0x4a0707, 0.7, { roughness: 0.4 }); m("bruciato", 0x1d1a18, 0.32, { roughness: 1 }); m("macerie", 0x55504a, 0.15, { roughness: 1 }); m("bomba", 0x4a5135, 0.25, { metalness: 0.3 });
    MAT.cratere = new THREE.MeshStandardMaterial({ color: 0x15120f, roughness: 1, metalness: 0, transparent: true, opacity: 0.9, depthWrite: false, alphaMap: texRadiale() }); MAT.cratere.userData.calore = 0.1;
  }
  // bruciatura irregolare attorno al cratere (macchie sovrapposte, bordo sfrangiato)
  function texRadiale() { const c = document.createElement("canvas"); c.width = c.height = 128; const g = c.getContext("2d"); g.fillStyle = "#000"; g.fillRect(0, 0, 128, 128); const rnd = seme("cratere");
    for (let i = 0; i < 26; i++) { const a = rnd() * Math.PI * 2, d = Math.pow(rnd(), 1.4) * 40, x = 64 + Math.cos(a) * d, y = 64 + Math.sin(a) * d, r = 10 + rnd() * 24 * (1 - d / 60); const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, `rgba(255,255,255,${0.55 + rnd() * 0.45})`); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(x - r, y - r, 2 * r, 2 * r); }
    return new THREE.CanvasTexture(c); }
  function geometrie() {
    if (GEO.box) return;
    GEO.box = new THREE.BoxGeometry(1, 1, 1); GEO.cil = new THREE.CylinderGeometry(0.5, 0.5, 1, 12); GEO.cono = new THREE.ConeGeometry(0.5, 1, 10); GEO.sfera = new THREE.SphereGeometry(0.5, 10, 8);
    GEO.disco = new THREE.CircleGeometry(1, 20); GEO.disco.rotateX(-Math.PI / 2);
    const s = new THREE.CylinderGeometry(0.5, 0.5, 1, 16, 1, false, 0, Math.PI); s.rotateZ(Math.PI / 2); s.rotateY(Math.PI / 2); GEO.semi = s;   // mezzo cilindro sdraiato lungo z, cupola in alto
    const pr = new THREE.ExtrudeGeometry(new THREE.Shape([V2(-0.5, 0), V2(0.5, 0), V2(0, 1)]), { depth: 1, bevelEnabled: false }); pr.translate(0, 0, -0.5); GEO.prisma = pr;   // tetto a capanna
    // ala a freccia in scala reale (apertura 15 m), spessore 1 lungo y, muso verso +z
    const al = new THREE.ExtrudeGeometry(new THREE.Shape([V2(0, 3.4), V2(1.2, 2.2), V2(7.4, -1.8), V2(7.4, -2.9), V2(0, -3.3), V2(-7.4, -2.9), V2(-7.4, -1.8), V2(-1.2, 2.2)]), { depth: 1, bevelEnabled: false }); al.rotateX(Math.PI / 2); al.translate(0, 0.5, 0); GEO.ala = al;
    const sc = new THREE.ExtrudeGeometry(new THREE.Shape([V2(-0.5, -0.5), V2(0.5, -0.5), V2(0.5, 0.28), V2(0.22, 0.44), V2(0, 0.5), V2(-0.22, 0.44), V2(-0.5, 0.28)]), { depth: 1, bevelEnabled: false }); sc.rotateX(Math.PI / 2); sc.translate(0, 1, 0); GEO.scafo = sc;
  }
  function pz(g, geo, mat, sx, sy, sz, x, y, z, rx, ry, rz) { const me = new THREE.Mesh(GEO[geo], MAT[mat]); me.scale.set(sx, sy, sz); me.position.set(x, y, z); if (rx || ry || rz) me.rotation.set(rx || 0, ry || 0, rz || 0); g.add(me); return me; }
  const ruota = (g, r, w, x, y, z) => pz(g, "cil", "gomma", 2 * r, w, 2 * r, x, y, z, 0, 0, Math.PI / 2);

  /* ---------- modelli procedurali (metri; muso dei veicoli verso +z) ---------- */
  function camion(tipo) {
    const g = new THREE.Group(); const L = 8.6;
    pz(g, "box", "oliva2", 2.4, 0.5, L, 0, 1.05, 0); pz(g, "box", "oliva", 2.45, 1.9, 2.1, 0, 2.15, L / 2 - 1.05); pz(g, "box", "vetro", 2.2, 0.7, 0.06, 0, 2.62, L / 2 + 0.01); pz(g, "box", "motore", 1.6, 0.7, 1.0, 0, 1.45, L / 2 - 0.35);
    if (tipo === "cisterna") pz(g, "cil", "oliva2", 2.1, 5.6, 2.1, 0, 2.35, -1.1, Math.PI / 2, 0, 0);
    else if (tipo === "comando" || tipo === "radar") pz(g, "box", "oliva", 2.45, 2.4, 5.4, 0, 2.5, -1.4);
    else pz(g, "box", "telo", 2.45, 2.2, 5.6, 0, 2.4, -1.3);
    if (tipo === "comando") pz(g, "cil", "antenna", 0.12, 9, 0.12, 0.9, 7.6, -3.6);
    [3.0, -0.8, -2.6].forEach(z => [-1.1, 1.1].forEach(x => ruota(g, 0.52, 0.4, x, 0.55, z)));
    pz(g, "cil", "scarico", 0.14, 1.2, 0.14, 1.05, 2.8, L / 2 - 2.0);
    return g;
  }
  function carro() {
    const g = new THREE.Group(); pz(g, "box", "oliva", 3.5, 1.3, 7.0, 0, 1.25, 0); pz(g, "box", "gomma", 0.6, 1.0, 7.2, 1.75, 0.6, 0); pz(g, "box", "gomma", 0.6, 1.0, 7.2, -1.75, 0.6, 0);
    pz(g, "box", "oliva2", 2.6, 0.9, 3.0, 0, 2.35, 0.3); pz(g, "cil", "oliva2", 0.22, 5.5, 0.22, 0, 2.4, 4.4, Math.PI / 2, 0, 0); pz(g, "box", "motore", 2.6, 0.25, 2.2, 0, 1.95, -2.4); return g;
  }
  function auto(rnd) { const g = new THREE.Group(); pz(g, "box", ["auto1", "auto2", "auto3"][Math.floor(rnd() * 3)], 1.8, 0.8, 4.5, 0, 0.75, 0); pz(g, "box", "vetro", 1.6, 0.6, 2.4, 0, 1.4, -0.2); return g; }
  // lanciatore 5P85 (SA-10) su autotelaio MAZ-543 a 8 ruote, 4 contenitori; alzati in batteria schierata
  function tel(alzato, iskander) {
    const g = new THREE.Group(); pz(g, "box", "oliva2", 3.0, 1.1, 12.6, 0, 1.45, 0);
    pz(g, "box", "oliva", 1.15, 1.5, 2.3, 0.95, 2.6, 5.0); pz(g, "box", "oliva", 1.15, 1.5, 2.3, -0.95, 2.6, 5.0); pz(g, "box", "motore", 0.75, 1.2, 2.2, 0, 2.4, 5.0);
    pz(g, "box", "vetro", 0.95, 0.5, 0.06, 0.95, 3.0, 6.16); pz(g, "box", "vetro", 0.95, 0.5, 0.06, -0.95, 3.0, 6.16);
    [4.6, 2.9, -2.4, -4.1].forEach(z => [-1.35, 1.35].forEach(x => ruota(g, 0.8, 0.55, x, 0.8, z)));
    const piv = new THREE.Group(); piv.position.set(0, 2.3, -5.6); g.add(piv);
    if (iskander) { [-0.6, 0.6].forEach(x => pz(piv, "cil", "canister", 0.95, 7.3, 0.95, x, 0.55, 3.8, Math.PI / 2, 0, 0)); pz(piv, "box", "telo", 2.6, 0.5, 8, 0, 1.15, 3.9); }
    else [[-0.46, 0.45], [0.46, 0.45], [-0.46, 1.35], [0.46, 1.35]].forEach(([x, y]) => pz(piv, "cil", "canister", 0.86, 7.9, 0.86, x, y, 3.95, Math.PI / 2, 0, 0));
    if (alzato) { piv.rotation.x = -Math.PI / 2; [-1, 1].forEach(s => pz(g, "box", "oliva2", 0.3, 0.9, 0.3, s * 1.9, 0.45, -5.6)); }
    g.userData.piv = piv; return g;
  }
  function radarFlapLid() {   // 30N6: radar di guida su autocarro, schiera piana su supporto girevole
    const g = camion("radar"); pz(g, "box", "antenna", 0.6, 3.2, 0.6, 0, 5.3, -2.0);
    const t = new THREE.Group(); t.position.set(0, 7.0, -2.0); g.add(t); pz(t, "box", "antenna", 4.4, 3.8, 0.45, 0, 1.7, 0, -0.25, 0, 0); pz(t, "box", "elettronica", 1.4, 1.0, 1.2, 0, 0.25, -0.9);
    g.userData.testa = t; g.userData.giri = 0.6; return g;
  }
  function radarBigBird() {   // 64N6: radar di scoperta su semirimorchio, due facce schiena contro schiena
    const g = new THREE.Group(); pz(g, "box", "oliva2", 3.0, 1.0, 14, 0, 1.3, 0); [4.8, 3.2, -4.6, -6.0].forEach(z => [-1.3, 1.3].forEach(x => ruota(g, 0.55, 0.45, x, 0.55, z)));
    pz(g, "box", "elettronica", 2.8, 2.6, 4, 0, 3.1, -4); pz(g, "box", "oliva", 2.4, 2.0, 2.4, 0, 2.2, 6.3);
    const t = new THREE.Group(); t.position.set(0, 4.4, 2.0); g.add(t); pz(t, "box", "antenna", 9.5, 4.8, 0.6, 0, 2.5, 0.55, -0.35, 0, 0); pz(t, "box", "antenna", 9.5, 4.8, 0.6, 0, 2.5, -0.55, 0.35, 0, Math.PI);
    g.userData.testa = t; g.userData.giri = 0.63; return g;
  }
  function radarP18() {   // radar a schiera di Yagi su traliccio
    const g = camion("radar"); const t = new THREE.Group(); t.position.set(0, 6.0, -2); g.add(t); pz(g, "cil", "antenna", 0.3, 2.5, 0.3, 0, 4.8, -2);
    for (let i = 0; i < 4; i++) pz(t, "box", "antenna", 7.5, 0.15, 0.15, 0, 0.4 + i * 0.9, 0); for (let i = 0; i < 8; i++) pz(t, "box", "antenna", 0.08, 3.2, 1.8, -3.4 + i * 0.97, 1.75, 0.9);
    g.userData.testa = t; g.userData.giri = 0.9; return g;
  }
  function generatore() { const g = new THREE.Group(); pz(g, "box", "oliva2", 2.2, 2.0, 4.2, 0, 1.4, 0); pz(g, "box", "motore", 1.6, 0.4, 1.6, 0, 2.6, -0.8); pz(g, "cil", "scarico", 0.25, 1.4, 0.25, 0.7, 3.0, 1.2); [-1.2, 1.2].forEach(z => [-1.05, 1.05].forEach(x => ruota(g, 0.4, 0.3, x, 0.4, z))); return g; }
  function argine(w, d, h) { const g = new THREE.Group(); pz(g, "box", "terra", w, h, 3.2, 0, h / 2, -d / 2); pz(g, "box", "terra", 3.2, h, d, -w / 2, h / 2, 0); pz(g, "box", "terra", 3.2, h, d, w / 2, h / 2, 0); return g; }
  function argine4(w, h) { const g = argine(w, w, h); pz(g, "box", "terra", w * 0.35, h, 3.2, -w * 0.32, h / 2, w / 2); pz(g, "box", "terra", w * 0.35, h, 3.2, w * 0.32, h / 2, w / 2); return g; }
  function edificio(w, d, h, rnd, tipo) {
    const g = new THREE.Group(); const muro = tipo === "mattone" ? "mattone" : rnd() < 0.5 ? "muro" : "muro2"; pz(g, "box", muro, w, h, d, 0, h / 2, 0);
    if (tipo === "capannone") pz(g, "prisma", "lamiera", w + 0.6, Math.min(5, w * 0.18), d + 0.6, 0, h, 0);
    else { pz(g, "box", rnd() < 0.5 ? "tetto" : "tetto2", w - 0.6, 0.5, d - 0.6, 0, h + 0.2, 0); const n = 1 + Math.floor(rnd() * 3); for (let i = 0; i < n; i++) pz(g, "box", "clima", 1.6, 1.1, 2.4, (rnd() - 0.5) * Math.max(1, w - 5), h + 0.9, (rnd() - 0.5) * Math.max(1, d - 5)); }
    const piani = Math.max(1, Math.floor(h / 3.5)); for (let p = 0; p < piani; p++) { const y = 1.8 + p * 3.5; if (y > h - 1) break; pz(g, "box", "vetro", w * 0.86, 1.1, 0.12, 0, y, d / 2 + 0.04); pz(g, "box", "vetro", w * 0.86, 1.1, 0.12, 0, y, -d / 2 - 0.04); }
    return g;
  }
  function torre() { const g = new THREE.Group(); pz(g, "box", "muro", 6, 20, 6, 0, 10, 0); pz(g, "box", "vetro", 8, 3.2, 8, 0, 21.6, 0); pz(g, "box", "tetto", 8.6, 0.5, 8.6, 0, 23.4, 0); pz(g, "cil", "antenna", 0.15, 6, 0.15, 2, 26.5, 2); return g; }
  function shelter() { const g = new THREE.Group(); pz(g, "semi", "cemento", 24, 18, 32, 0, 0, 0); pz(g, "box", "lamiera", 21, 7.2, 0.6, 0, 3.6, 16.1); return g; }
  function hangar() { const g = new THREE.Group(); pz(g, "semi", "lamiera", 46, 30, 64, 0, 0, 0); pz(g, "box", "lamiera", 40, 12, 0.6, 0, 6, 32.1); return g; }
  function jet(mat) {
    const g = new THREE.Group(); const m = mat || "jet";
    pz(g, "cil", m, 1.7, 15.5, 1.9, 0, 2.2, 0.5, Math.PI / 2, 0, 0); pz(g, "cono", m, 1.7, 4.5, 1.7, 0, 2.2, 10.5, Math.PI / 2, 0, 0); pz(g, "ala", m, 1, 0.35, 1, 0, 2.0, -1.0);
    pz(g, "box", m, 0.25, 3.2, 3.2, 1.5, 4.2, -6.2, 0, 0, -0.25); pz(g, "box", m, 0.25, 3.2, 3.2, -1.5, 4.2, -6.2, 0, 0, 0.25); pz(g, "box", m, 9.5, 0.2, 2.6, 0, 2.2, -6.8);
    pz(g, "cil", "ugello", 1.1, 1.2, 1.1, 0.65, 2.1, -7.6, Math.PI / 2, 0, 0); pz(g, "cil", "ugello", 1.1, 1.2, 1.1, -0.65, 2.1, -7.6, Math.PI / 2, 0, 0); pz(g, "box", "vetro", 0.9, 0.6, 2.6, 0, 3.15, 6.0);
    return g;
  }
  function elicottero() {
    const g = new THREE.Group(); pz(g, "box", "elicottero", 2.5, 2.6, 8.5, 0, 2.3, 0.5); pz(g, "sfera", "elicottero", 2.5, 2.4, 3.2, 0, 2.3, 4.6); pz(g, "cil", "elicottero", 0.7, 9, 0.7, 0, 2.9, -7.8, Math.PI / 2, 0, 0); pz(g, "box", "elicottero", 0.2, 2.6, 1.6, 0, 4.0, -12.0);
    pz(g, "box", "motore", 1.8, 0.9, 3.0, 0, 4.0, 0.2); const rot = new THREE.Group(); rot.position.set(0, 4.8, 0.2); g.add(rot);
    for (let i = 0; i < 5; i++) { const a = i * Math.PI * 2 / 5; pz(rot, "box", "jetScuro", 0.5, 0.08, 10.5, Math.sin(a) * 5.25, 0, Math.cos(a) * 5.25, 0, a, 0); }
    return g;
  }
  function serbatoio(r, h) { const g = new THREE.Group(); pz(g, "cil", "serbatoio", 2 * r, h, 2 * r, 0, h / 2, 0); pz(g, "cono", "serbatoio", 2 * r, 1.6, 2 * r, 0, h + 0.8, 0); return g; }
  function nave() {
    const g = new THREE.Group(); pz(g, "scafo", "scafo", 11, 6, 72, 0, -2, 0); pz(g, "box", "ponte", 9.4, 0.3, 64, 0, 4.1, -2); pz(g, "box", "scafo", 8, 7, 14, 0, 7.6, -8); pz(g, "box", "vetro", 7.6, 1.2, 0.2, 0, 9.6, -0.9);
    pz(g, "cil", "scarico", 2.8, 5, 3.6, 0, 12.6, -16); pz(g, "cil", "antenna", 0.5, 12, 0.5, 0, 16.5, -6); pz(g, "box", "grigioMil", 3, 2, 4, 0, 5.2, 22); pz(g, "cil", "grigioMil", 0.35, 5, 0.35, 0, 6.2, 25, 1.2, 0, 0);
    return g;
  }
  function vagone(cisterna) { const g = new THREE.Group(); if (cisterna) pz(g, "cil", "serbatoio", 2.8, 12.5, 2.8, 0, 2.6, 0, Math.PI / 2, 0, 0); else pz(g, "box", "vagone", 3.0, 3.3, 14, 0, 2.6, 0); pz(g, "box", "gomma", 2.6, 0.8, 13, 0, 0.6, 0); return g; }
  function loco() { const g = new THREE.Group(); pz(g, "box", "loco", 3.0, 3.9, 17, 0, 2.6, 0); pz(g, "box", "motore", 2.2, 0.5, 6, 0, 4.75, -2); pz(g, "box", "gomma", 2.6, 0.8, 16, 0, 0.6, 0); return g; }
  /* persona con scheletro articolato (bacino, busto, collo, testa, spalle, gomiti, anche, ginocchia, caviglie),
     proporzioni anatomiche, superfici arrotondate; militari con elmetto, giubbotto e fucile, civili con abiti e capelli vari */
  const CAPS = {};
  const caps = (r, l) => CAPS[r + "_" + l] || (CAPS[r + "_" + l] = new THREE.CapsuleGeometry(r, l, 3, 8));
  function pc(g, r, l, mat, x, y, z, sx, sz) { const me = new THREE.Mesh(caps(r, l), MAT[mat]); me.position.set(x, y, z); if (sx || sz) me.scale.set(sx || 1, 1, sz || 1); g.add(me); return me; }
  function nodo(par, x, y, z) { const o = new THREE.Group(); o.position.set(x, y, z); par.add(o); return o; }
  function persona(rnd, civile) {
    const g = new THREE.Group(); g.rotation.order = "YXZ"; const h = 0.9 + rnd() * 0.1; g.scale.setScalar(h);
    const pelle = ["pelle", "pelle2", "pelle3"][Math.floor(rnd() * 3)], sopra = civile ? ["camicia1", "camicia2", "camicia3", "camicia4", "civile"][Math.floor(rnd() * 5)] : "divisa", sotto = civile ? (rnd() < 0.6 ? "jeans" : "civile2") : "divisa2";
    const pelvi = nodo(g, 0, 0.97, 0); pz(pelvi, "sfera", sotto, 0.34, 0.24, 0.22, 0, 0, 0);
    const busto = nodo(pelvi, 0, 0.07, 0); pz(busto, "sfera", sopra, 0.3, 0.3, 0.21, 0, 0.13, 0); pc(busto, 0.15, 0.14, sopra, 0, 0.33, 0, 1.28, 0.78);
    if (!civile) pz(busto, "box", "giubbotto", 0.37, 0.3, 0.27, 0, 0.31, 0);
    const collo = nodo(busto, 0, 0.51, 0); pc(collo, 0.048, 0.05, pelle, 0, 0.03, 0);
    const testa = nodo(collo, 0, 0.08, 0); pz(testa, "sfera", pelle, 0.19, 0.235, 0.215, 0, 0.11, 0.005);
    if (!civile) pz(testa, "sfera", "divisa", 0.235, 0.16, 0.255, 0, 0.17, -0.005); else pz(testa, "sfera", "capelli", 0.2, 0.13, 0.22, 0, 0.17, -0.02);
    const braccio = s => { const sh = nodo(busto, s * 0.2, 0.44, 0); pc(sh, 0.052, 0.2, sopra, 0, -0.14, 0); const el = nodo(sh, 0, -0.29, 0); pc(el, 0.044, 0.19, sopra, 0, -0.12, 0); pz(el, "sfera", pelle, 0.075, 0.1, 0.045, 0, -0.28, 0); return { sh, el }; };
    const gamba = s => { const hp = nodo(pelvi, s * 0.095, -0.04, 0); pc(hp, 0.075, 0.3, sotto, 0, -0.21, 0); const kn = nodo(hp, 0, -0.44, 0); pc(kn, 0.056, 0.3, sotto, 0, -0.2, 0); const an = nodo(kn, 0, -0.42, 0); pz(an, "box", civile && rnd() < 0.5 ? "civile2" : "gomma", 0.1, 0.08, 0.27, 0, -0.04, 0.05); return { hp, kn, an }; };
    const bL = braccio(1), bR = braccio(-1), gL = gamba(1), gR = gamba(-1);   // +x = sinistra della persona (guarda verso +z)
    const fucile = !civile && rnd() < 0.7; if (fucile) pz(busto, "box", "gomma", 0.05, 0.07, 0.92, 0.03, 0.3, 0.2, -0.2, 0.55, 0);   // portato in diagonale davanti al petto
    g.userData.j = { pelvi, busto, collo, testa, sh: [bL.sh, bR.sh], el: [bL.el, bR.el], hp: [gL.hp, gR.hp], kn: [gL.kn, gR.kn], an: [gL.an, gR.an], fucile, h };
    g.userData.arti = [gL.hp, gR.hp, bL.sh, bR.sh]; g.traverse(o => { o.userData.pod = true; }); return g;
  }
  /* animazione procedurale: andatura dal passo alla corsa (anche, ginocchia, caviglie, braccia, rotazione del busto, oscillazione),
     zoppia, strisciare, abbassarsi e coprirsi la testa, accovacciarsi, crollo e posa dei caduti; passaggi morbidi tra gli stati */
  function animaPersona(q, dt) {
    const o = q.obj, j = o.userData.j; if (!j) return; const t = (q.tt = (q.tt || 0) + dt), v = q.v, lerp = (a, b, k) => a + (b - a) * k;
    const T = { pelY: 0.97, pelRx: 0, pelRy: 0, pelRz: 0, bRx: 0.03, bRy: 0, bRz: 0, nRx: 0, nRy: 0, hpLx: 0, hpLz: 0.03, hpRx: 0, hpRz: -0.03, knL: 0.06, knR: 0.06, anL: 0, anR: 0, shLx: 0.04, shLz: 0.09, shRx: 0.04, shRz: -0.09, elL: -0.18, elR: -0.18, rRx: 0, rRz: 0, lift: 0 };
    let lab;
    if (!q.vivo) { const dm = t - (q.tMorte || 0); if (dm < 0.38) { lab = "cede"; Object.assign(T, { pelY: 0.62, hpLx: -1.0, hpRx: -0.75, knL: 1.5, knR: 1.25, anL: -0.4, anR: -0.4, bRx: 0.45, shLx: -0.3, shRx: -0.6, shLz: 0.4, shRz: -0.3, elL: -0.4, elR: -0.3, nRx: 0.35 }); } else { lab = "morto"; Object.assign(T, q.posa); } }
    else if (q.ferita === "striscia" || q.stato === "terra") {
      lab = "terra"; const cr = q.ferita === "striscia" && v > 0.05; q.fase += dt * 2 * Math.PI * (cr ? 0.55 : 0); const s = Math.sin(q.fase), m = cr ? 1 : 0;
      Object.assign(T, { rRx: 1.5, lift: 0.12, pelY: 0.97, nRx: -0.55, shLx: -2.6 - 0.55 * s * m, shRx: -2.6 + 0.55 * s * m, shLz: 0.25, shRz: -0.25, elL: -0.5 - 0.7 * Math.max(0, s) * m, elR: -0.5 - 0.7 * Math.max(0, -s) * m,
        hpLx: 0.05, hpRx: 0.05, hpLz: 0.1 + 0.35 * Math.max(0, -s) * m, hpRz: -0.1 - 0.35 * Math.max(0, s) * m, knL: 0.15 + 1.2 * Math.max(0, -s) * m, knR: 0.15 + 1.2 * Math.max(0, s) * m, anL: 0.4, anR: 0.4, rRz: 0.08 * s * m, bRy: 0.06 * s * m });
    }
    else if (q.stato === "reazione") { lab = "riparati"; Object.assign(T, { pelY: 0.62, hpLx: -1.1, hpRx: -1.0, knL: 1.7, knR: 1.6, anL: -0.6, anR: -0.6, bRx: 0.65, nRx: 0.35, shLx: -2.7, shRx: -2.7, shLz: 0.45, shRz: -0.45, elL: -2.2, elR: -2.2 }); }
    else if (q.stato === "riparo") { lab = "accovacciato"; const r = 0.03 * Math.sin(t * 1.3); Object.assign(T, { pelY: 0.5, hpLx: -1.55, hpRx: -1.35, hpLz: 0.15, hpRz: -0.1, knL: 2.25, knR: 2.0, anL: -0.75, anR: -0.6, bRx: 0.5 + r, nRx: -0.25, nRy: 0.5 * Math.sin(t * 0.4 + q.fase), shLx: -0.55, shRx: -0.45, shLz: -0.1, shRz: 0.1, elL: -1.3, elR: -1.2 }); }
    else {   // in piedi: fermo, cammina, corre (anche zoppicando)
      const zop = q.ferita === "zoppica", w = clamp(v / 1.4, 0, 1), r = clamp((v - 2.2) / 2.4, 0, 1); lab = zop ? "zoppica" : "piedi";
      q.fase += dt * 2 * Math.PI * (v < 0.05 ? 0 : v < 2.2 ? 0.72 + 0.3 * v : 1.12 + 0.24 * v); const s = Math.sin(q.fase), c = Math.cos(q.fase);
      const Ah = lerp(0.42, 0.86, r) * w, Ak = lerp(0.62, 1.75, r) * w, kst = lerp(0.07, 0.26, r) * w, As = lerp(0.3, 0.68, r) * w, el0 = lerp(0.22, 1.45, r), el1 = lerp(0.25, 0.3, r) * w;
      const lean = lerp(0.04, 0.3, r) * w, bob = lerp(0.025, 0.065, r) * w, tw = lerp(0.07, 0.14, r) * w;
      Object.assign(T, { hpLx: -Ah * s, hpRx: Ah * s, knL: kst + Ak * Math.pow(Math.max(0, c), 1.3), knR: kst + Ak * Math.pow(Math.max(0, -c), 1.3), pelY: 0.97 - bob * Math.abs(s) - 0.04 * r, pelRy: -tw * s, pelRz: 0.04 * s * w, bRy: tw * 1.25 * s, bRx: 0.03 + lean,
        shLx: As * s, shRx: -As * s, shLz: 0.08 + 0.05 * r, shRz: -0.08 - 0.05 * r, elL: -(el0 + el1 * Math.max(0, -s)), elR: -(el0 + el1 * Math.max(0, s)), nRx: -lean * 0.6 });
      T.anL = -(T.hpLx + T.knL) * 0.7 + 0.1 * Math.max(0, -c) * w; T.anR = -(T.hpRx + T.knR) * 0.7 + 0.1 * Math.max(0, c) * w;
      if (w < 0.25) {   // fermo: sposta il peso da una gamba all'altra e si guarda intorno
        if (!q.sguardoT || t > q.sguardoT) { q.sguardoT = t + 2 + Math.random() * 5; q.sguardo = (Math.random() - 0.5) * 1.6; }
        const sw = Math.sin(t * 0.7 + q.fase); T.pelRz = 0.04 * sw; T.hpLz = 0.03 + 0.03 * sw; T.hpRz = -0.03 + 0.03 * sw; T.knL = 0.06 + 0.08 * Math.max(0, -sw); T.knR = 0.06 + 0.08 * Math.max(0, sw); T.nRy = q.sguardo; T.bRy = q.sguardo * 0.2;
      }
      if (j.fucile && !zop) { T.shLx = -0.55 + 0.06 * s * w; T.shLz = -0.35; T.elL = -1.5; T.shRx = -0.25 + 0.05 * s * w; T.shRz = 0.15; T.elR = -1.6; }   // fucile a due mani
      if (zop) {   // gamba destra ferita: rigida, appoggio breve, bacino che cede, busto inclinato, mano sinistra sulla ferita
        T.hpRx *= 0.55; T.knR = 0.05 + 0.2 * Ak * Math.max(0, -c); T.pelRz = 0.13 * s; T.bRz = -0.16 * s; T.pelY -= 0.03 * Math.max(0, -s); T.shLx = -0.45; T.shLz = -0.35; T.elL = -1.95; T.bRx += 0.12;
      }
    }
    if (lab !== q.lab) { q.lab = lab; q.trans = lab === "morto" ? 0.75 : 0.4; } q.trans = (q.trans || 0) - dt;
    const k = q.trans > 0 ? (lab === "morto" ? 5 : 8) : 40, cu = q.cur || (q.cur = Object.assign({}, T)), a = Math.min(1, dt * k); for (const f in T) cu[f] += (T[f] - cu[f]) * a;
    j.pelvi.position.y = cu.pelY; j.pelvi.rotation.set(cu.pelRx, cu.pelRy, cu.pelRz); j.busto.rotation.set(cu.bRx, cu.bRy, cu.bRz); j.collo.rotation.set(cu.nRx, cu.nRy, 0);
    j.hp[0].rotation.set(cu.hpLx, 0, cu.hpLz); j.hp[1].rotation.set(cu.hpRx, 0, cu.hpRz); j.kn[0].rotation.x = cu.knL; j.kn[1].rotation.x = cu.knR; j.an[0].rotation.x = cu.anL; j.an[1].rotation.x = cu.anR;
    j.sh[0].rotation.set(cu.shLx, 0, cu.shLz); j.sh[1].rotation.set(cu.shRx, 0, cu.shRz); j.el[0].rotation.x = cu.elL; j.el[1].rotation.x = cu.elR;
    const yT = Math.atan2(q.dir.x, q.dir.z); if (q.yaw == null) q.yaw = yT; if (q.vivo && !(lab === "terra" && v < 0.05)) { const d = Math.atan2(Math.sin(yT - q.yaw), Math.cos(yT - q.yaw)); q.yaw += d * Math.min(1, dt * (v > 2 ? 5 : 3)); }
    o.position.set(q.pos.x, q.pos.y + cu.lift * j.h, q.pos.z); o.rotation.set(cu.rRx, q.yaw, cu.rRz); o.scale.setScalar(j.h);
  }
  function bomba() { const g = new THREE.Group(); pz(g, "cil", "bomba", 0.36, 3.0, 0.36, 0, 0, 0, Math.PI / 2, 0, 0); pz(g, "cono", "bomba", 0.3, 0.6, 0.3, 0, 0, 1.8, Math.PI / 2, 0, 0); for (let i = 0; i < 4; i++) pz(g, "box", "bomba", 0.04, 0.9, 0.7, 0, 0, -1.3, 0, 0, i * Math.PI / 2).position.set(Math.sin(i * Math.PI / 2) * 0.35, Math.cos(i * Math.PI / 2) * 0.35, -1.3); return g; }

  /* ---------- siti: composizione per tipo di bersaglio (seme fisso: stesso aspetto a ogni apertura) ---------- */
  function seme(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return () => { h += 0x6D2B79F5; let t = h; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function tipoSito(t, sam) {
    if (sam) return "sam";
    const c = String(t.categoria || "").toLowerCase(), n = (String(t.nome || "") + " " + String(t.descrizione || "")).toLowerCase();
    if (/sam|sa-\d|s-300|s-400/.test(c) || t.sam) return "sam";
    if (/elicott|helo/.test(c + n)) return "elicotteri";
    if (/aeroporto|caccia|airport|air base|aerodrom|base aerea|airfield/.test(c + " " + n)) return "aeroporto";
    if (/hangar/.test(c)) return "hangar"; if (/radar|guerra elettronica|ew\b/.test(c)) return /guerra/.test(c) ? "ew" : "radar";
    if (/deposit|carbur|fuel|munizion|serbato/.test(c + " " + n)) return "deposito"; if (/ponte|bridge/.test(c + " " + n)) return "ponte";
    if (/convogl|convoy|colonna/.test(c + " " + n)) return "convoglio"; if (/nave|ship|porto|harbor|fregata|corvetta/.test(c + " " + n)) return "nave";
    if (/ferrov|rail|treno|scalo/.test(c + " " + n)) return "ferrovia"; if (/lanciator|iskander|tel\b|missil/.test(c + " " + n)) return "lanciatore";
    if (/c2|comando|command|hq|quartier|controllo/.test(c + " " + n)) return "c2"; if (/radar/.test(n)) return "radar";
    return "generico";
  }
  function componi(kind, rnd) {
    const g = new THREE.Group(); const items = []; const ang = rnd() * Math.PI * 2; const ca = Math.cos(ang), sa = Math.sin(ang);
    const rot = (x, z) => [x * ca - z * sa, x * sa + z * ca];
    const add = (obj, lx, lz, ry, tipo, dmpi, extra) => { const [x, z] = rot(lx, lz); obj.position.set(x, 0, z); obj.rotation.y = ang + (ry || 0); g.add(obj); const it = Object.assign({ obj, x, z, tipo, dmpi: dmpi !== false, vivo: true, ris: 0 }, extra || {}); items.push(it); return it; };
    const decor = (obj, lx, lz, ry) => add(obj, lx, lz, ry, "decor", false, { decor: true });
    const camionVari = (n, x0, z0, dx, dz, ry) => { for (let i = 0; i < n; i++) add(rnd() < 0.3 ? camion("cisterna") : camion("cargo"), x0 + i * dx, z0 + i * dz, ry || 0, "camion", i < 2); };
    if (kind === "sam") {
      for (let i = 0; i < 4; i++) { const a = (i - 1.5) * 0.6; const x = Math.sin(a) * 115, z = Math.cos(a) * 115; decor(argine(9, 18, 2.6), x, z, a + Math.PI); add(tel(true), x, z, a + Math.PI, "tel"); }
      add(radarFlapLid(), 0, 0, 0, "radar"); add(generatore(), 15, -12, 1.2, "gen"); add(camion("comando"), -17, 9, -0.6, "posto comando");
      add(radarBigBird(), 0, -270, 0, "radar"); add(generatore(), 20, -270, 0.3, "gen"); camionVari(3, -50, -70, -14, 0, 0.2);
    } else if (kind === "lanciatore") {
      for (let i = 0; i < 3; i++) { decor(argine(9, 18, 2.6), -70 + i * 70, 0, 0); add(tel(rnd() < 0.5, true), -70 + i * 70, 0, 0, "tel"); }
      camionVari(3, -40, -60, 28, 0, Math.PI / 2); add(camion("comando"), 60, -55, 0.4, "posto comando");
    } else if (kind === "radar") {
      add(radarBigBird(), 0, 0, 0, "radar"); decor(argine4(34, 2.8), 0, 0, 0); add(radarP18(), 85, 30, 0.5, "radar"); add(radarFlapLid(), -80, 40, -0.3, "radar");
      add(generatore(), 25, -30, 0.2, "gen"); add(generatore(), -30, -35, 0.1, "gen"); add(edificio(14, 9, 3.6, rnd), 10, -70, 0, "edificio"); camionVari(2, -60, -80, 14, 0, 0);
    } else if (kind === "ew") {
      for (let i = 0; i < 4; i++) { const c = camion("comando"); pz(c, "cil", "antenna", 0.25, 16, 0.25, 0, 11, -2.5); pz(c, "box", "antenna", 3, 0.2, 0.2, 0, 18.5, -2.5); add(c, -60 + i * 40, (i % 2) * 25, 0.2 * i, "ew"); }
      add(generatore(), 0, -45, 0, "gen"); add(generatore(), 30, -45, 0, "gen"); add(radarP18(), -10, 70, 0, "radar");
    } else if (kind === "c2") {
      add(edificio(44, 24, 12, rnd), 0, 0, 0, "edificio"); add(edificio(24, 14, 7, rnd), 58, 8, 0, "edificio"); add(edificio(22, 16, 6, rnd, "mattone"), -55, -12, 0, "edificio"); add(edificio(30, 12, 4, rnd, "capannone"), 12, -52, 0, "edificio");
      [[-25, 30], [30, 32], [70, -30]].forEach(([x, z], i) => { const m = new THREE.Group(); pz(m, "cil", "antenna", 0.35, 28 + i * 4, 0.35, 0, 14 + i * 2, 0); pz(m, "box", "antenna", 0.1, 3, 1.4, 0, 26 + i * 4, 0); add(m, x, z, 0, "antenna", i === 0); });
      add(generatore(), -30, 40, 0, "gen"); add(camion("comando"), 40, 45, 0.3, "posto comando"); for (let i = 0; i < 7; i++) add(auto(rnd), -45 + i * 3.2, 48, Math.PI / 2, "auto", false);
    } else if (kind === "aeroporto" || kind === "hangar") {
      // il punto del bersaglio di un aeroporto cade di solito sulla pista: piazzale, ricoveri e torre stanno di lato
      const nS = kind === "hangar" ? 0 : 5; for (let i = 0; i < nS; i++) add(shelter(), -130 + i * 62, 340, Math.PI, "shelter");
      if (kind === "hangar") for (let i = 0; i < 3; i++) add(hangar(), -80 + i * 80, 300, Math.PI, "hangar");
      for (let i = 0; i < 8; i++) add(jet(i % 3 ? "jet" : "jetScuro"), -150 + i * 38, 215, Math.PI, "velivolo", i < 6);
      add(torre(), 200, 250, 0, "torre"); add(edificio(40, 18, 8, rnd), 170, 310, 0, "edificio"); camionVari(3, -150, 175, 30, 0, Math.PI / 2);
      for (let i = 0; i < 2; i++) add(camion("cisterna"), 120 + i * 14, 175, 0, "camion");
    } else if (kind === "elicotteri") {
      for (let i = 0; i < 6; i++) add(elicottero(), -90 + i * 34, 30 + (i % 2) * 6, Math.PI, "elicottero");
      add(hangar(), 30, 120, Math.PI, "hangar"); add(camion("cisterna"), -60, -20, Math.PI / 2, "camion"); add(camion("cargo"), -40, -20, Math.PI / 2, "camion"); add(edificio(20, 12, 5, rnd), 90, -30, 0, "edificio");
    } else if (kind === "deposito") {
      for (let i = 0; i < 6; i++) { const x = -60 + (i % 3) * 52, z = -30 + Math.floor(i / 3) * 56; decor(argine4(36, 2.4), x, z, 0); add(serbatoio(12 + rnd() * 3, 9 + rnd() * 3), x, z, 0, "serbatoio"); }
      add(edificio(56, 22, 9, rnd, "capannone"), 20, 90, 0, "edificio"); add(edificio(40, 20, 8, rnd, "capannone"), -55, 92, 0, "edificio"); camionVari(4, -70, 140, 14, 0, Math.PI / 2);
    } else if (kind === "convoglio") {
      for (let i = 0; i < 11; i++) { const z = 140 - i * 28, x = Math.sin(i * 0.25) * 12; add(i % 3 === 1 ? carro() : camion(i % 4 === 0 ? "cisterna" : "cargo"), x, z, -Math.cos(i * 0.25) * 0.1, "veicolo"); }
    } else if (kind === "nave") {
      add(nave(), 0, 0, 0, "nave"); if (rnd() < 0.7) add(nave(), 45, -110, 0.08, "nave");
    } else if (kind === "ferrovia") {
      add(loco(), 0, 150, 0, "locomotiva"); for (let i = 0; i < 10; i++) add(vagone(i % 3 === 0), 0, 132 - i * 14.6, 0, "vagone", i < 6);
      add(edificio(30, 12, 6, rnd, "mattone"), 25, 60, 0, "edificio"); camionVari(2, 40, 20, 0, 14, 0);
    } else if (kind === "ponte") {
      for (let i = 0; i < 4; i++) add(i % 2 ? carro() : camion("cargo"), 0, -45 + i * 28, 0, "veicolo"); for (let i = 0; i < 3; i++) add(auto(rnd), 2.5, 70 + i * 9, Math.PI, "auto", false);
    } else {
      add(edificio(34, 18, 9, rnd), 0, 0, 0, "edificio"); add(edificio(46, 20, 8, rnd, "capannone"), 60, 20, 0, "edificio"); add(edificio(20, 14, 6, rnd, "mattone"), -50, -25, 0, "edificio"); add(edificio(26, 12, 5, rnd), 10, -55, 0, "edificio");
      camionVari(4, -60, 50, 14, 0, Math.PI / 2); add(generatore(), 40, -40, 0, "gen"); for (let i = 0; i < 5; i++) add(auto(rnd), 75 + i * 3.2, -35, Math.PI / 2, "auto", false);
    }
    g.traverse(o => { o.userData.pod = true; });
    return { g, items };
  }

  /* ---------- gestione dei siti (bersagli e batterie SAM) ---------- */
  function sitiInit() {
    tavolozza(); geometrie();
    if (H.motore) {   // vista 3D della missione: siti creati qui dai bersagli e dalle batterie del motore
      const eng = H.motore(); const sc = H.scene(); const conSam = new Set();
      eng.sam.forEach(s => { const c = componi("sam", seme("sam" + s.id)); sc.add(c.g); S.siti.push({ id: s.id, nome: s.nome || "SA-10", kind: "sam", g: c.g, items: c.items, ref: s, sam: true, pos: V3(), nuovo: true }); });
      eng.target.forEach(t => { if (t.sam && eng.sam.some(s => s.id === t.sam)) { conSam.add(t.id); return; } const k = tipoSito(t); if (k === "sam" && eng.sam.length) { const vic = eng.sam.map(s => ({ s, d: Math.hypot(s.lat - t.lat, s.lon - t.lon) })).sort((a, b) => a.d - b.d)[0]; if (vic && vic.d < 0.02) { conSam.add(t.id); return; } }
        const c = componi(k, seme(t.id)); sc.add(c.g); S.siti.push({ id: t.id, nome: t.nome, kind: k, g: c.g, items: c.items, ref: t, pos: V3(), nuovo: true }); });
      S.alias = {}; eng.target.filter(t => conSam.has(t.id)).forEach(t => { let s = t.sam; if (!s) { const v = eng.sam.map(x => ({ x, d: Math.hypot(x.lat - t.lat, x.lon - t.lon) })).sort((a, b) => a.d - b.d)[0]; s = v ? v.x.id : null; } if (s) S.alias[t.id] = s; });
    }
    S.sitiPronti = true; sitiAggiorna(0, true);
  }
  // volo libero: i siti del volo (S.terra) ricevono i modelli dettagliati; quelli grezzi originali vengono nascosti
  function sitiVolo() {
    const lista = H.siti ? H.siti() : []; if (!lista) return;
    lista.forEach(t => {
      if (t._pod || !t.obj) return; const sc0 = H.bersaglioScenario ? H.bersaglioScenario(t.id) : null; const k = t.sotto === "sam" ? "sam" : tipoSito(sc0 || t);
      t.obj.children.forEach(ch => { ch.visible = false; }); const c = componi(k, seme(String(t.id))); t.obj.add(c.g); t._pod = true;
      S.siti.push({ id: t.id, nome: t.nome, kind: k, g: c.g, items: c.items, ref: t, volo: true, pos: V3(), nuovo: true });
    });
  }
  const _rc = new THREE.Raycaster(), _ro = V3(), _rd = V3(0, -1, 0);
  function quotaVisiva(x, z) {   // quota della superficie disegnata (la tile più alta tra quelle visibili sotto il punto)
    const ter = S.cls && S.cls.terreno; if (!ter || !ter.length) return H.elev(x, z); const cand = [];
    for (const m of ter) { if (!m.visible || !m.parent) continue; let bb = m.userData.podBB; if (!bb) { const b = new THREE.Box3().setFromObject(m); bb = m.userData.podBB = [b.min.x, b.max.x, b.min.z, b.max.z]; } if (x >= bb[0] && x <= bb[1] && z >= bb[2] && z <= bb[3]) cand.push(m); }
    if (!cand.length) return H.elev(x, z); _rc.set(_ro.set(x, 30000, z), _rd); _rc.far = 60000; const h = _rc.intersectObjects(cand, false);
    return h.length ? h[0].point.y : H.elev(x, z);
  }
  function sitoVivo(s) { const r = s.ref; if (s.volo) return r.vivo !== false; if (s.sam) return !r.soppressa; return !r.distrutto; }
  function itemVivo(it) { return it && it.vivo && (!it.sito || sitoVivo(it.sito)); }
  const _w = V3();
  function posItem(it) { if (it.aereo) return it.aereo.pos; if (it.mobile) { if (it.cur && Math.abs(it.cur.rRx) > 0.7 && it.yaw != null) { const k = Math.sign(it.cur.rRx) * 0.85 * ((it.obj.userData.j || {}).h || 1); return it.pos.clone().add(V3(Math.sin(it.yaw) * k, 0.25, Math.cos(it.yaw) * k)); }   // a terra: centro del corpo
      return it.pos.clone().add(V3(0, it.tipo === "veicolo" ? 1.6 : 1.0, 0)); } it.obj.getWorldPosition(_w); return _w.clone().add(V3(0, it.tipo === "edificio" ? 4 : 2, 0)); }
  function sitiAggiorna(dt, forza) {
    if (!S.sitiPronti) return; const now = performance.now();
    if (H.motore) {
      S.siti.forEach(s => { const r = s.ref; const q = H.toXZ(r.lat, r.lon); s.pos.set(q.x, H.elev(q.x, q.z), q.z); s.g.position.copy(s.pos); s.g.visible = s.sam ? true : r.presente !== false; });
    } else { sitiVolo(); S.siti.forEach(s => { s.ref.obj.updateMatrixWorld(); s.pos.copy(s.ref.obj.position); }); }
    if (forza || now - S.sedeT > 2000) {   // prima sistemazione con il modello delle quote (le quote arrivano dopo l'apertura)
      S.sedeT = now; S.siti.forEach(s => { s.g.updateMatrixWorld(true); const gp = s.g.getWorldPosition(V3()); s.items.forEach(it => { it.sito = s; if (it.sedeRc && now - it.sedeRc < 12000) return; const y = H.elev(gp.x + it.x, gp.z + it.z); it.obj.position.y = (Number.isFinite(y) ? y : gp.y) - gp.y; }); });
    }
    // poi ogni elemento vicino alla linea di mira viene appoggiato sulla superficie davvero disegnata (maglia del terreno, anche HD),
    // con un raggio verticale: pochi elementi per fotogramma, così non ci sono scatti
    if (S.spi && S.cls) { let n = 0; for (const s of S.siti) { if (n >= 6) break; if (s.pos.distanceTo(S.spi) > 25000) continue; const gp = s.g.getWorldPosition(V3());
      for (const it of s.items) { if (n >= 6) break; if (it.sedeRc && now - it.sedeRc < 12000) continue; n++; it.sedeRc = now; const y = quotaVisiva(gp.x + it.x, gp.z + it.z); if (Number.isFinite(y)) it.obj.position.y = y - gp.y; } } }
    S.siti.forEach(s => { const v = sitoVivo(s); s.items.forEach(it => { const ud = it.obj.userData; if (ud.testa && v && it.vivo) ud.testa.rotation.y += dt * (ud.giri || 0.6); });
      // volo libero: il sito distrutto dal volo (materiali sostituiti) resta caldo nel FLIR e si raffredda in un paio di minuti
      if (s.volo && !v) { if (!s.mortoT) { s.mortoT = now; allarme(s, s.pos.clone()); s.items.forEach(it => { if (!it.decor) macerie(it.obj.getWorldPosition(V3()), it.tipo === "edificio" ? 14 : 6, it.tipo); }); s.caldi = []; s.g.traverse(o => { if (o.isMesh && o.material && o.material.emissive && !o.material.userData.podCaldo) { o.material.userData.podCaldo = true; s.caldi.push(o.material); TERMICI.add(o.material); } }); }
        const k = Math.exp(-(now - s.mortoT) / 90000); s.caldi.forEach((m, i) => { m.userData.calore = 0.12 + (i % 3 === 0 ? 0.85 : 0.5) * k; }); } });
  }

  /* ---------- immagini satellitari ad alta risoluzione proiettate sul terreno (solo nell'immagine del pod) ---------- */
  const DR = { pronto: false };
  function drapeInit() {
    if (DR.pronto) return; DR.pronto = true; const n = mobile() ? 4 : 6;
    const strato = () => { const c = document.createElement("canvas"); c.width = c.height = n * 256; const t = new THREE.CanvasTexture(c); t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter; t.anisotropy = 4; return { c, g: c.getContext("2d"), t, n, z: -1, tx: 0, ty: 0, token: 0, sporco: false, r: new THREE.Vector4(0, 0, 1, 1) }; };
    DR.A = strato(); DR.B = strato(); DR.on = { value: 0 };
    DR.u = { uDrA: { value: DR.A.t }, uDrAR: { value: DR.A.r }, uDrB: { value: DR.B.t }, uDrBR: { value: DR.B.r }, uDrOn: DR.on };
    DR.loader = new THREE.ImageLoader(); DR.loader.setCrossOrigin("anonymous");
  }
  const DRAPE_V = "varying vec3 vDrapeW;\n", DRAPE_F = "uniform sampler2D uDrA; uniform sampler2D uDrB; uniform vec4 uDrAR; uniform vec4 uDrBR; uniform float uDrOn; varying vec3 vDrapeW;\n" +
    "vec4 podDrape(sampler2D t, vec4 r){ vec2 uv = (vDrapeW.xz - r.xy) / r.zw; if (uv.x <= 0.0 || uv.y <= 0.0 || uv.x >= 1.0 || uv.y >= 1.0) return vec4(0.0); vec4 c = texture2D(t, vec2(uv.x, 1.0 - uv.y)); float e = min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y)); c.a *= smoothstep(0.0, 0.07, e); return c; }\n";
  function patchTerreno(m) {
    if (m.userData.podDrape) return; m.userData.podDrape = true; drapeInit();
    const prev = m.onBeforeCompile, base = THREE.Material.prototype.onBeforeCompile; const chiave = (m.customProgramCacheKey ? m.customProgramCacheKey() : "") + "|pod-drape";
    m.onBeforeCompile = function (sh, rr) {
      if (prev && prev !== base) prev.call(this, sh, rr);
      Object.assign(sh.uniforms, DR.u);
      sh.vertexShader = DRAPE_V + sh.vertexShader.replace("#include <project_vertex>", "#include <project_vertex>\n  vDrapeW = (modelMatrix * vec4(transformed, 1.0)).xyz;");
      sh.fragmentShader = DRAPE_F + sh.fragmentShader.replace("#include <map_fragment>", "#include <map_fragment>\n  if (uDrOn > 0.5) { vec4 dA = podDrape(uDrA, uDrAR); diffuseColor.rgb = mix(diffuseColor.rgb, pow(dA.rgb, vec3(2.2)), dA.a); vec4 dB = podDrape(uDrB, uDrBR); diffuseColor.rgb = mix(diffuseColor.rgb, pow(dB.rgb, vec3(2.2)), dB.a); }");
    };
    m.customProgramCacheKey = () => chiave; m.needsUpdate = true;
  }
  function tileXY(lat, lon, z) { const n = 2 ** z; const lr = lat * D2R; return { x: (lon + 180) / 360 * n, y: (1 - Math.log(Math.tan(lr) + 1 / Math.cos(lr)) / Math.PI) / 2 * n }; }
  function tileLat(y, z) { const n = Math.PI - 2 * Math.PI * y / 2 ** z; return R2D * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))); }
  function strato(L, z, lat, lon) {
    const t = tileXY(lat, lon, z); const tx = Math.floor(t.x) - Math.floor(L.n / 2) + (t.x % 1 >= 0.5 ? 1 : 0), ty = Math.floor(t.y) - Math.floor(L.n / 2) + (t.y % 1 >= 0.5 ? 1 : 0);
    if (L.z === z && Math.abs(t.x - (L.tx + L.n / 2)) < L.n * 0.3 && Math.abs(t.y - (L.ty + L.n / 2)) < L.n * 0.3) return;
    if (L.z === z && L.tx === tx && L.ty === ty) return;
    L.z = z; L.tx = tx; L.ty = ty; const tok = ++L.token; L.g.clearRect(0, 0, L.c.width, L.c.height); L.t.needsUpdate = true;
    const lonW = tx / 2 ** z * 360 - 180, lonE = (tx + L.n) / 2 ** z * 360 - 180, latN = tileLat(ty, z), latS = tileLat(ty + L.n, z);
    const a = H.toXZ(latN, lonW), b = H.toXZ(latS, lonE); L.r.set(a.x, a.z, b.x - a.x, b.z - a.z);
    const cx = t.x, cy = t.y; const lista = []; for (let i = 0; i < L.n; i++) for (let j = 0; j < L.n; j++) lista.push({ x: tx + i, y: ty + j, d: Math.hypot(tx + i + 0.5 - cx, ty + j + 0.5 - cy) }); lista.sort((p, q) => p.d - q.d);
    lista.forEach(p => { const url = (typeof VISTA3D !== "undefined" && VISTA3D.tileUrl) ? VISTA3D.tileUrl("img", z, p.x, p.y) : `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${p.y}/${p.x}`;
      const prova = (n) => DR.loader.load(url, img => { if (L.token !== tok || (z >= 17 && segnaposto(img))) return; L.g.drawImage(img, (p.x - tx) * 256, (p.y - ty) * 256, 256, 256); L.sporco = true; }, undefined, () => { if (n < 2 && L.token === tok) setTimeout(() => prova(n + 1), 800 * (n + 1)); });
      prova(0); });
  }
  // dove Esri non ha lo zoom richiesto restituisce un riquadro grigio uniforme con una scritta: non si disegna (resta lo strato meno dettagliato)
  function segnaposto(img) {
    try { const c = segnaposto.c || (segnaposto.c = document.createElement("canvas")); c.width = c.height = 24; const g = c.getContext("2d", { willReadFrequently: true }); g.drawImage(img, 0, 0, 24, 24); const d = g.getImageData(0, 0, 24, 24).data;
      let s = 0, s2 = 0, n = 0; for (let i = 0; i < d.length; i += 4) { const l = d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; s += l; s2 += l * l; n++; } const m = s / n, sd = Math.sqrt(Math.max(0, s2 / n - m * m)); return m > 190 && m < 245 && sd < 20; } catch (e) { return false; }
  }
  function drapeAggiorna(fovDeg, pxVideo) {
    drapeInit(); if (!S.spi || S.range <= 0) return; const ll = H.latLon(S.spi.x, S.spi.z); if (!Number.isFinite(ll.lat)) return;
    const W = 2 * S.range * Math.tan(fovDeg * D2R / 2); const texel = W / Math.max(256, pxVideo); const mpp0 = 156543.03 * Math.cos(ll.lat * D2R);
    const zB = clamp(Math.round(Math.log2(mpp0 / texel)), 14, 19), now = performance.now();
    // isteresi: il livello cambia solo se il nuovo valore resta stabile per 0,6 s (niente ricarichi continui durante lo zoom)
    if (DR.zB == null) DR.zB = zB; else if (zB !== DR.zB) { if (DR.zBc !== zB) { DR.zBc = zB; DR.zBt = now; } else if (now - DR.zBt > 600) DR.zB = zB; } else DR.zBc = null;
    strato(DR.B, DR.zB, ll.lat, ll.lon); strato(DR.A, DR.zB - 2, ll.lat, ll.lon);
    [DR.A, DR.B].forEach(L => { if (L.sporco) { L.sporco = false; L.t.needsUpdate = true; } });
  }

  /* ---------- classificazione della scena: cosa nascondere o modificare nell'immagine del pod ---------- */
  function classifica() {
    const c = { nasc: [], cielo: [], punti: [], nubi: [], lampi: [], terreno: [], luci: [] };
    H.scene().traverse(o => {
      if (o.isLight) { c.luci.push(o); return; }
      if (o.userData && o.userData.pod) { if (o.isSprite && o.material && o.material.blending === THREE.AdditiveBlending) c.lampi.push(o); return; }
      if (o.isLine || o.isLineSegments || o.isLineLoop) { c.nasc.push(o); return; }
      if (o.isPoints) { c.punti.push(o); return; }
      const m = o.material; if (!m || Array.isArray(m)) return;
      if (o.isSprite) { if (m.depthTest === false || o.scale.x > 5000) c.nasc.push(o); else if (m.blending === THREE.AdditiveBlending) c.lampi.push(o); return; }
      if (!o.isMesh) return; const g = o.geometry;
      if (m.side === THREE.BackSide && g) { if (!g.boundingSphere) g.computeBoundingSphere(); if (g.boundingSphere && g.boundingSphere.radius > 50000) { c.cielo.push(o); return; } }
      const par = g && g.parameters;
      if (m.isMeshBasicMaterial || m.isShaderMaterial) { if (m.isMeshBasicMaterial && par && (par.width || 0) > 50000) c.nubi.push(o); else if (m.transparent || (g && /Cone|Ring|Torus/.test(g.type))) c.nasc.push(o); return; }
      if (m.isMeshStandardMaterial && g && g.type === "PlaneGeometry" && par && par.width >= 300 && par.height >= 300) { c.terreno.push(o); patchTerreno(m); }
    });
    S.cls = c; S.clsT = performance.now();
  }
  // firme termiche: materiali della tavolozza + velivoli (scarichi caldissimi, cellula tiepida)
  const TERMICI = new Set();
  function marcaTermici() {
    Object.values(MAT).forEach(m => { if (m && m.isMaterial) TERMICI.add(m); });
    (H.aerei ? H.aerei() : []).forEach(a => { if (!a.obj) return; a.obj.traverse(o => { if (!o.isMesh || !o.material || Array.isArray(o.material)) return; const m = o.material; if (m.userData.calore == null && m.emissive) { const n = ((o.name || "") + " " + (m.name || "")).toLowerCase(); m.userData.calore = /nozzle|ugell|exhaust|afterburn|scarico|engine|motore/.test(n) ? 1 : 0.42; } if (m.userData.calore != null && m.emissive) TERMICI.add(m); }); });
  }

  /* ---------- passata di disegno del pod ---------- */
  const VS = "varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }";
  const FS_DOWN = "uniform sampler2D tS; varying vec2 vUv; void main(){ vec3 c = texture2D(tS, vUv).rgb; float l = max(1e-6, dot(c, vec3(0.2126, 0.7152, 0.0722))); gl_FragColor = vec4(clamp((log2(l) + 16.0) / 20.0, 0.0, 1.0), 0.0, 0.0, 1.0); }";
  const FS_POST = [
    "uniform sampler2D tS; uniform vec2 uRes; uniform float uLo, uHi, uModo, uT, uRum, uSfoc, uPix, uMask, uShim;",
    "varying vec2 vUv;",
    "float h21(vec2 p){ p = fract(p * vec2(443.897, 441.423)); p += dot(p, p.yx + 19.19); return fract((p.x + p.y) * p.x); }",
    "float lum(vec2 uv){ vec3 c = texture2D(tS, clamp(uv, 0.001, 0.999)).rgb; return max(1e-6, dot(c, vec3(0.2126, 0.7152, 0.0722))); }",
    "float agc(float l){ return (log2(l) - uLo) / max(0.3, uHi - uLo); }",
    "void main(){",
    "  vec2 uv = vUv;",
    "  uv += vec2(sin(uv.y * 90.0 + uT * 7.0), cos(uv.x * 80.0 + uT * 6.0)) * uShim * 0.0012;",
    "  if (uPix > 1.0) { vec2 g = uRes / uPix; uv = (floor(uv * g) + 0.5) / g; }",
    "  vec2 px = uPix / uRes; float r = 1.0 + uSfoc * 6.0;",
    "  float c = lum(uv);",
    "  float n4 = lum(uv + vec2(px.x, 0.0) * r) + lum(uv - vec2(px.x, 0.0) * r) + lum(uv + vec2(0.0, px.y) * r) + lum(uv - vec2(0.0, px.y) * r);",
    "  float bl = mix(c, n4 * 0.25, 0.28 + 0.72 * uSfoc);",
    "  float wd = 0.0; for (int i = 0; i < 8; i++) { float a = float(i) * 0.7853982; wd += lum(uv + vec2(cos(a), sin(a)) * px * 7.0 * r); } wd *= 0.125;",
    "  float v = agc(bl), vw = agc(wd);",
    "  if (uModo < 1.5) { v = v + (v - vw) * 0.5 + max(0.0, vw - 0.82) * 0.35; v = pow(clamp(v, 0.0, 1.0), 0.92); if (uModo > 0.5) v = 1.0 - v; }",
    "  else { v = v + (v - vw) * 0.25; v = pow(clamp(v, 0.0, 1.0), 0.85); }",
    "  vec2 cell = floor(uv * uRes / max(1.0, uPix * 0.5));",
    "  v += (h21(cell + vec2(floor(uT * 30.0) * 7.31, floor(uT * 30.0) * 3.17)) - 0.5) * uRum;",
    "  v += (h21(vec2(floor(uv.x * uRes.x), 3.7)) - 0.5) * (uModo < 1.5 ? 0.016 : 0.004);",
    "  vec2 d = vUv - 0.5; v *= 1.0 - 0.32 * dot(d, d) * 2.0;",
    "  v = mix(v, 0.1 + 0.08 * h21(cell + floor(uT * 24.0)), uMask);",
    "  gl_FragColor = vec4(vec3(clamp(v, 0.0, 1.0)), 1.0);",
    "}"].join("\n");
  function risorse(rend) {
    if (R && R.rend === rend) return R;
    if (R) { try { R.rt.dispose(); R.rtS.dispose(); R.post.dispose(); R.down.dispose(); } catch (e) {} }
    // 8 bit: sui render target in virgola mobile gli sprite trasparenti (fumo, fiamme, esplosioni) non superano il test di profondità;
    // la precisione notturna si recupera alzando la luce della scena durante la passata infrarossa (guadagno del sensore)
    const rt = new THREE.WebGLRenderTarget(16, 16, { type: THREE.UnsignedByteType, depthBuffer: true, stencilBuffer: false, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
    rt.texture.generateMipmaps = false;
    const rtS = new THREE.WebGLRenderTarget(32, 32, { type: THREE.UnsignedByteType, depthBuffer: false, stencilBuffer: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter }); rtS.texture.generateMipmaps = false;
    const geo = new THREE.PlaneGeometry(2, 2);
    const post = new THREE.ShaderMaterial({ uniforms: { tS: { value: rt.texture }, uRes: { value: V2(16, 16) }, uLo: { value: -5 }, uHi: { value: 1 }, uModo: { value: 0 }, uT: { value: 0 }, uRum: { value: 0.04 }, uSfoc: { value: 0 }, uPix: { value: 1 }, uMask: { value: 0 }, uShim: { value: 0 } }, vertexShader: VS, fragmentShader: FS_POST, depthTest: false, depthWrite: false, toneMapped: false });
    const down = new THREE.ShaderMaterial({ uniforms: { tS: { value: rt.texture } }, vertexShader: VS, fragmentShader: FS_DOWN, depthTest: false, depthWrite: false, toneMapped: false });
    const scP = new THREE.Scene(), scD = new THREE.Scene(); const mP = new THREE.Mesh(geo, post), mD = new THREE.Mesh(geo, down); mP.frustumCulled = mD.frustumCulled = false; scP.add(mP); scD.add(mD);
    R = { rend, rt, rtS, post, down, scP, scD, oc: new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), buf: new Uint8Array(32 * 32 * 4), w: 0, h: 0 };
    return R;
  }
  const NERO = new THREE.Color(0x000000);
  function preparaPassata(ir, notte) {
    const now = performance.now(); if (!S.cls || now - S.clsT > 1500) classifica(); if (!S.aereiT || now - S.aereiT > 2500) { S.aereiT = now; marcaTermici(); }
    const c = S.cls, sc = H.scene(), sv = S.salva = { vis: [], col: [], em: [], bg: sc.background, fog: sc.fog ? [sc.fog.near, sc.fog.far, sc.fog.color.clone(), sc.fog.density] : null };
    const nascondi = o => { if (o.visible) { o.visible = false; sv.vis.push(o); } };
    c.nasc.forEach(nascondi); if (ir) { c.cielo.forEach(nascondi); c.punti.forEach(nascondi); }
    const pr = H.proprio && H.proprio(); if (pr) nascondi(pr);
    if (ir) {
      c.nubi.forEach(o => { sv.col.push([o.material, o.material.color.clone()]); o.material.color.multiplyScalar(0.12); });
      c.lampi.forEach(o => { if (o.visible) { sv.col.push([o.material, o.material.color.clone()]); o.material.color.multiplyScalar(4); } });
      // di notte la scena è molto scura: si alza la luce (come il guadagno del sensore) per non perdere precisione a 8 bit
      const gn = notte ? 10 : 1; if (gn !== 1) c.luci.forEach(l => { sv.luci = sv.luci || []; sv.luci.push([l, l.intensity]); l.intensity *= gn; });
      // firma termica rispetto alla luce della scena
      const kh = (notte ? 0.06 : 1.25) * gn, fl = 0.92 + Math.random() * 0.08;
      TERMICI.forEach(m => { if (!m.emissive) return; sv.em.push([m, m.emissive.clone(), m.emissiveIntensity]); m.emissive.setScalar(m.userData.calore * kh * fl); m.emissiveIntensity = 1; });
      sc.background = NERO;
      // l'infrarosso termico attraversa la foschia meglio del visibile
      if (sc.fog) { if (sc.fog.isFogExp2) sc.fog.density = sv.fog[3] / 2.5; else { sc.fog.near = Math.max(4000, sv.fog[0] * 2.5); sc.fog.far = Math.max(30000, sv.fog[1] * 2.5); } sc.fog.color.setScalar(notte ? 0.004 : 0.06); }
    }
    if (DR.pronto) DR.on.value = 1;
  }
  function ripristina() {
    const sv = S.salva; if (!sv) return; const sc = H.scene();
    sv.vis.forEach(o => { o.visible = true; }); sv.col.forEach(([m, c]) => m.color.copy(c)); if (sv.luci) sv.luci.forEach(([l, i]) => { l.intensity = i; }); sv.em.forEach(([m, e, i]) => { m.emissive.copy(e); m.emissiveIntensity = i; });
    sc.background = sv.bg; if (sv.fog && sc.fog) { if (sc.fog.isFogExp2) sc.fog.density = sv.fog[3]; else { sc.fog.near = sv.fog[0]; sc.fog.far = sv.fog[1]; } sc.fog.color.copy(sv.fog[2]); }
    if (DR.pronto) DR.on.value = 0; S.salva = null;
  }
  function agc(buf) {
    const hist = new Uint32Array(256); let n = 0; for (let i = 0; i < buf.length; i += 4) { const v = buf[i]; if (v > 26) { hist[v]++; n++; } }
    if (n < 40) return; const pc = q => { let acc = 0; const lim = n * q; for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc >= lim) return i; } return 255; };
    const ir = S.modo < 2; let lo = pc(ir ? 0.01 : 0.02) / 255 * 20 - 16, hi = pc(ir ? 0.995 : 0.985) / 255 * 20 - 16; S.agc.alto = hi;
    const minR = ir ? 1.7 : 3.4; if (hi - lo < minR) { const m = (hi + lo) / 2; lo = m - minR / 2; hi = m + minR / 2; }
    if (!ir) { const minHi = Math.log2(0.35); if (hi < minHi) { lo += minHi - hi; hi = minHi; } }   // la TV non amplifica oltre un limite: di notte resta scura e rumorosa
    S.agc.tlo = lo - 0.12; S.agc.thi = hi + 0.12;
  }
  function rettangolo(ho) {
    const rend = H.renderer(); const cv = rend.domElement; const cr = cv.getBoundingClientRect(); const r = ho.ui.vid.getBoundingClientRect();
    if (r.width < 20 || r.height < 20) return null; return { left: r.left, top: r.top, w: r.width, h: r.height, x: r.left - cr.left, yb: cr.bottom - r.bottom };
  }
  function rendi(ho, dt) {
    const rend = H.renderer(); const sc = H.scene(); const r = rettangolo(ho); S.rect = r; if (!r || !S.spi) return;
    const res = risorse(rend); const dpr = rend.getPixelRatio(); const max = mobile() ? 640 : 1024;
    let w = Math.round(r.w * dpr), h = Math.round(r.h * dpr); const k = Math.min(1, max / Math.max(w, h)); w = Math.max(64, Math.round(w * k)); h = Math.max(64, Math.round(h * k));
    if (res.w !== w || res.h !== h) { res.rt.setSize(w, h); res.w = w; res.h = h; res.post.uniforms.uRes.value.set(w, h); }
    const campo = CAMPI[S.campo]; const asp = r.w / r.h; const cam = S.cam;
    cam.fov = 2 * Math.atan(Math.tan(campo.deg * D2R / 2) / Math.max(1, asp)) * R2D; cam.aspect = asp; cam.near = 2; cam.far = Math.max(60000, S.range * 3); cam.position.copy(S.pos);
    const pf = S.pf; let up = V3(0, 1, 0); if (Math.abs(S.dir.y) > 0.985 && pf) { up = V3(0, 0, 1).applyQuaternion(pf.Q); up.y = 0; if (up.lengthSq() < 1e-6) up.set(0, 0, -1); up.normalize(); }
    cam.up.copy(up); cam.lookAt(S.spi);
    const j = (0.000012 + (pf && pf.nz ? Math.max(0, pf.nz - 1) * 0.00001 : 0)) * (S.track === "RATES" ? 2 : 1); cam.rotateX((Math.random() - 0.5) * j); cam.rotateY((Math.random() - 0.5) * j);
    cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    drapeAggiorna(campo.deg, Math.max(w, h));
    const ir = S.modo < 2, notte = !!(H.notte && H.notte());
    const prevRT = rend.getRenderTarget(), prevAC = rend.autoClear, smA = rend.shadowMap.autoUpdate;
    preparaPassata(ir, notte);
    try { rend.shadowMap.autoUpdate = false; rend.autoClear = true; rend.setRenderTarget(res.rt); rend.clear(); rend.render(sc, cam); }
    finally { ripristina(); }
    if ((S.fn = S.fn + 1) % 4 === 0) { try { rend.setRenderTarget(res.rtS); rend.render(res.scD, res.oc); rend.readRenderTargetPixels(res.rtS, 0, 0, 32, 32, res.buf); agc(res.buf); } catch (e) {} }
    rend.setRenderTarget(prevRT);
    const a = S.agc, ka = Math.min(1, dt * (ir ? 3.2 : 2.2)); a.lo += (a.tlo - a.lo) * ka; a.hi += (a.thi - a.hi) * ka;
    const u = res.post.uniforms; u.uLo.value = a.lo; u.uHi.value = a.hi; u.uModo.value = S.modo; u.uT.value = performance.now() / 1000;
    const buio = clamp((Math.log2(0.35) - a.alto) / 3, 0, 1); u.uRum.value = ir ? 0.03 + clamp(2.2 - (a.hi - a.lo), 0, 1) * 0.03 : 0.018 + buio * 0.3;
    S.sfoc = Math.max(0, S.sfoc - dt * 2.6); u.uSfoc.value = S.sfoc; u.uPix.value = campo.exp; u.uMask.value = clamp(S.maschera, 0, 1);
    // tremolio dell'aria: si nota di più quanto più stretto è il campo (super narrow) e a bassa quota sulle lunghe distanze
    u.uShim.value = pf ? clamp(S.range / 30000, 0, 1) * clamp(1 - (S.pos.y - S.spi.y) / 6000, 0, 1) * (notte ? 0.4 : 1) * clamp(1 / campo.deg, 0.3, 3) : 0;
    const sz = rend.getSize(V2(0, 0));
    rend.setViewport(r.x, r.yb, r.w, r.h); rend.setScissor(r.x, r.yb, r.w, r.h); rend.setScissorTest(true); rend.autoClear = true;
    rend.render(res.scP, res.oc);
    rend.setScissorTest(false); rend.setViewport(0, 0, sz.x, sz.y); rend.autoClear = prevAC; rend.shadowMap.autoUpdate = smA;
  }

  /* ---------- cinematica del pod: linea di mira, inseguimento, mascheramento, laser ---------- */
  function interseca(o, d, maxR) {
    maxR = maxR || 90000; let t0 = 0, t = 40; if (o.y - H.elev(o.x, o.z) <= 0) return null;
    while (t < maxR) { const x = o.x + d.x * t, y = o.y + d.y * t, z = o.z + d.z * t; if (y - H.elev(x, z) <= 0) { let a = t0, b = t; for (let i = 0; i < 14; i++) { const m = (a + b) / 2; if (o.y + d.y * m - H.elev(o.x + d.x * m, o.z + d.z * m) > 0) a = m; else b = m; } return V3(o.x + d.x * b, o.y + d.y * b, o.z + d.z * b); } if (y < -500) break; t0 = t; t += Math.max(15, t * 0.012); }
    return null;
  }
  function snowplow() { const pf = S.pf; const f = V3(0, 0, 1).applyQuaternion(pf.Q); f.y = 0; if (f.lengthSq() < 1e-6) f.set(0, 0, -1); f.normalize(); const d = f.clone().add(V3(0, -Math.tan(16 * D2R), 0)).normalize(); const p = interseca(S.pos, d); S.spi = p || V3(S.pos.x + f.x * 9000, 0, S.pos.z + f.z * 9000); if (!p) S.spi.y = H.elev(S.spi.x, S.spi.z); S.sito = null; S.item = null; S.track = "AREA"; }
  function sitoById(id) { if (!id) return null; const a = S.alias && S.alias[id]; return S.siti.find(s => s.id === id || s.id === a) || null; }
  function iniziale() {
    const a = H.assegnato && H.assegnato(); let s = a ? sitoById(a.id) : null;
    if (!s && S.siti.length) { const pf = S.pf; const f = V3(0, 0, 1).applyQuaternion(pf.Q); let best = null; S.siti.forEach(x => { if (!sitoVivo(x)) return; const d = V3().subVectors(x.pos, S.pos); const r = d.length(); if (r > 70000) return; const ang = Math.acos(clamp(d.normalize().dot(f), -1, 1)); const sc = r * (1 + ang * 2); if (!best || sc < best.sc) best = { x, sc }; }); s = best && best.x; }
    if (s) { S.spi = s.pos.clone(); S.sito = s; S.item = null; S.track = "AREA"; S.tgtI = S.siti.indexOf(s); return; }
    snowplow();
  }
  function cicloBersagli(d) {
    const vivi = S.siti.filter(sitoVivo); if (!vivi.length) { avviso("NO TGT"); return; }
    let i = vivi.indexOf(S.sito); i = (i + d + vivi.length) % vivi.length; const s = vivi[i]; S.sito = s; S.spi = s.pos.clone(); S.item = null; S.track = "AREA"; S.sfoc = 0.6; avviso("TGT " + String(s.nome || s.id).toUpperCase().slice(0, 22), 1.8);
  }
  function slew(ax, ay) {
    const d = V3().subVectors(S.spi, S.pos).normalize(); const up0 = Math.abs(d.y) > 0.985 ? V3(0, 0, -1) : V3(0, 1, 0);
    const rt = V3().crossVectors(d, up0).normalize(); const up = V3().crossVectors(rt, d).normalize();
    d.addScaledVector(rt, ax).addScaledVector(up, ay).normalize(); const p = interseca(S.pos, d); S.noGnd = !p; S.spi = p || S.pos.clone().addScaledVector(d, 40000); S.sito = null; S.item = null;
  }
  function candidatiTrack() {
    const out = []; S.siti.forEach(s => s.items.forEach(it => { if (!it.decor && !it.partito && itemVivo(it)) out.push(it); }));
    S.persone.forEach(q => { if (q.vivo) out.push(q); }); S.mezzi.forEach(m => out.push(m));
    (H.aerei ? H.aerei() : []).forEach(a => { if (a.pos) out.push({ aereo: a, vivo: true, tipo: "aereo" }); });
    return out;
  }
  function acquisisci() {
    const cam = S.cam; const gate = 0.14; let best = null; const p = V3();
    // persone e mezzi (in movimento, contrastati) hanno la precedenza sugli edifici dentro il riquadro di aggancio
    candidatiTrack().forEach(it => { p.copy(posItem(it)).project(cam); if (p.z > 1 || p.z < -1) return; const d0 = Math.hypot(p.x, p.y); if (d0 >= gate) return; const d = d0 * (it.mobile ? 0.4 : 1); if (!best || d < best.d) best = { it, d }; });
    if (best) { S.item = best.it; S.track = "POINT"; S.sito = best.it.sito || S.sito; S.spi.copy(posItem(best.it)); avviso("POINT · " + String(best.it.tipo || "").toUpperCase()); }
    else { S.item = null; S.track = "POINT"; avviso("POINT · GROUND"); }
  }
  function cambiaTrack() { if (S.track === "POINT") { S.track = "AREA"; S.item = null; avviso("AREA"); } else acquisisci(); }
  function cinematica(dt) {
    const pf = H.piattaforma(); S.pf = pf; if (!pf) return false;
    const m = MONTAGGIO[pf.tipo] || [0.6, -1.4, 3.4]; S.pos.set(m[0], m[1], m[2]).applyQuaternion(pf.Q).add(pf.pos);
    // cambio di velivolo (missioni): nuova linea di mira; alla prima accensione si tiene il bersaglio già scelto
    if (S.pfId !== pf.id) { if (S.pfId != null || !S.spi) S.spi = null; S.pfId = pf.id; }
    if (!S.spi) iniziale();
    if ((S.track === "POINT" || S.track === "INR") && S.item) { if (itemVivo(S.item)) S.spi.copy(posItem(S.item)); else { S.track = "AREA"; S.item = null; avviso("TRACK LOST"); } }
    else if (S.track !== "RATES" && (S.quotaT = (S.quotaT || 0) - dt) <= 0) {   // punto a terra: segue la quota del terreno man mano che arrivano le tile
      S.quotaT = 0.5; if (S.sito && S.track === "AREA" && Math.hypot(S.spi.x - S.sito.pos.x, S.spi.z - S.sito.pos.z) < 5) S.spi.copy(S.sito.pos); const y = quotaVisiva(S.spi.x, S.spi.z); if (Number.isFinite(y) && !S.noGnd) S.spi.y = y; }
    const fov = CAMPI[S.campo].deg * D2R; let ax = S.slew.x, ay = S.slew.y; S.slew.x = S.slew.y = 0;
    const kx = (KEYS.l ? 1 : 0) - (KEYS.j ? 1 : 0), ky = (KEYS.i ? 1 : 0) - (KEYS.k ? 1 : 0); if (kx || ky) { ax += kx * fov * 0.5 * dt; ay += ky * fov * 0.5 * dt; }
    if (ax || ay) { slew(ax, ay); S.rates = 0.4; S.track = "RATES"; }
    if (S.rates > 0) { S.rates -= dt; if (S.rates <= 0 && S.track === "RATES") S.track = "AREA"; }
    const los = V3().subVectors(S.spi, S.pos); S.range = los.length(); if (S.range < 1) return true; los.divideScalar(S.range); S.dir.copy(los);
    const b = los.clone().applyQuaternion(pf.Q.clone().invert()); const el = Math.asin(clamp(b.y, -1, 1)) * R2D, az = Math.atan2(-b.x, b.z) * R2D; S.az = az; S.el = el;
    const lato = (MONTAGGIO[pf.tipo] || [0.6])[0];   // pod a sinistra: la fusoliera maschera il lato destro a piccola depressione
    const masch = el > 8 || (Math.abs(az) > 155 && el > -22) || (lato > 0.3 && az > 32 && el > -28) || (lato < -0.3 && az < -32 && el > -28);
    S.maschera += ((masch ? 1 : 0) - S.maschera) * Math.min(1, dt * 7); S.limite = el > 25;
    if (S.maschera > 0.5 && S.track === "POINT") S.track = "INR"; else if (S.maschera < 0.5 && S.track === "INR") S.track = S.item ? "POINT" : "AREA";
    // TTI e laser automatico durante la guida delle armi
    S.tti = null; let guida = false;
    (H.armiInVolo ? H.armiInVolo() : []).forEach(a => { const tg = a.bersaglio; if (!tg || !tg.pos) return; const d = a.pos.distanceTo(tg.pos), v = Math.max(50, a.vel.length()); const t = d / v; if (S.tti == null || t < S.tti) S.tti = t; if (tg.pos.distanceTo(S.spi) < 400) guida = true; });
    S.bombe.forEach(bm => { const t = (bm.t1 - (S.simT || 0)); if (t >= 0 && (S.tti == null || t < S.tti)) S.tti = t; if (t < 20 && bm.aimPos && bm.aimPos.distanceTo(S.spi) < 600) guida = true; });
    S.laser = (S.laserMan || guida) && S.maschera < 0.5 && S.range < 40000;
    return true;
  }

  /* ---------- missioni: GBU sincronizzate con il motore, esplosioni, incendi, macerie ---------- */
  const FX = { pool: null };
  function fxInit() {
    if (FX.pool && FX.scena === H.scene()) return; FX.scena = H.scene(); FX.pool = [];
    const tl = (typeof VISTA3D !== "undefined" && VISTA3D.puffTexture) ? VISTA3D.puffTexture(true) : null, ts = (typeof VISTA3D !== "undefined" && VISTA3D.puffTexture) ? VISTA3D.puffTexture(false) : null;
    for (let i = 0; i < 220; i++) { const luce = i % 2 === 0; const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: luce ? tl : ts, transparent: true, depthWrite: false, blending: luce ? THREE.AdditiveBlending : THREE.NormalBlending, color: 0xffffff })); sp.visible = false; sp.userData.pod = true; FX.scena.add(sp); FX.pool.push({ sp, luce, vita: 0 }); }
    FX.i = 0;
  }
  function emetti(pos, o) {
    const n = FX.pool.length; for (let k = 0; k < n; k++) { const it = FX.pool[FX.i = (FX.i + 1) % n]; if (it.luce !== !!o.luce || (it.vita > 0 && k < n - 1)) continue;
      it.vita = it.vMax = o.vita || 1.5; it.sp.position.copy(pos); it.v = o.vel ? o.vel.clone() : V3(); it.s0 = o.s0 || 4; it.s1 = o.s1 || 20; it.a0 = o.a0 == null ? 0.85 : o.a0; it.g = o.g || 0; it.drag = o.drag == null ? 0.6 : o.drag; it.su = o.su || 0;
      it.sp.material.color.set(o.col || 0xffffff); if (o.int) it.sp.material.color.multiplyScalar(o.int); it.sp.material.opacity = it.a0; it.sp.scale.setScalar(it.s0); it.sp.visible = true; return; }
  }
  function fxAggiorna(dt) {
    if (!FX.pool) return; FX.pool.forEach(it => { if (it.vita <= 0) return; it.vita -= dt; if (it.vita <= 0) { it.sp.visible = false; return; } const k = 1 - it.vita / it.vMax; it.v.multiplyScalar(Math.max(0, 1 - it.drag * dt)); it.v.y += (it.su - it.g) * dt; it.sp.position.addScaledVector(it.v, dt); it.sp.scale.setScalar(it.s0 + (it.s1 - it.s0) * Math.sqrt(k)); it.sp.material.opacity = it.a0 * (1 - k * k); });
    S.fuochi = S.fuochi.filter(f => { f.t -= dt; if (f.t <= 0) return false; f.e -= dt; if (f.e <= 0) { f.e = 0.12 + Math.random() * 0.1; const k = Math.min(1, f.t / 20); emetti(f.pos.clone().add(V3((Math.random() - 0.5) * f.r, 0, (Math.random() - 0.5) * f.r)), { luce: true, col: Math.random() < 0.5 ? 0xff8a2a : 0xffb347, int: 1.6, vel: V3(0, 6 + Math.random() * 6, 0), vita: 0.7, s0: 5 * f.r / 10 * k + 2, s1: 9 * f.r / 10 * k + 3, a0: 0.9, drag: 0.4 }); if (Math.random() < 0.55) emetti(f.pos.clone().add(V3(0, 6, 0)), { col: 0x24201d, vel: V3(2 + Math.random() * 2, 8 + Math.random() * 4, 1), vita: 9, s0: 10, s1: 70 * (0.5 + k), a0: 0.55 * (0.4 + k), drag: 0.15, su: 1.2 }); } return true; });
  }
  function cratere(p, r) { const m = new THREE.Mesh(GEO.disco, MAT.cratere); m.scale.set(r * (0.85 + Math.random() * 0.3), 1, r * (0.85 + Math.random() * 0.3)); m.rotation.y = Math.random() * Math.PI * 2; m.position.set(p.x, quotaVisiva(p.x, p.z) + 0.6, p.z); m.renderOrder = 2; m.userData.pod = true; H.scene().add(m); }
  function distruggi(it, silenzioso) {
    if (!it || !it.vivo) return; it.vivo = false; if (S.item === it) { S.item = null; if (S.track === "POINT") S.track = "AREA"; }
    const p = posItem(it); it.obj.traverse(o => { if (o.isMesh) o.material = Math.random() < 0.6 ? MAT.bruciato : MAT.macerie; }); it.obj.scale.y *= 0.28; it.obj.rotation.z += (Math.random() - 0.5) * 0.3;
    if (it.obj.userData.piv) it.obj.userData.piv.rotation.x = -0.4;
    const r = it.tipo === "edificio" || it.tipo === "hangar" || it.tipo === "shelter" ? 22 : 10; cratere(p, r); if (it.tipo !== "suolo") macerie(it.obj.getWorldPosition(V3()), r * 0.7, it.tipo);
    S.fuochi.push({ pos: p.clone().setY(p.y - 1.5), t: silenzioso ? 25 + Math.random() * 25 : 60 + Math.random() * 60, e: 0, r });
    if (silenzioso) return;
    if (it.sito) allarme(it.sito, p);
    fxInit(); emetti(p.clone().add(V3(0, 4, 0)), { luce: true, col: 0xfff2d8, int: 6, vita: 0.25, s0: 30, s1: 140, a0: 1, drag: 0 });
    for (let i = 0; i < 12; i++) emetti(p.clone().add(V3(0, 5, 0)), { luce: true, col: i % 2 ? 0xffa040 : 0xff6a1a, int: 2.4, vel: V3(Math.random() - 0.5, Math.random() * 0.8 + 0.2, Math.random() - 0.5).multiplyScalar(35), vita: 1 + Math.random() * 0.9, s0: 14, s1: 55, a0: 1, drag: 1.6, su: 6 });
    for (let i = 0; i < 12; i++) emetti(p.clone(), { col: 0x6b5a45, vel: V3(Math.random() - 0.5, 0.15, Math.random() - 0.5).normalize().multiplyScalar(30 + Math.random() * 25), vita: 5 + Math.random() * 3, s0: 14, s1: 80, a0: 0.75, drag: 0.7 });
    for (let i = 0; i < 14; i++) emetti(p.clone().add(V3(0, 3, 0)), { col: 0x221d19, vel: V3(Math.random() - 0.5, 1 + Math.random(), Math.random() - 0.5).multiplyScalar(45 + Math.random() * 60), vita: 2.6, s0: 2, s1: 3.5, a0: 1, drag: 0.15, g: 9.8 });
    for (let i = 0; i < 6; i++) emetti(p.clone().add(V3(0, 10, 0)), { col: 0x2d2723, vel: V3((Math.random() - 0.5) * 6, 12 + Math.random() * 8, (Math.random() - 0.5) * 6), vita: 14, s0: 30, s1: 140, a0: 0.7, drag: 0.12, su: 0.8 });
  }
  /* ---------- squirters: personale che si muove nei siti e, dopo un impatto, scappa (persone e mezzi) ---------- */
  // quota rapida: modello del terreno + scarto misurato ogni tanto con il raggio sulla superficie disegnata (pochi raggi per fotogramma)
  function quotaMobile(q, dt) {
    q.seatT = (q.seatT || 0) - dt; if (q.seatT <= 0 && S.rcBudget > 0) { S.rcBudget--; q.seatT = q.v > 0.3 ? 0.7 + Math.random() * 0.4 : 6; const y = quotaVisiva(q.pos.x, q.pos.z); const e = H.elev(q.pos.x, q.pos.z); if (Number.isFinite(y) && Number.isFinite(e)) q.dy = y - e; }
    const e = H.elev(q.pos.x, q.pos.z); if (Number.isFinite(e)) { const yT = e + (q.dy || 0); q.pos.y = q.pos.y ? q.pos.y + (yT - q.pos.y) * Math.min(1, dt * 6) : yT; }
  }
  function nuovaPersona(origine, pos, rnd, civile, stato) {
    const o = persona(rnd, civile); H.scene().add(o); const p = { obj: o, pos: pos.clone(), home: pos.clone(), dir: V3(Math.sin(rnd() * 6.3), 0, Math.cos(rnd() * 6.3)).normalize(), v: 0, vT: 0, stato: stato || "idle", t: rnd() * 6, fase: rnd() * 6, origine, tipo: civile ? "civile" : "persona", vivo: true, mobile: true, seatT: 0, dy: 0, mut: [], monconi: [], macchie: [], ferita: null };
    p.pos.y = quotaVisiva(p.pos.x, p.pos.z); p.dy = p.pos.y - H.elev(p.pos.x, p.pos.z); o.position.copy(p.pos); S.persone.push(p); return p;
  }
  function popola(s) {
    if (s.popolato) return; s.popolato = true; const rnd = seme("pop" + s.id); const anc = s.items.filter(it => !it.decor); if (!anc.length) return;
    const n = Math.round((mobile() ? 4 : 7) * (0.7 + rnd() * 0.6)); const civ = s.kind === "c2" || s.kind === "generico" || s.kind === "ferrovia" || s.kind === "ponte";
    for (let i = 0; i < n; i++) { const a = anc[Math.floor(rnd() * anc.length)]; const an = rnd() * Math.PI * 2, d = 6 + rnd() * 14; nuovaPersona(s, V3(s.pos.x + a.x + Math.cos(an) * d, 0, s.pos.z + a.z + Math.sin(an) * d), rnd, civ && rnd() < 0.4); }
  }
  // un mezzo del sito (missioni) o uno comparso ai margini (volo libero) accende il motore e scappa
  function nuovoMezzo(obj, pos, yaw, rnd, lontanoDa) {
    obj.position.copy(pos); obj.rotation.set(0, yaw, 0); obj.traverse(o => { o.userData.pod = true; }); H.scene().add(obj);
    const via = V3(pos.x - lontanoDa.x, 0, pos.z - lontanoDa.z).normalize(); const m = { obj, pos: pos.clone(), dir: V3(Math.sin(yaw), 0, Math.cos(yaw)), via, v: 0, vMax: 9 + rnd() * 9, stato: "avvio", t: 2.5 + rnd() * 8, tFuga: 50 + rnd() * 90, curva: 0, curvaT: 0, tipo: "veicolo", vivo: true, mobile: true, seatT: 0, dy: 0, polvT: 0 };
    m.dy = quotaVisiva(pos.x, pos.z) - H.elev(pos.x, pos.z); S.mezzi.push(m); return m;
  }
  /* ---------- macerie all'impatto: cumuli di detriti, monconi di muro, lamiere, frammenti sparsi ---------- */
  function macerie(pos, raggio, tipo) {
    const g = new THREE.Group(), rnd = Math.random, ed = /edificio|hangar|shelter|torre|serbatoio/.test(tipo || ""), n = ed ? 30 : 10, mats = ed ? ["cemento", "macerie", "muro2", "bruciato", "tetto2", "lamiera"] : ["bruciato", "macerie", "lamiera", "gomma", "oliva2"];
    const pick = () => mats[Math.floor(rnd() * mats.length)];
    for (let i = 0; i < n; i++) { const a = rnd() * Math.PI * 2, d = Math.pow(rnd(), 0.6) * raggio, sz = ed ? 1 + rnd() * 3.5 : 0.4 + rnd() * 1.3; pz(g, "box", pick(), sz * (0.6 + rnd()), sz * (0.25 + rnd() * 0.5), sz * (0.6 + rnd()), Math.cos(a) * d, sz * 0.12, Math.sin(a) * d, (rnd() - 0.5) * 0.9, rnd() * 3.1, (rnd() - 0.5) * 0.9); }
    for (let i = 0; i < n; i++) { const a = rnd() * Math.PI * 2, d = raggio * (1 + rnd() * 2.2), sz = 0.2 + rnd() * (ed ? 0.9 : 0.5); pz(g, "box", pick(), sz, sz * 0.4, sz * (0.5 + rnd()), Math.cos(a) * d, sz * 0.15, Math.sin(a) * d, rnd(), rnd() * 3.1, rnd()); }
    if (ed) for (let i = 0; i < 3 + Math.floor(rnd() * 3); i++) { const a = rnd() * Math.PI * 2, d = raggio * (0.4 + rnd() * 0.5), h = 2 + rnd() * 6; pz(g, "box", rnd() < 0.5 ? "muro" : "muro2", 0.45, h, 3 + rnd() * 5, Math.cos(a) * d, h / 2 - 0.3, Math.sin(a) * d, (rnd() - 0.5) * 0.25, a, (rnd() - 0.5) * 0.25); }
    else for (let i = 0; i < 3; i++) pz(g, "box", "lamiera", 1.6 + rnd(), 0.05, 0.8 + rnd(), (rnd() - 0.5) * raggio, 0.4, (rnd() - 0.5) * raggio, rnd() * 1.2, rnd() * 3, rnd());
    g.position.set(pos.x, quotaVisiva(pos.x, pos.z), pos.z); g.traverse(o => { o.userData.pod = true; }); H.scene().add(g); return g;
  }
  /* ---------- feriti, caduti, sangue (interruttore BLD, spento di serie) ---------- */
  const SANG = { on: (() => { try { return localStorage.getItem("centurion_pod_sangue") === "1"; } catch (e) { return false; } })(), tex: null };
  function texSchizzo(i) {   // macchia irregolare con gocce attorno
    const c = document.createElement("canvas"); c.width = c.height = 128; const g = c.getContext("2d"); g.fillStyle = "#000"; g.fillRect(0, 0, 128, 128); const rnd = seme("schizzo" + i);
    for (let k = 0; k < 14; k++) { const a = rnd() * 6.28, d = Math.pow(rnd(), 1.6) * 30, r = 8 + rnd() * 18; const gr = g.createRadialGradient(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, 0, 64 + Math.cos(a) * d, 64 + Math.sin(a) * d, r); gr.addColorStop(0, "#fff"); gr.addColorStop(0.7, "#ddd"); gr.addColorStop(1, "rgba(0,0,0,0)"); g.fillStyle = gr; g.beginPath(); g.arc(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, r, 0, 6.28); g.fill(); }
    g.fillStyle = "#fff"; for (let k = 0; k < 22; k++) { const a = rnd() * 6.28, d = 34 + rnd() * 26, r = 1 + rnd() * 3; g.beginPath(); g.arc(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, r, 0, 6.28); g.fill(); }
    return new THREE.CanvasTexture(c);
  }
  function pozza(pos, rMax, cresce) {   // sangue a terra: scuro e lucido in TV, caldo nel FLIR finché si raffredda
    if (!SANG.tex) SANG.tex = [0, 1, 2].map(texSchizzo); const m = new THREE.MeshStandardMaterial({ color: 0x3e0505, roughness: 0.35, metalness: 0.05, transparent: true, opacity: 0.92, depthWrite: false, alphaMap: SANG.tex[Math.floor(Math.random() * 3)] });
    m.userData.calore = 0.55; TERMICI.add(m); const me = new THREE.Mesh(GEO.disco, m); me.position.set(pos.x, pos.y + 0.05, pos.z); me.rotation.y = Math.random() * 6.28; me.renderOrder = 3; me.userData.pod = true; me.visible = SANG.on;
    const sc = cresce ? 0.15 : rMax; me.scale.set(sc, 1, sc * (0.7 + Math.random() * 0.5)); H.scene().add(me); S.pozze.push({ me, m, r: rMax, t: 0, cresce: cresce || 0 }); return me;
  }
  function mutila(q, parte) {   // arto mancante: l'arto si nasconde (solo con BLD acceso), resta il moncone
    if (q.mut.includes(parte)) return; q.mut.push(parte); const j = q.obj.userData.j, gamba = parte < 2, s = parte % 2 === 0 ? 1 : -1;
    const st = gamba ? pz(j.pelvi, "sfera", "ferita", 0.17, 0.12, 0.17, s * 0.095, -0.1, 0) : pz(j.busto, "sfera", "ferita", 0.12, 0.11, 0.12, s * 0.2, 0.42, 0); st.userData.pod = true; q.monconi.push(st); applicaSangueA(q);
  }
  function macchia(q) { if (q.macchie.length) return; const m = pz(q.obj.userData.j.busto, "sfera", "ferita", 0.2, 0.22, 0.04, (Math.random() - 0.5) * 0.14, 0.15 + Math.random() * 0.2, 0.135); m.userData.pod = true; q.macchie.push(m); applicaSangueA(q); }
  function applicaSangueA(q) { const A = q.obj.userData.arti; A.forEach((a, i) => { a.visible = !(SANG.on && q.mut.includes(i)); }); q.monconi.forEach(m => { m.visible = SANG.on; }); q.macchie.forEach(m => { m.visible = SANG.on; }); }
  function applicaSangue() { S.persone.forEach(applicaSangueA); S.pozze.forEach(p => { p.me.visible = SANG.on; }); }
  function ferisci(q, grave) {
    if (!q.vivo || q.ferita) return; const rnd = Math.random; q.ferita = grave || rnd() < 0.4 ? "striscia" : "zoppica"; macchia(q);
    if (rnd() < (grave ? 0.6 : 0.3)) mutila(q, q.ferita === "striscia" ? Math.floor(rnd() * 2) : 2 + Math.floor(rnd() * 2));
    q.vRun = q.ferita === "striscia" ? 0.3 + rnd() * 0.2 : 1.1 + rnd() * 0.7; q.tCollasso = q.ferita === "striscia" || q.mut.length ? 20 + rnd() * 70 : (rnd() < 0.3 ? 40 + rnd() * 80 : null); q.goccia = 0;
    pozza(q.pos, 0.35 + rnd() * 0.3, 0);
  }
  // caduto: posizione naturale (prono o supino, arti scomposti), spostato dall'onda d'urto; vicino all'esplosione carbonizzato
  function uccidi(q, da, opt) {
    if (!q.vivo && q.posa) return; opt = opt || {}; const rnd = Math.random; q.vivo = false; q.stato = "morto"; q.v = q.vT = 0; q.ferita = null;
    if (da) { const via = V3(q.pos.x - da.x, 0, q.pos.z - da.z); const d = via.length(); if (d > 0.01) { via.divideScalar(d); q.pos.addScaledVector(via, opt.spinta != null ? opt.spinta : 0); q.dir.copy(via); } }
    const sup = rnd() < 0.5, ca = !!opt.carbonizzato; q.tMorte = q.tt || 0; q.yaw = q.yaw == null ? Math.atan2(q.dir.x, q.dir.z) : q.yaw;
    q.posa = ca ? { rRx: sup ? -1.5 : 1.5, rRz: (rnd() - 0.5) * 0.5, lift: 0.13, pelY: 0.97, bRx: 0.35, bRy: 0, bRz: 0, nRx: 0.4, nRy: (rnd() - 0.5), hpLx: -1.0, hpRx: -0.8, hpLz: 0.2, hpRz: -0.15, knL: 1.6, knR: 1.3, anL: -0.3, anR: -0.3, shLx: -1.3, shRx: -1.2, shLz: -0.2, shRz: 0.2, elL: -2.1, elR: -2.0, pelRx: 0, pelRy: 0, pelRz: 0 }
      : { rRx: sup ? -1.52 : 1.52, rRz: (rnd() - 0.5) * 0.3, lift: 0.12, pelY: 0.97, pelRx: 0, pelRy: (rnd() - 0.5) * 0.4, pelRz: (rnd() - 0.5) * 0.2, bRx: (rnd() - 0.5) * 0.3, bRy: (rnd() - 0.5) * 0.5, bRz: (rnd() - 0.5) * 0.3, nRx: (rnd() - 0.5) * 0.5, nRy: (rnd() - 0.5) * 1.4,
        hpLx: -rnd() * 0.9, hpRx: -rnd() * 0.6, hpLz: 0.05 + rnd() * 0.4, hpRz: -0.05 - rnd() * 0.4, knL: 0.1 + rnd() * 1.4, knR: 0.05 + rnd() * 0.9, anL: rnd() * 0.5, anR: rnd() * 0.5,
        shLx: (rnd() - 0.6) * 2.2, shRx: (rnd() - 0.6) * 2.2, shLz: 0.2 + rnd() * 1.3, shRz: -0.2 - rnd() * 1.3, elL: -0.1 - rnd() * 1.6, elR: -0.1 - rnd() * 1.6 };
    q.posa.rx = q.posa.rRx;
    if (opt.carbonizzato) q.obj.traverse(o => { if (o.isMesh) o.material = MAT.bruciato; });
    else { macchia(q); if (opt.mutila) { const n = 1 + Math.floor(rnd() * 2); for (let i = 0; i < n; i++) mutila(q, Math.floor(rnd() * 4)); } pozza(q.pos, 0.6 + rnd() * 0.7 + (opt.mutila ? 0.5 : 0), 25 + rnd() * 20); }
  }
  function allarme(s, p, soloPanico) {
    const now = performance.now(); if (s) { if (s.allT && now - s.allT < 2500) return; s.allT = now; } const rnd = Math.random; if (!soloPanico) { S.ultimoImpatto = p.clone(); S.sqrT = now + 3500; }
    S.persone.forEach(q => { if (!q.vivo) return; const d = Math.hypot(q.pos.x - p.x, q.pos.z - p.z); if (d > 480) return;
      const kR = 12 + rnd() * 10;   // raggio letale dell'esplosione: più vicino carbonizzati, poi caduti spesso mutilati; nella fascia esterna feriti
      if (!soloPanico && d < kR) { uccidi(q, p, { spinta: 2 + rnd() * 6, carbonizzato: d < 6, mutila: rnd() < 0.55 }); return; }
      if (!soloPanico && d < kR + 35 && rnd() < 0.55) ferisci(q, d < kR + 10);
      const via = V3(q.pos.x - p.x, 0, q.pos.z - p.z).normalize().applyAxisAngle(V3(0, 1, 0), (rnd() - 0.5) * 1.4); q.dir.copy(via);
      if (soloPanico && q.stato === "corre") return;   // sotto il fuoco chi corre già cambia solo direzione
      q.stato = "reazione"; q.t = 0.3 + rnd() * 1.6 + d / 250; q.vRun = 3.0 + rnd() * 2.8; q.tCorsa = 12 + rnd() * 35; q.squirter = true; });
    if (s) { // dagli edifici rimasti in piedi esce chi era dentro
      s.items.filter(it => it.vivo && (it.tipo === "edificio" || it.tipo === "hangar" || it.tipo === "torre")).forEach(b => { const bp = posItem(b); if (Math.hypot(bp.x - p.x, bp.z - p.z) > 260) return; const k = Math.floor(rnd() * 4);
        for (let i = 0; i < k; i++) { const an = rnd() * Math.PI * 2; const q = nuovaPersona(null, V3(bp.x + Math.cos(an) * 9, 0, bp.z + Math.sin(an) * 9), rnd, s.kind === "c2" && rnd() < 0.5, "reazione"); q.dir.set(bp.x - p.x, 0, bp.z - p.z).normalize().applyAxisAngle(V3(0, 1, 0), (rnd() - 0.5) * 1.6); q.t = 1 + rnd() * 5; q.vRun = 3 + rnd() * 2.6; q.tCorsa = 15 + rnd() * 35; q.squirter = true; } });
      if (!s.volo) s.items.filter(it => it.vivo && !it.partito && /camion|veicolo|posto comando|ew|auto/.test(it.tipo)).forEach(it => { const ip = posItem(it); const d = Math.hypot(ip.x - p.x, ip.z - p.z); if (d < 18 || d > 360 || rnd() < 0.45) return;
        it.obj.updateMatrixWorld(true); const wp = it.obj.getWorldPosition(V3()); const yaw = it.obj.rotation.y; const cl = it.obj.clone(); it.obj.visible = false; it.partito = true; nuovoMezzo(cl, wp, yaw, rnd, p); });
      else { const n = 1 + Math.floor(rnd() * 3); for (let i = 0; i < n; i++) { const an = rnd() * Math.PI * 2, d = 70 + rnd() * 70; const pos = V3(s.pos.x + Math.cos(an) * d, 0, s.pos.z + Math.sin(an) * d); nuovoMezzo(rnd() < 0.6 ? camion(rnd() < 0.3 ? "cisterna" : "cargo") : auto(rnd), pos, Math.atan2(pos.x - p.x, pos.z - p.z) + (rnd() - 0.5), rnd, p); } }
    }
  }
  function aggiornaSquirters(dt) {
    S.rcBudget = 3; const rnd = Math.random;
    S.persone.forEach(q => {
      const o = q.obj; if (!o.parent) return; const A = o.userData.arti;
      if (!q.vivo) {   // caduto: posizione fissa sul terreno, arti scomposti
        if (!q.posa) uccidi(q, null, {}); quotaMobile(q, dt); animaPersona(q, dt); return; }
      if (q.ferita && q.tCollasso != null && (q.tCollasso -= dt) <= 0) { uccidi(q, null, {}); return; }   // ferito grave che crolla
      if (q.ferita && q.v > 0.15 && (q.goccia = (q.goccia || 0) + q.v * dt) > 1.3) { q.goccia = 0; pozza(q.pos, 0.12 + rnd() * 0.18, 0); }   // scia di sangue
      if (q.vivo) { q.t -= dt;
        if (q.stato === "idle") { if (q.t <= 0) { if (q.vT > 0) { q.vT = 0; q.t = 3 + rnd() * 9; } else { const an = rnd() * Math.PI * 2, r = 4 + rnd() * 22; const tx = q.home.x + Math.cos(an) * r, tz = q.home.z + Math.sin(an) * r; const d = Math.hypot(tx - q.pos.x, tz - q.pos.z); q.dir.set(tx - q.pos.x, 0, tz - q.pos.z).normalize(); q.vT = 1.0 + rnd() * 0.5; q.t = d / q.vT; } } }
        else if (q.stato === "reazione") { q.vT = 0; if (q.t <= 0) { q.stato = "corre"; q.t = q.tCorsa; } }
        else if (q.stato === "corre") { q.vT = q.ferita === "striscia" ? 0.4 : q.ferita === "zoppica" ? Math.min(1.7, q.vRun) : q.vRun; q.dir.applyAxisAngle(V3(0, 1, 0), (rnd() - 0.5) * 0.9 * dt); if (q.t <= 0) { const r = rnd(); if (r < 0.3) { q.stato = "terra"; q.vT = 0; } else if (r < 0.65) { q.stato = "cammina"; q.t = 20 + rnd() * 50; } else { q.stato = "riparo"; q.vT = 0; } } }
        else if (q.stato === "cammina") { q.vT = 1.3; q.dir.applyAxisAngle(V3(0, 1, 0), (rnd() - 0.5) * 0.6 * dt); if (q.t <= 0) { q.stato = rnd() < 0.5 ? "riparo" : "terra"; q.vT = 0; } }
        else q.vT = 0; }
      else q.vT = 0;
      q.v += (q.vT - q.v) * Math.min(1, dt * 3); q.pos.addScaledVector(q.dir, q.v * dt); quotaMobile(q, dt);
      animaPersona(q, dt);
    });
    S.mezzi.forEach(m => {
      m.t -= dt;
      if (m.stato === "avvio") { if (m.t <= 0) { m.stato = "fuga"; m.t = m.tFuga; } }
      else if (m.stato === "fuga") { // si allontana dal punto d'impatto, poi segue una strada immaginaria con curve dolci
        const err = Math.atan2(m.via.x, m.via.z) - Math.atan2(m.dir.x, m.dir.z); const e = Math.atan2(Math.sin(err), Math.cos(err)); m.curvaT -= dt; if (m.curvaT <= 0) { m.curvaT = 3 + rnd() * 5; m.curva = (rnd() - 0.5) * 0.25; }
        const rot = clamp(e * 0.6 + m.curva, -0.35, 0.35) * dt * clamp(m.v / 4, 0.2, 1); m.dir.applyAxisAngle(V3(0, 1, 0), rot); m.v = Math.min(m.vMax, m.v + 2.6 * dt); if (m.t <= 0) m.stato = "fermo";
        if ((m.polvT -= dt) <= 0 && m.v > 5) { m.polvT = 0.12; fxInit(); emetti(m.pos.clone().addScaledVector(m.dir, -4).add(V3(0, 0.8, 0)), { col: 0x8c7b62, vel: V3((rnd() - 0.5) * 2, 1.5, (rnd() - 0.5) * 2), vita: 3.5, s0: 3, s1: 16, a0: 0.32, drag: 0.8, su: 0.5 }); } }
      else m.v = Math.max(0, m.v - 4 * dt);
      m.pos.addScaledVector(m.dir, m.v * dt); quotaMobile(m, dt); m.obj.position.copy(m.pos); m.obj.rotation.set(0, Math.atan2(m.dir.x, m.dir.z), 0);
    });
    S.pozze.forEach(z => { z.t += dt; if (z.cresce) { const k = Math.min(1, z.t / z.cresce); const r = z.r * (0.15 + 0.85 * Math.sqrt(k)); z.me.scale.x = r; z.me.scale.z = r * 0.85; } z.m.userData.calore = 0.08 + 0.47 * Math.exp(-z.t / 150); });
    // volo libero: un Maverick esploso vicino a un sito (anche mancato) mette in fuga chi c'è
    const armi = H.armiInVolo ? H.armiInVolo() : []; const viste = new Set(armi.map(a => a.pos));
    (S.armiPrima || []).forEach(a => { if (viste.has(a.pos)) return; const s = S.siti.find(x => x.pos.distanceTo(a.pos) < 700); if (s) allarme(s, a.pos.clone()); }); S.armiPrima = armi;
    // dopo l'impatto, la chiamata di controllo
    if (S.sqrT && performance.now() > S.sqrT) { S.sqrT = 0; S.sqrRichiesta = performance.now() + 20000; avviso("CHECK FOR SQUIRTERS", 4); }
  }
  /* ---------- cannone aria-suolo (volo libero): colpi a terra su squirters e mezzi ---------- */
  // i proiettili del volo spariscono quando toccano terra: si confronta l'elenco con quello del fotogramma prima e si ricostruisce il punto d'impatto
  function cannoneSuolo() {
    const lista = H.proiettili ? H.proiettili() : null; if (!lista) return; const vivi = new Set(lista);
    (S.colpiPrima || []).forEach(c => { if (!vivi.has(c.ref)) impattoColpo(c); });
    S.colpiPrima = lista.map(b => ({ ref: b, pos: b.pos.clone(), vel: b.vel.clone() }));
  }
  function impattoColpo(c) {
    const p = c.pos.clone(), v = c.vel.clone(); let hit = null; for (let i = 0; i < 30; i++) { v.y -= 9.81 * 0.004; p.addScaledVector(v, 0.004); if (p.y <= H.elev(p.x, p.z)) { hit = p; break; } } if (!hit) return;
    hit.y = H.elev(hit.x, hit.z) + 0.3; fxInit(); const rnd = Math.random; (S.impatti = S.impatti || []).push(hit.clone()); if (S.impatti.length > 300) S.impatti.shift();
    emetti(hit, { col: 0x9c8b70, vel: V3((rnd() - 0.5) * 3, 3 + rnd() * 4, (rnd() - 0.5) * 3), vita: 1.4, s0: 1.2, s1: 7, a0: 0.6, drag: 1.2, su: -2 });
    if (rnd() < 0.34) emetti(hit, { luce: true, col: 0xffd27a, int: 3, vita: 0.1, s0: 1.4, s1: 3, a0: 1, drag: 0 });
    // schegge del 20 mm esplosivo: letali per una persona entro ~3 m, quattro colpi fermano un mezzo
    S.persone.forEach(q => { if (!q.vivo) return; const d = Math.hypot(q.pos.x - hit.x, q.pos.z - hit.z); if (d < 1.5) uccidi(q, hit, { spinta: 0.5, mutila: rnd() < 0.4 }); else if (d < 3.6 && rnd() < 0.6) { if (q.ferita) uccidi(q, hit, { spinta: 0.3 }); else ferisci(q, true); } });
    S.mezzi.forEach(m => { if (!m.vivo || Math.hypot(m.pos.x - hit.x, m.pos.z - hit.z) > 3.8) return; m.hp = (m.hp == null ? 4 : m.hp) - 1; if (m.hp <= 0) mezzoDistrutto(m); });
    const now = performance.now(); if (!S.gunAllT || now - S.gunAllT > 1200) { S.gunAllT = now; allarme(null, hit, true); }
  }
  function mezzoDistrutto(m) {
    m.vivo = false; m.stato = "fermo"; m.v = 0; if (S.item === m) { S.item = null; S.track = "AREA"; avviso("TRACK LOST"); }
    m.obj.traverse(o => { if (o.isMesh) o.material = Math.random() < 0.6 ? MAT.bruciato : MAT.macerie; }); m.obj.rotation.z = (Math.random() - 0.5) * 0.2;
    fxInit(); emetti(m.pos.clone().add(V3(0, 2, 0)), { luce: true, col: 0xffa040, int: 3, vita: 0.9, s0: 6, s1: 22, a0: 1, drag: 1.5, su: 4 });
    S.fuochi.push({ pos: m.pos.clone(), t: 40 + Math.random() * 40, e: 0, r: 5 }); macerie(m.pos, 4, "veicolo");
  }
  /* ---------- HUD aria-suolo: riquadro TD sul punto del pod e pipper CCIP del cannone ---------- */
  function hudAG() {
    const pf = H.piattaforma && H.piattaforma(), cam = H.camera && H.camera(), cv = H.hudCanvas && H.hudCanvas(), g = H.hudCtx && H.hudCtx(); if (!pf || !cam || !cv || !g) return;
    const W = cv.width, Hh = cv.height; cam.updateMatrixWorld();
    const proj = v => { const p = v.clone().project(cam); if (p.z > 1 || p.z < -1) return null; return { x: (p.x + 1) / 2 * W, y: (1 - p.y) / 2 * Hh, dentro: Math.abs(p.x) <= 0.98 && Math.abs(p.y) <= 0.98 }; };
    const VE = "#5dff8f"; g.save(); g.strokeStyle = VE; g.fillStyle = VE; g.lineWidth = 2; g.font = "bold 13px Consolas, monospace"; g.textAlign = "center"; g.shadowColor = "rgba(0,0,0,.6)"; g.shadowBlur = 3;
    let td = null; if (S && S.on && S.spi) { td = proj(S.spi); if (td && td.dentro) { const b = 9; g.strokeRect(td.x - b, td.y - b, 2 * b, 2 * b); g.fillText(S.track === "POINT" ? "TD" : "SPI", td.x, td.y - b - 6); } else td = null; }
    if (H.arma && H.arma() === "GUN") {   // traiettoria dei colpi (stessa balistica del volo) fino al suolo
      const f = V3(0, 0, 1).applyQuaternion(pf.Q); const p = pf.pos.clone().addScaledVector(f, 6), v = (pf.vel ? pf.vel.clone() : V3()).addScaledVector(f, 1050); let hit = null, t = 0;
      for (let i = 0; i < 160; i++) { v.y -= 9.81 * 0.02; v.multiplyScalar(1 - 0.12 * 0.02); p.addScaledVector(v, 0.02); t += 0.02; if (p.y <= H.elev(p.x, p.z)) { hit = p; break; } }
      if (hit) { const q = proj(hit); if (q && q.dentro) { const r = hit.distanceTo(pf.pos), inR = r < 2200, sopra = td && Math.hypot(q.x - td.x, q.y - td.y) < 16;
        g.beginPath(); g.arc(q.x, q.y, 12, 0, Math.PI * 2); g.stroke(); g.beginPath(); g.arc(q.x, q.y, 2, 0, Math.PI * 2); g.fill();
        g.textAlign = "left"; g.fillText(Math.round(r * FT / 100) / 10 + "K", q.x + 16, q.y + 4); g.textAlign = "center"; g.fillText("CCIP GUN", q.x, q.y + 30);
        if (inR && sopra) g.fillText("SHOOT", q.x, q.y - 22); else if (!inR) g.fillText("RNG", q.x, q.y - 22);
        if (td && !sopra) { g.setLineDash([4, 4]); g.beginPath(); g.moveTo(q.x, q.y); g.lineTo(td.x, td.y); g.stroke(); g.setLineDash([]); } } }
    }
    g.restore();
  }
  // CHECK FOR SQUIRTERS: campo largo sul punto d'impatto, inseguimento ad area, laser spento: si cerca chi scappa
  function checkSquirters() {
    const p = S.ultimoImpatto || (S.sito && S.sito.pos) || S.spi; if (!p) return; S.spi = p.clone(); const y = quotaVisiva(p.x, p.z); if (Number.isFinite(y)) S.spi.y = y;
    S.campo = 0; S.sfoc = 1; S.track = "AREA"; S.item = null; S.laserMan = false; S.sqrRichiesta = 0; avviso("CHECK FOR SQUIRTERS · WIDE", 3);
  }
  function missioni(dt) {
    const eng = H.motore(); if (!eng) return; const v = H.velocitaSim ? H.velocitaSim() : 0;
    if (S.simT == null) S.simT = eng.t; S.simT += dt * v; S.simT += (eng.t - S.simT) * Math.min(1, dt * 1.2);
    // sgancio delle GBU nel punto di rilascio reale: a velocità × tempo di caduta dal bersaglio, durante la corsa d'attacco,
    // così le bombe arrivano quando la formazione lo sorvola (il motore registra poi il danno a fine attacco)
    eng.flights.forEach(f => {
      if (f.distrutto || f.lato !== "BLUE" || f.alt <= 50) return; let w = null; try { w = eng.wp(f); } catch (e) {} const tid = (w && w.target) || (f.stato === "attacco" ? f.gbu_attacco_tgt : null); if (!tid) return;
      const key = f.id + "@" + tid + "@" + (f.wp_i == null ? "" : f.wp_i); if (S.rilasci.has(key)) return; const s = sitoById(tid); if (!s) return; const tg = eng.target.find(x => x.id === tid); if (!tg || tg.distrutto) return;
      const p0 = H.posFormazione(f); const hgt = Math.max(300, p0.y - s.pos.y); const tof = Math.sqrt(2 * hgt / 9.81) * 1.12 + 2; const v = Math.max(120, (f.tas || 400) * 0.5144); const d = Math.hypot(s.pos.x - p0.x, s.pos.z - p0.z);
      const hdg = (f.hdg || 0) * D2R; const fw = V3(Math.sin(hdg), 0, -Math.cos(hdg)), lat = V3(Math.cos(hdg), 0, Math.sin(hdg)); const verso = ((s.pos.x - p0.x) * fw.x + (s.pos.z - p0.z) * fw.z) / Math.max(1, d);
      const inCorsa = f.stato !== "attacco" && d <= v * tof && verso > 0.5, giaSopra = f.stato === "attacco" && d < 12000; if (!inCorsa && !giaSopra) return;
      const disp = eng.gbuTot ? eng.gbuTot(f) : (f.armi.GBU48 || 0) * f.n; const n = Math.min(24, f.stato === "attacco" ? (f.gbu_attacco || 0) : Math.min(disp, Math.max(0, tg.gbu_richieste - tg.danni - (tg.prenotate || 0)))); S.rilasci.add(key); if (n <= 0) return;
      const dmpi = s.items.filter(it => it.dmpi && it.vivo && !it.partito).sort((a, b) => (a.ris - b.ris) || (Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z))); const perBomba = Math.max(1, Math.ceil(dmpi.length / Math.max(1, tg.gbu_richieste)));
      for (let i = 0; i < n; i++) {
        const aim = dmpi.length ? dmpi[i % dmpi.length] : null; if (aim) aim.ris++;
        const st = p0.clone().addScaledVector(lat, ((i % 4) - 1.5) * 55).addScaledVector(fw, -Math.floor(i / 4) * 40); const ap = aim ? posItem(aim) : s.pos.clone();
        const m = bomba(); m.traverse(o => { o.userData.pod = true; }); H.scene().add(m);
        const t0 = S.simT, t1 = S.simT + Math.max(3, f.stato === "attacco" ? tof * 0.8 : Math.min(tof, d / v)) + i * 0.35;
        S.bombe.push({ m, p0: st, c: st.clone().addScaledVector(fw, Math.hypot(ap.x - st.x, ap.z - st.z) * 0.55), aim, aimPos: ap, t0, t1, sito: s, perBomba });
      }
    });
    const pv = V3(), tg = V3();
    S.bombe = S.bombe.filter(b => {
      const k = clamp((S.simT - b.t0) / (b.t1 - b.t0), 0, 1); if (b.aim) b.aimPos.copy(posItem(b.aim));
      const a = b.p0, c = b.c, e = b.aimPos; const u = 1 - k; pv.set(u * u * a.x + 2 * u * k * c.x + k * k * e.x, u * u * a.y + 2 * u * k * c.y + k * k * e.y, u * u * a.z + 2 * u * k * c.z + k * k * e.z);
      tg.set(2 * u * (c.x - a.x) + 2 * k * (e.x - c.x), 2 * u * (c.y - a.y) + 2 * k * (e.y - c.y), 2 * u * (c.z - a.z) + 2 * k * (e.z - c.z));
      if (k > 0.85) pv.add(V3(Math.sin(k * 60) * 0.6, 0, Math.cos(k * 50) * 0.6));
      b.m.position.copy(pv); b.m.lookAt(pv.clone().add(tg));
      if (k >= 1) { H.scene().remove(b.m); if (b.aim) { b.aim.ris = Math.max(0, b.aim.ris - 1); const ap = posItem(b.aim); distruggi(b.aim, false);
          // una GBU da 1000 lb distrugge anche gli elementi più vicini al punto d'impatto (quanti ne servono per bersaglio)
          b.sito.items.filter(it => it.dmpi && it.vivo && !it.ris).map(it => ({ it, d: posItem(it).distanceTo(ap) })).filter(x => x.d < 45).sort((p, q) => p.d - q.d).slice(0, b.perBomba - 1).forEach(x => distruggi(x.it, true)); } else { const it = { obj: new THREE.Group(), vivo: true, tipo: "suolo" }; it.obj.position.copy(b.aimPos); fxInit(); distruggi(it, false); allarme(b.sito, b.aimPos); } return false; }
      return true;
    });
    // allineamento ai danni del motore (attacchi avvenuti prima di aprire il pod o senza bombe visibili)
    const now = performance.now(); if (now - S.sincT > 1000) { S.sincT = now; S.siti.forEach(s => {
      const r = s.ref; const fr = s.sam ? (r.soppressa ? 1 : 0) : r.distrutto ? 1 : clamp((r.danni || 0) / Math.max(1, r.gbu_richieste || 1), 0, 1);
      const dm = s.items.filter(it => it.dmpi && !it.partito); const voluti = Math.round(dm.length * fr); const fatti = dm.filter(it => !it.vivo).length; const inArrivo = S.bombe.filter(b => b.sito === s).length;
      let da = voluti - fatti - inArrivo; const cand = dm.filter(it => it.vivo && !it.ris).sort((a, b) => Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z)); while (da-- > 0 && cand.length) distruggi(cand.shift(), s.nuovo);
      s.nuovo = false; }); }
  }

  /* ---------- simbologia del display (stile MFD, bianca con bordo nero: leggibile in WHOT e BHOT) ---------- */
  function pulisci(c, r) { if (!c) return; const cr = c.getBoundingClientRect(); if (!cr.width) return; const k = c.width / cr.width; const g = c.getContext("2d"); g.clearRect((r.left - cr.left) * k - 1, (r.top - cr.top) * k - 1, r.w * k + 2, r.h * k + 2); }
  function ddm(v, pos, neg, w) { const s = v >= 0 ? pos : neg; v = Math.abs(v); const d = Math.floor(v); const m = (v - d) * 60; return s + String(d).padStart(w, "0") + "°" + m.toFixed(3).padStart(6, "0") + "'"; }
  function simbologia() {
    const cv = H.hudCanvas(), g = H.hudCtx(), r = S.rect; if (!cv || !g || !r) return;
    (H.altreTele ? H.altreTele() : []).forEach(c => pulisci(c, r));
    const cr = cv.getBoundingClientRect(); const k = cv.width / Math.max(1, cr.width); const x0 = (r.left - cr.left) * k, y0 = (r.top - cr.top) * k, W = r.w * k, Hh = r.h * k;
    // a tutto schermo le righe dei tasti stanno sopra l'immagine: la simbologia in alto e in basso si sposta per non finirci sotto
    let su = 0, giu = 0; const ui = HOSTS[S.hostId] && HOSTS[S.hostId].ui; if (S.on === 2 && ui) ui.mfd.querySelectorAll(".pod-osb").forEach(el => { const q = el.getBoundingClientRect(); if (q.top < r.top + r.h / 2) su = Math.max(su, (q.bottom - r.top) * k); else giu = Math.max(giu, (r.top + r.h - q.top) * k); });
    g.save(); g.clearRect(x0, y0, W, Hh); g.beginPath(); g.rect(x0, y0, W, Hh); g.clip(); g.translate(x0, y0 + su); const HhT = Hh - su - giu;
    const s = clamp(Math.min(W, Hh) / 420, 0.62, 2.0), cx = W / 2, cy = Hh / 2 - su, BI = "#f3f8f3", NE = "rgba(0,0,0,0.85)", t = performance.now() / 1000, lamp = Math.floor(t * 2.5) % 2 === 0;
    const linea = (pts, lw) => { [[NE, (lw || 1.4) * s + 2.4], [BI, (lw || 1.4) * s]].forEach(([col, w]) => { g.strokeStyle = col; g.lineWidth = w; g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.stroke(); }); };
    const testo = (tx, x, y, al, sz, inv) => { g.font = `700 ${Math.round((sz || 12) * s)}px Consolas, "Courier New", monospace`; g.textAlign = al || "left"; g.textBaseline = "middle";
      if (inv) { const m = g.measureText(tx).width; const px = al === "center" ? x - m / 2 : al === "right" ? x - m : x; g.fillStyle = BI; g.fillRect(px - 3 * s, y - 8 * s, m + 6 * s, 16 * s); g.fillStyle = "#000"; g.fillText(tx, x, y); return; }
      g.lineWidth = 3; g.strokeStyle = NE; g.strokeText(tx, x, y); g.fillStyle = BI; g.fillText(tx, x, y); };
    if (!S.pf) { testo("TGP STBY", cx, cy, "center", 16); testo("NESSUN VELIVOLO IN VOLO SELEZIONATO", cx, cy + 22 * s, "center", 10); g.restore(); return; }
    // reticolo: linee lunghe con interruzione centrale e tacche
    const gap = 0.055 * Math.min(W, Hh), L = 0.46 * Math.min(W, Hh);
    if (S.track === "RATES") g.setLineDash([6 * s, 5 * s]);
    linea([[cx - L, cy], [cx - gap, cy]]); linea([[cx + gap, cy], [cx + L, cy]]); linea([[cx, cy - L], [cx, cy - gap]]); linea([[cx, cy + gap], [cx, cy + L]]); g.setLineDash([]);
    for (let i = 1; i <= 4; i++) { const d = gap + (L - gap) * i / 4.5; linea([[cx - d, cy - 4 * s], [cx - d, cy + 4 * s]], 1); linea([[cx + d, cy - 4 * s], [cx + d, cy + 4 * s]], 1); linea([[cx - 4 * s, cy - d], [cx + 4 * s, cy - d]], 1); linea([[cx - 4 * s, cy + d], [cx + 4 * s, cy + d]], 1); }
    if (S.track === "POINT" || S.track === "INR") { const b = 13 * s, c = 5 * s; [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([sx, sy]) => linea([[cx + sx * b, cy + sy * (b - c)], [cx + sx * b, cy + sy * b], [cx + sx * (b - c), cy + sy * b]], 1.8)); }
    // riga in alto
    const campo = CAMPI[S.campo]; testo("A-G", 10 * s, 16 * s); testo("TGP", 10 * s, 32 * s, "left", 10);
    testo(campo.nome + (campo.exp > 1 ? " EXP" + campo.exp : ""), cx, 16 * s, "center"); testo(MODI[S.modo], W - 10 * s, 16 * s, "right"); testo(S.track === "INR" ? "INR" : S.track, W - 10 * s, 32 * s, "right", 11, S.track === "POINT");
    if (S.laser) { if (lamp) testo("L", cx + gap * 1.7, cy - gap * 1.7, "center", 18); testo("LASE", cx, 32 * s, "center", 11, true); } else testo(S.laserMan ? "LSR ARM" : "LSR SAFE", cx, 32 * s, "center", 9);
    // freccia del nord
    const hl = Math.atan2(S.dir.x, -S.dir.z); g.save(); g.translate(W - 22 * s, 58 * s); g.rotate(-hl); linea([[0, 9 * s], [0, -9 * s]], 1.2); linea([[-4 * s, -4 * s], [0, -9 * s], [4 * s, -4 * s]], 1.2); g.restore(); testo("N", W - 22 * s, 75 * s, "center", 8);
    // linea di mira rispetto al velivolo
    testo("AZ " + (S.az >= 0 ? "R" : "L") + String(Math.round(Math.abs(S.az))).padStart(3, "0"), 10 * s, cy - 10 * s, "left", 11); testo("EL " + (S.el >= 0 ? "+" : "-") + String(Math.round(Math.abs(S.el))).padStart(2, "0"), 10 * s, cy + 8 * s, "left", 11);
    const bx = W - 30 * s, by = cy, br = 20 * s; g.strokeStyle = BI; linea([[bx + br, by]].concat(Array.from({ length: 33 }, (_, i) => [bx + Math.cos(i / 32 * Math.PI * 2) * br, by + Math.sin(i / 32 * Math.PI * 2) * br])), 1);
    linea([[bx - 7 * s, by], [bx + 7 * s, by]], 1.2); linea([[bx, by - 5 * s], [bx, by + 6 * s]], 1.2); const rr = clamp((90 + S.el) / 90, 0, 1.25) * br, aa = S.az * D2R; const lx = bx + Math.sin(aa) * rr, ly = by - Math.cos(aa) * rr;
    g.fillStyle = BI; g.strokeStyle = NE; g.lineWidth = 2; g.beginPath(); g.arc(lx, ly, 3.2 * s, 0, Math.PI * 2); g.stroke(); g.fill();
    // riga in basso: distanza, quota, coordinate, TTI, ora
    const rngNm = S.range / NM; const ll = H.latLon(S.spi.x, S.spi.z);
    testo(S.noGnd ? "RNG ----" : S.laser ? "L" + rngNm.toFixed(2) : "RNG " + rngNm.toFixed(1), 10 * s, HhT - 46 * s, "left", 12); testo("ELEV " + Math.round(S.spi.y * FT).toLocaleString("it-IT"), 10 * s, HhT - 30 * s, "left", 10); testo("CODE " + CODICE, 10 * s, HhT - 14 * s, "left", 9);
    testo(ddm(ll.lat, "N", "S", 2) + " " + ddm(ll.lon, "E", "W", 3), cx, HhT - 14 * s, "center", 10);
    const nomeT = S.item && S.item.tipo ? String(S.item.tipo).toUpperCase() : S.sito ? String(S.sito.nome || S.sito.id).toUpperCase().slice(0, 26) : ""; if (nomeT) testo(nomeT, cx, HhT - 30 * s, "center", 10);
    if (S.tti != null) testo("TTI " + String(Math.max(0, Math.round(S.tti))).padStart(2, "0"), W - 10 * s, HhT - 46 * s, "right", 13, S.tti < 10 && lamp);
    testo(H.tempo ? H.tempo() : "", W - 10 * s, HhT - 14 * s, "right", 9);
    // avvisi
    if (S.maschera > 0.5 && lamp) testo(S.limite ? "GIMBAL" : "MASK", cx, cy - 40 * s, "center", 18, true);
    if (S.noGnd) testo("NO GND", cx, cy + 40 * s, "center", 12);
    if (S.msg && performance.now() < S.msg.fino) testo(S.msg.t, cx, cy + 58 * s, "center", 11);
    g.restore();
  }

  /* ---------- interfaccia: display MFD con tasti a lato (OSB), pulsante TGP, tastiera, touch ---------- */
  const CSS = `
.pod-mfd{position:absolute;z-index:4;left:max(10px,env(safe-area-inset-left));top:calc(max(4px,env(safe-area-inset-top)) + 66px);width:var(--pod-w,min(44vh,30vw,460px));background:transparent;border:2px solid #3c454b;border-radius:10px;box-shadow:0 6px 20px #000a;display:flex;flex-direction:column;user-select:none;-webkit-user-select:none;touch-action:none;overflow:hidden}
.pod-mfd.hidden{display:none}
.pod-mfd[data-host="m3d"]{left:auto;right:12px;top:96px}
.pod-vid{position:relative;width:100%;aspect-ratio:1/1;box-shadow:inset 0 0 0 4px #15191c,inset 0 0 0 5px #000;cursor:crosshair;touch-action:none}
.pod-osb{display:flex;gap:3px;background:#15191c;padding:4px}
.pod-osb button{flex:1;min-width:0;min-height:30px;padding:4px 2px;font:700 11px Consolas,"Courier New",monospace;color:#9effa8;background:#222a2f;border:1px solid #4a555c;border-radius:4px;letter-spacing:.5px;touch-action:manipulation}
.pod-osb button:active,.pod-osb button.on{background:#3d4d36;color:#d9ffd9}
.pod-mfd.full{inset:0;width:auto;z-index:1;border:0;border-radius:0;padding:0;background:transparent;box-shadow:none}
.pod-mfd.full .pod-vid{flex:1;aspect-ratio:auto;border:0}
.pod-mfd.full .pod-osb{position:absolute;left:50%;transform:translateX(-50%);width:min(560px,70vw);z-index:5;background:rgba(21,25,28,.82);border-radius:7px}
.pod-mfd.full .pod-vid{box-shadow:none}
.pod-mfd.full .pod-osb.alto{top:6px}
.pod-mfd.full .pod-osb.basso{bottom:6px}
.pod-mfd.full[data-host="volo"] .pod-osb.basso{top:42px;bottom:auto}
#mondo3d .m3d-bar,#mondo3d .m3d-info{z-index:3}
#vl-tgp.on,#m3d-tgp.on{background:#3d4d36;color:#d9ffd9;border-color:#7fbf6f}
@media (pointer:coarse),(max-width:900px){.pod-mfd{--pod-w:min(42vh,34vw)}.pod-osb button{min-height:26px;font-size:10px;padding:3px 1px}}
`;
  function cssUnaVolta() { if (document.getElementById("pod-css")) return; const st = document.createElement("style"); st.id = "pod-css"; st.textContent = CSS; document.head.appendChild(st); }
  function azione(a) {
    if (!S) return; const ho = HOSTS[S.hostId]; if (!S.on && a !== "toggle" && a !== "full") return;
    if (a === "toggle") return accendi(ho, S.on ? 0 : 1);
    if (a === "full") return accendi(ho, S.on === 2 ? 1 : 2);
    if (a === "off") return accendi(ho, 0);
    if (a === "fov" || a === "zin") { S.campo = a === "fov" ? (S.campo === 0 ? 1 : S.campo === 1 ? 2 : 0) : Math.min(CAMPI.length - 1, S.campo + 1); S.sfoc = 1; }
    else if (a === "sqrt") checkSquirters();
    else if (a === "zout") { S.campo = Math.max(0, S.campo - 1); S.sfoc = 1; }
    else if (a === "modo") { S.modo = (S.modo + 1) % MODI.length; S.sfoc = 0.5; S.agc.tlo = S.agc.lo; }
    else if (a === "track") cambiaTrack();
    else if (a === "tgt") cicloBersagli(1); else if (a === "tgtp") cicloBersagli(-1);
    else if (a === "lsr") { S.laserMan = !S.laserMan; avviso(S.laserMan ? "LASER ARM · FIRE" : "LASER SAFE"); }
    else if (a === "sp") { if (S.pf) { snowplow(); avviso("SNOWPLOW"); } }
    else if (a === "bld") { SANG.on = !SANG.on; try { localStorage.setItem("centurion_pod_sangue", SANG.on ? "1" : "0"); } catch (e) {} applicaSangue(); avviso(SANG.on ? "BLOOD ON" : "BLOOD OFF"); }
    aggiornaTasti(ho, true);
  }
  function accendi(ho, v) {
    if (!S || !ho) return; S.on = v; ho.ui.mfd.classList.toggle("hidden", !v); ho.ui.mfd.classList.toggle("full", v === 2); if (ho.ui.btn) ho.ui.btn.classList.toggle("on", !!v);
    if (v && !S.sitiPronti) sitiInit(); if (v && !S.spi) S.pfId = null; if (!v) { (H.altreTele ? H.altreTele() : []).forEach(c => S.rect && pulisci(c, S.rect)); }
    aggiornaTasti(ho, true);
  }
  function aggiornaTasti(ho, forza) {
    if (!ho || !S) return; const u = ho.ui; const set = (a, t, on) => { const b = u.osb[a]; if (!b) return; if (b.textContent !== t) b.textContent = t; b.classList.toggle("on", !!on); };
    set("fov", CAMPI[S.campo].nome + (CAMPI[S.campo].exp > 1 ? "×" + CAMPI[S.campo].exp : "")); set("modo", MODI[S.modo]); set("track", S.track === "POINT" ? "POINT" : "AREA", S.track === "POINT"); set("lsr", S.laserMan ? "LSR ON" : "LSR", S.laserMan || S.laser); set("full", S.on === 2 ? "MFD" : "FULL"); set("bld", SANG.on ? "BLD ON" : "BLD", SANG.on); set("sqrt", "SQRT", !!(S.sqrRichiesta && performance.now() < S.sqrRichiesta && Math.floor(performance.now() / 400) % 2));
  }
  function monta(cont, ad, opt) {
    if (typeof THREE === "undefined" || !cont) return; opt = opt || {}; cssUnaVolta(); const id = ad.id;
    if (HOSTS[id] && HOSTS[id].cont === cont) { HOSTS[id].ad = ad; return; }
    const mfd = document.createElement("div"); mfd.className = "pod-mfd hidden"; mfd.dataset.host = id;
    mfd.innerHTML = `<div class="pod-osb alto"><button data-a="fov" title="Campo WIDE 4° / NARROW 1° / SUPER NARROW 0,35° (tasti + e −: anche zoom digitale)">WIDE</button><button data-a="modo" title="Sensore: FLIR bianco caldo, nero caldo, TV (tasto M)">WHOT</button><button data-a="track" title="Inseguimento AREA / POINT (Invio o doppio tocco sull'immagine)">AREA</button><button data-a="tgt" title="Punta il bersaglio successivo (tasto .)">TGT ▶</button><button data-a="sqrt" title="CHECK FOR SQUIRTERS: campo largo sul punto d'impatto per cercare chi scappa (tasto 0)">SQRT</button><button data-a="full" title="A tutto schermo / display (tasto Y)">FULL</button></div>
      <div class="pod-vid" title="Trascina per spostare la linea di mira · doppio clic: POINT/AREA · rotella o pizzico: zoom"></div>
      <div class="pod-osb basso"><button data-a="zout" title="Zoom indietro (−)">−</button><button data-a="zin" title="Zoom avanti (+)">+</button><button data-a="lsr" title="Laser: armato e in emissione manuale">LSR</button><button data-a="tgtp" title="Bersaglio precedente (tasto ,)">◀ TGT</button><button data-a="sp" title="Linea di mira davanti al velivolo (snowplow)">SP</button><button data-a="bld" title="Sangue e ferite visibili: acceso / spento (spento di serie)">BLD</button><button data-a="off" title="Spegni il display del pod (tasto Y)">✕</button></div>`;
    cont.appendChild(mfd); const vid = mfd.querySelector(".pod-vid"); const osb = {}; mfd.querySelectorAll("[data-a]").forEach(b => { osb[b.dataset.a] = b; b.addEventListener("click", e => { e.stopPropagation(); attiva(id); azione(b.dataset.a); }); b.addEventListener("pointerdown", e => e.stopPropagation()); });
    let btn = null; if (opt.barra) { btn = document.createElement("button"); btn.id = id === "volo" ? "vl-tgp" : "m3d-tgp"; btn.className = opt.classe || ""; btn.textContent = "TGP"; btn.title = "Pod di designazione: FLIR / TV con laser (tasto Y)"; btn.onclick = () => { attiva(id); azione("toggle"); }; if (opt.prima && opt.prima.parentNode === opt.barra) opt.barra.insertBefore(btn, opt.prima); else opt.barra.appendChild(btn); }
    if (opt.hint) opt.hint.textContent += " · Y: pod di designazione (FLIR/TV, laser)";
    const ho = HOSTS[id] = { id, cont, ad, ui: { mfd, vid, osb, btn } };
    // trascinamento = spostamento della linea di mira; doppio tocco = POINT/AREA; pizzico/rotella = zoom
    const pts = new Map(); let pinch = 0, tap = 0;
    vid.addEventListener("pointerdown", e => { e.preventDefault(); e.stopPropagation(); attiva(id); vid.setPointerCapture(e.pointerId); pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = Math.hypot(a.x - b.x, a.y - b.y); } else { const n = performance.now(); if (n - tap < 320) { azione("track"); tap = 0; } else tap = n; } });
    vid.addEventListener("pointermove", e => { const p = pts.get(e.pointerId); if (!p || !S || !S.on) return; e.preventDefault();
      if (pts.size >= 2) { p.x = e.clientX; p.y = e.clientY; const [a, b] = [...pts.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (pinch > 0 && d / pinch > 1.35) { azione("zin"); pinch = d; } else if (pinch > 0 && d / pinch < 0.74) { azione("zout"); pinch = d; } return; }
      const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY; const r = vid.getBoundingClientRect(); const fov = CAMPI[S.campo].deg * D2R; S.slew.x += dx / Math.max(1, r.width) * fov; S.slew.y -= dy / Math.max(1, r.height) * fov * (r.height / Math.max(1, r.width)); });
    const fine = e => { pts.delete(e.pointerId); if (pts.size < 2) pinch = 0; };
    vid.addEventListener("pointerup", fine); vid.addEventListener("pointercancel", fine);
    vid.addEventListener("wheel", e => { e.preventDefault(); e.stopPropagation(); attiva(id); azione(e.deltaY < 0 ? "zin" : "zout"); }, { passive: false });
    vid.addEventListener("contextmenu", e => e.preventDefault());
    if (!monta.tasti) { monta.tasti = true;
      window.addEventListener("keydown", e => { const ho2 = hostVisibile(); if (!ho2 || /INPUT|SELECT|TEXTAREA/.test((e.target && e.target.tagName) || "")) return; const k = e.key.toLowerCase(); attiva(ho2.id);
        if (S && S.on && "ijkl".includes(k) && k.length === 1) { KEYS[k] = true; e.preventDefault(); return; } if (e.repeat) return; const a = mappaTasto(k); if (a) { e.preventDefault(); azione(a); } });
      window.addEventListener("keyup", e => { KEYS[e.key.toLowerCase()] = false; }); window.addEventListener("blur", () => { "ijkl".split("").forEach(k => KEYS[k] = false); }); }
  }
  function mappaTasto(k) { if (k === "y") return S && S.on === 2 ? "off" : S && S.on === 1 ? "full" : "toggle"; if (!S || !S.on) return null; return { m: "modo", "+": "zin", "=": "zin", "-": "zout", enter: "track", ".": "tgt", ",": "tgtp", backspace: "sp", "0": "sqrt" }[k] || null; }
  function hostVisibile() { for (const id in HOSTS) { const ho = HOSTS[id]; try { if (ho.ad.visibile && ho.ad.visibile()) return ho; } catch (e) {} } return null; }
  function attiva(id) { const ho = HOSTS[id]; if (!ho) return; H = ho.ad; const sc = H.scene && H.scene(); if (!sc) return; if (!S || S.scena !== sc || S.hostId !== id) { S = nuovoStato(sc); S.hostId = id; DR.zB = null; if (DR.pronto) { DR.A.z = DR.B.z = -1; } ho.ui.mfd.classList.add("hidden"); ho.ui.mfd.classList.remove("full"); if (ho.ui.btn) ho.ui.btn.classList.remove("on"); } }

  /* ---------- ciclo per fotogramma (chiamato dall'host dopo il proprio disegno) ---------- */
  function frame(id, dt) {
    const ho = HOSTS[id]; if (!ho) return; attiva(id); if (!S) return;
    // simbologia aria-suolo nell'HUD del volo (pipper del cannone anche a pod spento, riquadro TD con il pod acceso)
    if (H.arma && H.visibile && H.visibile()) { try { hudAG(); } catch (e) {} }
    if (!S.on) return; dt = clamp(dt || 0.016, 0, 0.1);
    if (!(H.visibile && H.visibile())) { ho.ui.mfd.classList.add("hidden"); return; } ho.ui.mfd.classList.remove("hidden");
    // a tutto schermo l'immagine lascia libere la barra comandi in alto e le informazioni in basso dell'host
    // (anche il display ridotto si mette subito sotto la barra, che sui telefoni cambia altezza)
    const mf = ho.ui.mfd; if (H.margini) { const m = H.margini(); const t = Math.max(0, Math.round(m.top || 0)) + "px", b = S.on === 2 ? Math.max(0, Math.round(m.bottom || 0)) + "px" : ""; if (mf.style.top !== t) mf.style.top = t; if (mf.style.bottom !== b) mf.style.bottom = b; }
    try {
      if (!S.sitiPronti) sitiInit(); sitiAggiorna(dt, false); S.siti.forEach(popola); if (H.motore) { fxInit(); missioni(dt); } aggiornaSquirters(dt); cannoneSuolo(); if (FX.pool && FX.scena === H.scene()) fxAggiorna(dt);
      if (cinematica(dt)) rendi(ho, dt); else S.rect = rettangolo(ho);
      simbologia(); aggiornaTasti(ho);
    } catch (e) { if (!frame.errore) { frame.errore = true; console.warn("POD", e); } }
  }
  // per il volo libero: dice se il tasto appartiene al pod (così il volo non lo usa per altro, es. L giorno/notte)
  function tasto(k) { if (k === "y") return true; if (!S || !S.on) return false; return "ijklm+=-.,0".includes(k) || k === "enter" || k === "backspace"; }
  function bersaglioTracciato() {
    if (!S || !S.on || !S.spi) return null; if (S.item && S.item.sito && S.item.sito.volo && itemVivo(S.item)) return S.item.sito.ref;
    if (S.track !== "RATES") { const s = S.siti.find(x => x.volo && sitoVivo(x) && x.pos.distanceTo(S.spi) < 250); if (s) return s.ref; } return null;
  }
  return { monta, frame, tasto, bersaglioTracciato, get attivo() { return !!(S && S.on); }, get debug() { return S && { on: S.on, campo: CAMPI[S.campo].nome + CAMPI[S.campo].exp, modo: MODI[S.modo], track: S.track, range: Math.round(S.range), az: Math.round(S.az), el: Math.round(S.el), maschera: +S.maschera.toFixed(2), laser: S.laser, tti: S.tti, siti: S.siti.length, items: S.siti.reduce((a, s) => a + s.items.length, 0), bombe: S.bombe.length, fuochi: S.fuochi.length, agc: [+S.agc.lo.toFixed(2), +S.agc.hi.toFixed(2)], drape: DR.pronto ? [DR.A.z, DR.B.z] : null, spi: S.spi && S.spi.toArray().map(Math.round), item: S.item && S.item.tipo }; },
    _test: { azione: a => azione(a), stato: () => S, host: () => H, risorse: () => R, allarme: p => S && allarme(S.sito, p || S.spi.clone()) } };
})();
