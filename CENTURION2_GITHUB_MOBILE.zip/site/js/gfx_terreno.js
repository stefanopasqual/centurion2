/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA · 5 – TERRENO SENZA CHIAZZE
   Il Free Flight sovrappone il terreno di base (riquadri z10/z11) e tre livelli ad alta risoluzione
   (gruppo CENTURION_HD_REAL_ELEVATION di terrain_mobile.js: z12, z15, z17). I livelli hanno quote
   un po' diverse: dove quello più grossolano sta più in alto buca le immagini nitide (chiazze sfocate o
   marroni), e le piazzole grigie della vita a terra (SIMULATED_CIVILIAN_GROUND_LIFE) affiorano.
   Questo modulo, senza toccare terrain_mobile.js né volo.js:
   - abbassa i vertici di ogni livello più grossolano SOLO sotto i riquadri più fini già caricati
     (base −60 m sotto l'HD, z12 −35 m sotto z15/z17, z15 −15 m sotto z17), con una sfumatura stretta
     verso i lati che danno sul vuoto; fuori dalla copertura le quote restano quelle vere;
   - solleva di poco i livelli fini (z15 +1,2 m, z17 +2,5 m), come fa la missione DUDE 44;
   - appoggia i villaggi della vita a terra sulla superficie nitida visibile invece che sul rilievo di base.
   La fisica non cambia (usa il modello del terreno, non le maglie). Si mette da parte da solo se un altro
   modulo sta già riallineando il terreno (missione DUDE 44: ZAGROS.allinea). Attivo da qualità BASSA,
   anche di notte (costa solo CPU, ogni mezzo secondo e solo sui riquadri cambiati).
   ===================================================================== */
window.CENTURION_TERRENO_GFX = window.CENTURION_TERRENO_GFX || (() => {
  "use strict";
  const T = window.THREE, G = window.CENTURION_GFX; if (!T || !G) return null;
  const P = { base: 60, z12: 35, z15: 15, alzo15: 1.2, alzo17: 2.5, intervallo: 500 };
  const st = { mod: new Set(), alzati: new Set(), tUlt: 0, villaggi: new Map(), ray: new T.Raycaster(), fermo: false };

  const gruppo = (root, nome) => root ? root.children.find(o => o.name === nome) : null;
  function livello(m) { const r = m.renderOrder || 0; return r >= 17 ? 17 : r >= 15 ? 15 : r >= 12 ? 12 : 0; }
  function rettangolo(m) {
    const g = m.geometry; if (!g.boundingBox) g.computeBoundingBox(); const b = g.boundingBox;
    return { lv: livello(m), x0: m.position.x + b.min.x, x1: m.position.x + b.max.x, z0: m.position.z + b.min.z, z1: m.position.z + b.max.z, id: m.id };
  }
  // copertura 0..1: 1 dentro il riquadro, sfumata a 0 solo verso i lati che danno sul vuoto (nessun riquadro
  // fine accanto). Sui lati condivisi la maglia grossolana resta sotto, così il bordo comune non sfarfalla.
  function lati(r, insieme) {
    const e = (r.x1 - r.x0) * 0.02, mx = (r.x0 + r.x1) / 2, mz = (r.z0 + r.z1) / 2;
    const dentro = (x, z) => insieme.some(f => f !== r && x > f.x0 && x < f.x1 && z > f.z0 && z < f.z1);
    return [dentro(r.x0 - e, mz), dentro(r.x1 + e, mz), dentro(mx, r.z0 - e), dentro(mx, r.z1 + e)];
  }
  function copertura(r, x, z) {
    if (x <= r.x0 || x >= r.x1 || z <= r.z0 || z >= r.z1) return 0;
    const banda = (r.x1 - r.x0) * 0.05, a = r.aperti, G = 1e9;
    const d = Math.min(a[0] ? G : x - r.x0, a[1] ? G : r.x1 - x, a[2] ? G : z - r.z0, a[3] ? G : r.z1 - z);
    const k = Math.min(1, d / banda); return k * k * (3 - 2 * k);
  }
  // griglia regolare della PlaneGeometry (ruotata in orizzontale): da (x, z) mondo all'indice di colonna/riga
  function griglia(m) {
    const g = m.geometry, p = g.parameters; if (!p || p.widthSegments == null) return null;
    const a = g.attributes.position.array, nx = p.widthSegments + 1, ny = p.heightSegments + 1;
    if (a.length !== nx * ny * 3) return null;
    const x0 = a[0], z0 = a[2], dx = (a[(nx - 1) * 3] - x0) / (nx - 1), dz = (a[(ny - 1) * nx * 3 + 2] - z0) / (ny - 1);
    if (!dx || !dz) return null;
    return { nx, ny, x0: x0 + m.position.x, z0: z0 + m.position.z, dx, dz };
  }
  function abbassa(m, lv, fini) {
    const pos = m.geometry && m.geometry.attributes.position; if (!pos) return false;
    const u = m.userData;
    const r = rettangolo(m); const tutti = fini.filter(f => f.lv > lv), sopra = tutti.filter(f => f.x1 > r.x0 && f.x0 < r.x1 && f.z1 > r.z0 && f.z0 < r.z1);
    const chiave = sopra.map(f => f.id).join(",") + "|" + tutti.length;
    // le quote originali si rileggono se qualcun altro ha riscritto la maglia (volo.js riquota quando arriva il DEM)
    if (!u.gfxY || u.gfxVer !== pos.version) { if (!sopra.length && !u.gfxY) return false; u.gfxY = Float32Array.from({ length: pos.count }, (_, i) => pos.array[i * 3 + 1]); u.gfxChiave = null; }
    if (u.gfxChiave === chiave) return false;
    sopra.forEach(f => { f.aperti = lati(f, tutti); });
    const D = lv === 0 ? P.base : lv === 12 ? P.z12 : P.z15, arr = pos.array, n = pos.count, k = new Float32Array(n), gr = griglia(m);
    for (const f of sopra) {
      if (gr) {   // solo le colonne e le righe sotto il riquadro fine
        const c0 = Math.max(0, Math.floor(Math.min((f.x0 - gr.x0) / gr.dx, (f.x1 - gr.x0) / gr.dx))), c1 = Math.min(gr.nx - 1, Math.ceil(Math.max((f.x0 - gr.x0) / gr.dx, (f.x1 - gr.x0) / gr.dx)));
        const r0 = Math.max(0, Math.floor(Math.min((f.z0 - gr.z0) / gr.dz, (f.z1 - gr.z0) / gr.dz))), r1 = Math.min(gr.ny - 1, Math.ceil(Math.max((f.z0 - gr.z0) / gr.dz, (f.z1 - gr.z0) / gr.dz)));
        for (let j = r0; j <= r1; j++) { const z = gr.z0 + j * gr.dz; for (let c = c0; c <= c1; c++) { const i = j * gr.nx + c, v = copertura(f, gr.x0 + c * gr.dx, z); if (v > k[i]) k[i] = v; } }
      } else {
        const ox = m.position.x, oz = m.position.z;
        for (let i = 0; i < n; i++) { const v = copertura(f, ox + arr[i * 3], oz + arr[i * 3 + 2]); if (v > k[i]) k[i] = v; }
      }
    }
    const y0 = u.gfxY; for (let i = 0; i < n; i++) arr[i * 3 + 1] = y0[i] - D * k[i];
    pos.needsUpdate = true; m.geometry.computeBoundingSphere(); u.gfxVer = pos.version; u.gfxChiave = chiave; st.mod.add(m);
    return true;
  }
  function ripristina() {
    st.mod.forEach(m => { const u = m.userData, pos = m.geometry && m.geometry.attributes.position;
      if (pos && u.gfxY && u.gfxVer === pos.version) { for (let i = 0; i < pos.count; i++) pos.setY(i, u.gfxY[i]); pos.needsUpdate = true; m.geometry.computeBoundingSphere(); }
      u.gfxY = null; u.gfxVer = null; u.gfxChiave = null; });
    st.mod.clear();
    st.alzati.forEach(m => { if (m.position.y === P.alzo15 || m.position.y === P.alzo17) m.position.y = 0; }); st.alzati.clear();
    st.villaggi.clear();
  }
  // un altro modulo (missione DUDE 44) sta già spostando il terreno: meglio non sovrapporsi
  function altroAllineamento(hd, base) {
    if (hd && (hd.position.y !== 0 || hd.children.some(m => m.userData && m.userData.zgY))) return true;
    return base.some(m => m.position.y !== 0);
  }
  function villaggi(ctx, hd, vita) {
    if (!vita || !hd) return;
    const tiles = hd.children.filter(m => m.isMesh && m.visible && m.material && m.material.map);
    vita.children.forEach(s => {
      if (!s.visible) return; const k = Math.round(s.position.x) + "," + Math.round(s.position.z);
      let v = st.villaggi.get(s);
      if (!v || v.k !== k || ctx.t - v.t > 3) {
        st.ray.set(new T.Vector3(s.position.x, 12000, s.position.z), new T.Vector3(0, -1, 0)); st.ray.far = 20000;
        const hit = st.ray.intersectObjects(tiles, false)[0];
        v = { k, t: ctx.t, y: hit ? hit.point.y : null }; st.villaggi.set(s, v);
      }
      if (v.y != null && Math.abs(s.position.y - v.y) > 0.01) s.position.y = v.y;
    });
  }

  const mod = G.registra({
    nome: "terreno", min: 1, ordine: 1, notte: true,
    monta() { st.tUlt = 0; st.fermo = false; },
    smonta() { ripristina(); },
    prima(ctx) {
      const S = ctx.S, root = S.root; if (!root) return;
      const hd = gruppo(root, "CENTURION_HD_REAL_ELEVATION"), vita = gruppo(root, "SIMULATED_CIVILIAN_GROUND_LIFE");
      const base = root.children.filter(m => m.isMesh && m.userData && m.userData.tx !== undefined);
      if (altroAllineamento(hd, base)) { if (!st.fermo) { ripristina(); st.fermo = true; } return; }
      st.fermo = false;
      villaggi(ctx, hd, vita);                                   // ogni fotogramma (la vita a terra riposa i villaggi ogni 0,8 s)
      const now = performance.now(); if (now - st.tUlt < P.intervallo || !hd) return; st.tUlt = now;
      const tiles = hd.children.filter(m => m.isMesh && m.geometry);
      tiles.forEach(m => { const lv = livello(m), y = lv === 17 ? P.alzo17 : lv === 15 ? P.alzo15 : 0; if (m.position.y !== y) { m.position.y = y; m.updateMatrixWorld(true); } if (y) st.alzati.add(m); });
      const t0 = performance.now();
      const fini = tiles.filter(m => m.visible && m.material && m.material.map && livello(m) >= 12).map(rettangolo);
      // al massimo 4 maglie riscritte per giro (2 in qualità BASSA): niente scatti mentre il terreno HD arriva in volo
      let fatte = 0; const coda = base.map(m => [m, 0]).concat(tiles.filter(m => { const lv = livello(m); return lv === 12 || lv === 15; }).map(m => [m, livello(m)]));
      const lim = ctx.livello >= 2 ? 4 : 2; for (const [m, lv] of coda) { if (fatte >= lim) { st.tUlt = now - P.intervallo + 60; break; } if (abbassa(m, lv, fini)) fatte++; }
      st.ms = performance.now() - t0; st.msMax = Math.max(st.msMax || 0, st.ms);
      // riquadri HD scaricati: si dimenticano
      st.mod.forEach(m => { if (!m.parent) st.mod.delete(m); }); st.alzati.forEach(m => { if (!m.parent) st.alzati.delete(m); });
    }
  });
  return { P, mod, info: () => ({ maglie: st.mod.size, ms: +(st.ms || 0).toFixed(1), msMax: +(st.msMax || 0).toFixed(1), fermo: st.fermo }) };
})();
