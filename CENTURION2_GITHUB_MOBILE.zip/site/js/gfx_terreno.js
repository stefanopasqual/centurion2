/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA · 5 – TERRENO SENZA CHIAZZE
   Il Free Flight sovrappone il terreno di base (riquadri z10/z11 di volo.js) e tre livelli ad alta
   risoluzione (gruppo CENTURION_HD_REAL_ELEVATION di terrain_mobile.js: z12, z15, z17), ognuno con il
   suo rilievo. Sui pendii ripidi il livello grossolano sta anche 100 m sopra quello fine e lo buca:
   chiazze sfocate, marroni o scure. Abbassarlo di una quota fissa non basta (prima versione).
   Qui il livello grossolano NON si disegna dove ce n'è uno più fine:
   - tutti i riquadri (base e HD) stanno sulla stessa griglia di tessere (cella = una tessera z17, ~210 m
     alle Dolomiti); una piccola texture di copertura, rifatta solo quando cambiano i riquadri caricati,
     dice per ogni cella il livello più fine presente (R) e il minimo fra la cella e le 8 vicine (G);
   - nello shader di ogni maglia grossolana: se anche le vicine sono coperte da un livello più fine il
     frammento si scarta; nella fascia di bordo (una cella) resta, ma spinto indietro nella profondità
     logaritmica di qualche decina di metri (in proporzione alla distanza), così il nitido vince e fra
     i due livelli non si apre nessuna fessura;
   - i villaggi della vita a terra si appoggiano sulla superficie nitida visibile.
   Niente vertici riscritti: la CPU lavora solo quando cambia l'elenco dei riquadri (texture di poche
   decine di KB) e il terreno reagisce nello stesso fotogramma in cui un riquadro arriva o viene scaricato.
   terrain_mobile.js, volo.js e la fisica non cambiano. Attivo da BASSA in su, anche di notte.
   ===================================================================== */
window.CENTURION_TERRENO_GFX = window.CENTURION_TERRENO_GFX || (() => {
  "use strict";
  const T = window.THREE, G = window.CENTURION_GFX; if (!T || !G) return null;
  const P = { spinta: 0.04, spintaMin: 8, spintaMax: 300, maxCelle: 1024 };
  // uniformi condivise da tutte le maglie grossolane (ogni materiale aggiunge solo il proprio livello)
  const U = { uCov: { value: null }, uCovO: { value: new T.Vector2() }, uCovS: { value: new T.Vector2() }, uCovOn: { value: 0 }, uCovK: { value: new T.Vector3(P.spinta, P.spintaMin, P.spintaMax) } };
  const st = { firma: "", tex: null, data: null, w: 0, h: 0, agganciati: 0, villaggi: new Map(), ray: new T.Raycaster(), ms: 0, msMax: 0, celle: 0 };

  const gruppo = (root, nome) => root ? root.children.find(o => o.name === nome) : null;
  function livello(m) { const r = m.renderOrder || 0; return r >= 17 ? 17 : r >= 15 ? 15 : r >= 12 ? 12 : 0; }
  function rettangolo(m) {
    const g = m.geometry; if (!g.boundingBox) g.computeBoundingBox(); const b = g.boundingBox;
    return { lv: livello(m), x0: m.position.x + b.min.x, x1: m.position.x + b.max.x, z0: m.position.z + b.min.z, z1: m.position.z + b.max.z };
  }

  /* ---------- aggancio allo shader dei materiali grossolani ---------- */
  function aggancia(mat, lv) {
    if (!mat || mat.userData.gfxCov != null) return; mat.userData.gfxCov = lv;
    const prima = mat.onBeforeCompile, chiave = mat.customProgramCacheKey;
    mat.onBeforeCompile = function (sh, r) {
      if (prima) prima.call(this, sh, r);
      Object.assign(sh.uniforms, U); sh.uniforms.uCovLv = { value: lv };
      sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nvarying vec2 vCovXZ;")
        .replace("#include <project_vertex>", "#include <project_vertex>\n\tvCovXZ = ( modelMatrix * vec4( transformed, 1.0 ) ).xz;");
      sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\nvarying vec2 vCovXZ;\nuniform sampler2D uCov;\nuniform vec2 uCovO, uCovS;\nuniform vec3 uCovK;\nuniform float uCovOn, uCovLv;\nfloat covSpinta = 0.0;")
        .replace("void main() {", `void main() {
	if ( uCovOn > 0.5 ) {
		vec2 cu = ( vCovXZ - uCovO ) * uCovS;
		if ( cu.x > 0.0 && cu.x < 1.0 && cu.y > 0.0 && cu.y < 1.0 ) {
			vec4 cv = texture2D( uCov, cu ) * 255.0;
			if ( cv.g > uCovLv + 0.5 ) discard;          // coperto anche tutt'intorno da un livello più fine
			if ( cv.r > uCovLv + 0.5 ) covSpinta = 1.0;  // fascia di bordo: resta, ma dietro al livello fine
		}
	}`)
        .replace("#include <logdepthbuf_fragment>", `#include <logdepthbuf_fragment>
	#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
		if ( covSpinta > 0.5 && vIsPerspective != 0.0 ) gl_FragDepthEXT = log2( vFragDepth + clamp( vFragDepth * uCovK.x, uCovK.y, uCovK.z ) ) * logDepthBufFC * 0.5;
	#endif`);
    };
    mat.customProgramCacheKey = function () { return (chiave ? chiave.call(this) : "") + "|gfxCov"; };
    mat.needsUpdate = true; st.agganciati++;
  }

  /* ---------- texture di copertura ---------- */
  function rifaiCopertura(fini) {
    const t0 = performance.now();
    if (!fini.length) { U.uCovOn.value = 0; st.celle = 0; return; }
    // cella = tessera z17 (i livelli z12/z15 sono 32×32 e 4×4 celle); origine allineata a un riquadro qualunque
    const a = fini[0], cella = (a.x1 - a.x0) / Math.pow(2, 17 - a.lv);
    const snap = (v, o) => o + Math.round((v - o) / cella) * cella;
    let X0 = Infinity, X1 = -Infinity, Z0 = Infinity, Z1 = -Infinity;
    fini.forEach(f => { X0 = Math.min(X0, f.x0); X1 = Math.max(X1, f.x1); Z0 = Math.min(Z0, f.z0); Z1 = Math.max(Z1, f.z1); });
    X0 = snap(X0, a.x0) - cella; Z0 = snap(Z0, a.z0) - cella;                     // una cella vuota di margine
    let w = Math.round((snap(X1, a.x0) - X0) / cella) + 1, h = Math.round((snap(Z1, a.z0) - Z0) / cella) + 1;
    w = Math.min(w, P.maxCelle); h = Math.min(h, P.maxCelle);
    if (!st.tex || st.w !== w || st.h !== h) {
      if (st.tex) st.tex.dispose();
      st.data = new Uint8Array(w * h * 4); st.w = w; st.h = h;
      st.tex = new T.DataTexture(st.data, w, h, T.RGBAFormat, T.UnsignedByteType);
      st.tex.magFilter = st.tex.minFilter = T.NearestFilter; st.tex.generateMipmaps = false; st.tex.flipY = false;
      U.uCov.value = st.tex;
    }
    const L = new Uint8Array(w * h), d = st.data;
    fini.forEach(f => {
      const c0 = Math.max(0, Math.round((f.x0 - X0) / cella)), c1 = Math.min(w, Math.round((f.x1 - X0) / cella));
      const r0 = Math.max(0, Math.round((f.z0 - Z0) / cella)), r1 = Math.min(h, Math.round((f.z1 - Z0) / cella));
      for (let r = r0; r < r1; r++) for (let c = c0; c < c1; c++) { const i = r * w + c; if (f.lv > L[i]) L[i] = f.lv; }
    });
    for (let r = 0; r < h; r++) for (let c = 0; c < w; c++) {
      let m = 255; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { const rr = r + dr, cc = c + dc; const v = (rr < 0 || cc < 0 || rr >= h || cc >= w) ? 0 : L[rr * w + cc]; if (v < m) m = v; }
      const i = (r * w + c) * 4; d[i] = L[r * w + c]; d[i + 1] = m; d[i + 2] = 0; d[i + 3] = 255;
    }
    st.tex.needsUpdate = true;
    U.uCovO.value.set(X0, Z0); U.uCovS.value.set(1 / (w * cella), 1 / (h * cella)); U.uCovOn.value = 1;
    st.celle = w * h; st.ms = performance.now() - t0; st.msMax = Math.max(st.msMax, st.ms);
  }

  /* ---------- villaggi della vita a terra sulla superficie nitida ---------- */
  function villaggi(ctx, hd, vita) {
    if (!vita || !hd || !vita.visible) return;
    const tiles = hd.children.filter(m => m.isMesh && m.visible && m.material && m.material.map);
    vita.children.forEach(s => {
      if (!s.visible) return; const k = Math.round(s.position.x) + "," + Math.round(s.position.z);
      let v = st.villaggi.get(s);
      if (!v || v.k !== k || ctx.t - v.t > 3) {
        st.ray.set(new T.Vector3(s.position.x, 12000, s.position.z), new T.Vector3(0, -1, 0)); st.ray.far = 20000;
        const hit = st.ray.intersectObjects(tiles, false)[0];
        v = { k, t: ctx.t, y: hit ? hit.point.y : null }; st.villaggi.set(s, v);
      }
      if (v.y != null && Math.abs(s.position.y - v.y) > 0.01) s.position.y = v.y;
    });
  }

  const mod = G.registra({
    nome: "terreno", min: 1, ordine: 1, notte: true,
    monta() { st.firma = ""; },
    smonta() { U.uCovOn.value = 0; st.firma = ""; st.villaggi.clear(); },   // i materiali agganciati tornano identici (ramo spento)
    prima(ctx) {
      const S = ctx.S, root = S.root; if (!root) return;
      const hd = gruppo(root, "CENTURION_HD_REAL_ELEVATION"), vita = gruppo(root, "SIMULATED_CIVILIAN_GROUND_LIFE");
      // maglie grossolane: terreno di base (userData.tx) e riquadri HD z12/z15
      root.children.forEach(m => { if (m.isMesh && m.userData && m.userData.tx !== undefined) aggancia(m.material, 0); });
      const tiles = hd ? hd.children.filter(m => m.isMesh && m.geometry) : [];
      tiles.forEach(m => { const lv = livello(m); if (lv === 12 || lv === 15) aggancia(m.material, lv); });
      // la copertura si rifà solo quando cambia l'elenco dei riquadri nitidi pronti (con immagine)
      const pronti = tiles.filter(m => m.visible && m.material && m.material.map && livello(m) >= 12);
      const firma = pronti.map(m => m.id).join(",");
      if (firma !== st.firma) { st.firma = firma; rifaiCopertura(pronti.map(rettangolo)); }
      villaggi(ctx, hd, vita);
    }
  });
  return { P, mod, info: () => ({ celle: st.celle, ms: +st.ms.toFixed(1), msMax: +st.msMax.toFixed(1), on: U.uCovOn.value, materiali: st.agganciati }) };
})();
