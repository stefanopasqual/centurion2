/* =====================================================================
   CENTURION 2 · GRAFICA AVANZATA DEL FREE FLIGHT – nucleo comune
   - Interruttore di qualità unico per i moduli grafici (gfx_atmosfera, gfx_nuvole, gfx_luce, gfx_materiali):
       0 = SPENTA (grafica originale di volo.js), 1 = BASSA (telefoni), 2 = MEDIA, 3 = ALTA; "auto" sceglie
     dal dispositivo e scende di un livello da solo se i fotogrammi diventano troppo lenti.
     Scelta salvata in localStorage ("centurion_gfx"), forzabile con ?gfx=0..3, ?ora=19.5, ?nuvole=coperto.
   - Aggancio senza toccare volo.js: il renderer del Free Flight (canvas #vl-canvas) viene riconosciuto alla
     nascita; il suo render() viene avvolto solo per la scena principale disegnata a schermo (pod, camera
     termica e altre scene passano invariati). Se un modulo si rompe viene spento e il volo continua.
   - Pulsante "GFX" nella barra del Free Flight: qualità, ora del giorno, nuvole.
   Caricato prima di js/volo.js (dopo three.min.js).
   ===================================================================== */
window.CENTURION_GFX = window.CENTURION_GFX || (() => {
  "use strict";
  const T = window.THREE; if (!T) return null;
  const KEY = "centurion_gfx";
  const moduli = [];                 // { nome, min, monta, smonta, prima, dopo, rendi, cielo }
  const ctx = { renderer: null, scene: null, camera: null, S: null, livello: 0, attivo: false, post: false, dt: 0, t: 0 };
  const NOMI = ["SPENTA", "BASSA", "MEDIA", "ALTA"];

  /* ---------- impostazioni ---------- */
  function leggi() { try { return JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { return {}; } }
  function salva(o) { try { localStorage.setItem(KEY, JSON.stringify(Object.assign(leggi(), o))); } catch (e) {} }
  const url = new URLSearchParams(location.search);
  const imp = Object.assign({ livello: "auto", ora: null, nuvole: "auto" }, leggi());
  if (url.has("gfx")) imp.livello = url.get("gfx") === "auto" ? "auto" : Math.max(0, Math.min(3, +url.get("gfx") || 0));
  if (url.has("ora")) imp.ora = +url.get("ora");
  if (url.has("nuvole")) imp.nuvole = url.get("nuvole");

  // livello automatico: telefoni e tablet BASSA, grafica integrata MEDIA, scheda dedicata ALTA
  function gpuNome(r) { try { const gl = r.getContext(); const d = gl.getExtension("WEBGL_debug_renderer_info"); return String(d ? gl.getParameter(d.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER)); } catch (e) { return ""; } }
  function livelloAuto(r) {
    const touch = matchMedia("(pointer:coarse)").matches, mem = navigator.deviceMemory || 4, g = gpuNome(r);
    if (!r.capabilities.isWebGL2) return 1;
    if (touch || /Mali|Adreno|PowerVR|Apple GPU|Mobile/i.test(g)) return mem >= 6 && /Apple|Adreno \(TM\) [6-9]\d\d/i.test(g) ? 2 : 1;
    if (/Intel|UHD|Iris|Radeon\(TM\) Graphics|Vega \d Graphics|SwiftShader|llvmpipe/i.test(g)) return 2;
    return 3;
  }
  let autoCalo = 0;                  // livelli tolti dal controllo automatico dei fotogrammi
  function livelloEffettivo() {
    if (!ctx.renderer) return 0;
    if (imp.livello !== "auto") return +imp.livello;
    return Math.max(1, livelloAuto(ctx.renderer) - autoCalo);
  }

  /* ---------- riconoscimento del renderer del Free Flight ---------- */
  const Orig = T.WebGLRenderer;
  class RendererCenturion extends Orig {
    constructor(p) { super(p); try { if (p && p.canvas && p.canvas.id === "vl-canvas") avvolgi(this); } catch (e) { console.warn("GFX", e); } }
  }
  T.WebGLRenderer = RendererCenturion;

  function scenaVolo(scene) {
    const S = (typeof VOLO !== "undefined") ? VOLO.stato : null;
    return !!(S && S.root && S.root.parent === scene) ? S : null;
  }
  function avvolgi(r) {
    ctx.renderer = r; const orig = r.render.bind(r);
    r.render = function (scene, camera) {
      const S = (r.getRenderTarget() === null && !r.xr.isPresenting) ? scenaVolo(scene) : null;
      if (!S) return orig(scene, camera);
      try { prepara(S, scene, camera); } catch (e) { guasto("prepara", e); }
      let fatto = false;
      if (ctx.attivo) for (const m of moduli) if (m.on && m.rendi) { try { fatto = m.rendi(ctx, orig) === true; } catch (e) { guasto(m.nome, e, m); } if (fatto) break; }
      if (!fatto) orig(scene, camera);
      if (ctx.attivo) for (const m of moduli) if (m.on && m.dopo) { try { m.dopo(ctx); } catch (e) { guasto(m.nome, e, m); } }
    };
    r.__centurionGfx = true;
  }

  /* ---------- ciclo per fotogramma ---------- */
  let tPrec = 0, campioni = [], ultimoControllo = 0;
  function prepara(S, scene, camera) {
    const now = performance.now(), dt = tPrec ? Math.min(0.1, (now - tPrec) / 1000) : 0.016; tPrec = now;
    const nuovaScena = ctx.scene !== scene; ctx.S = S; ctx.scene = scene; ctx.camera = camera; ctx.dt = dt; ctx.t += dt;
    const liv = livelloEffettivo(); const notte = S.cfg && S.cfg.ora === "notte";
    if (nuovaScena) { moduli.forEach(m => { if (m.on) spegni(m); }); ctx.cupola = null; }
    ctx.livello = liv; ctx.attivo = liv > 0; ctx.notte = notte;
    // il cielo di volo.js è stato rifatto (avvio, giorno/notte): i moduli ripartono dal cielo nuovo
    if (ctx.cupola !== S.cupola) { const prima = ctx.cupola; ctx.cupola = S.cupola; if (prima) moduli.forEach(m => { if (m.on) spegni(m); }); }
    for (const m of moduli) {
      const deve = ctx.attivo && liv >= m.min && !(notte && !m.notte) && !m.guasto && !(imp.escludi || []).includes(m.nome);   // escludi: solo per prove e confronti
      if (deve && !m.on) { try { m.monta && m.monta(ctx); m.on = true; } catch (e) { guasto(m.nome, e, m); } }
      else if (!deve && m.on) spegni(m);
    }
    ctx.post = moduli.some(m => m.on && m.rendi);
    for (const m of moduli) if (m.on && m.prima) { try { m.prima(ctx); } catch (e) { guasto(m.nome, e, m); } }
    // controllo automatico: se in "auto" la media supera 45 ms per 4 s, si scende di un livello
    if (imp.livello === "auto" && dt < 0.25 && !S.pausa) {
      campioni.push(dt);
      if (now - ultimoControllo > 4000) { ultimoControllo = now; if (campioni.length > 40) { const media = campioni.reduce((a, b) => a + b, 0) / campioni.length; if (media > 0.045 && liv > 1) { autoCalo++; avviso("GRAFICA " + NOMI[livelloEffettivo()] + " (auto)"); } } campioni = []; }
    }
    aggiornaPulsante();
  }
  function spegni(m) { try { m.smonta && m.smonta(ctx); } catch (e) { console.warn("GFX smonta " + m.nome, e); } m.on = false; }
  function guasto(nome, e, m) { console.warn("GFX: modulo " + nome + " spento per errore", e); if (m) { m.guasto = true; if (m.on) spegni(m); } }
  function avviso(t) { try { if (typeof VOLO !== "undefined" && VOLO._acc && VOLO._acc.messaggio) VOLO._acc.messaggio(t, 2); } catch (e) {} }

  /* ---------- registro dei moduli ---------- */
  function registra(m) { m.min = m.min || 1; m.on = false; moduli.push(m); moduli.sort((a, b) => (a.ordine || 0) - (b.ordine || 0)); return m; }

  /* ---------- ora del giorno (la usa l'atmosfera) ---------- */
  // stessa formula di volo.js (cieloBase), ma con l'ora scelta al posto delle 14:30 fisse
  function sole(ora, lat, giorno) {
    const D = Math.PI / 180, decl = 23.44 * Math.sin(2 * Math.PI * (284 + giorno) / 365) * D, H = (ora - 12.5) * 15 * D, f = lat * D;
    const el = Math.asin(Math.sin(f) * Math.sin(decl) + Math.cos(f) * Math.cos(decl) * Math.cos(H));
    const az = Math.atan2(-Math.sin(H), Math.tan(decl) * Math.cos(f) - Math.sin(f) * Math.cos(H));
    return { el, az, dir: new T.Vector3(Math.sin(az) * Math.cos(el), Math.sin(el), -Math.cos(az) * Math.cos(el)).normalize() };
  }

  /* ---------- pulsante e pannello GFX nella barra del Free Flight ---------- */
  let btn = null, pan = null;
  function aggiornaPulsante() {
    const top = document.getElementById("vl-top"); if (!top) return;
    if (!btn || !btn.isConnected) {
      btn = document.createElement("button"); btn.className = "vl-b sm"; btn.id = "vl-gfx"; btn.title = "Qualità grafica, ora del giorno, nuvole";
      btn.onclick = e => { e.stopPropagation(); apriPannello(); };
      const aiuto = top.querySelector("#vl-aiuto"); top.insertBefore(btn, aiuto || null);
    }
    const t = "GFX " + ["0", "B", "M", "A"][ctx.livello]; if (btn.textContent !== t) btn.textContent = t;
  }
  function apriPannello() {
    if (pan && pan.isConnected) { pan.remove(); pan = null; return; }
    const ov = document.getElementById("volo") || btn.parentElement.parentElement;
    pan = document.createElement("div"); pan.id = "vl-gfx-pan";
    pan.style.cssText = "position:absolute;top:calc(env(safe-area-inset-top,0px) + 52px);left:50%;transform:translateX(-50%);z-index:30;background:#0b1622ee;color:#e8f1f8;border:1px solid #4d7594;border-radius:12px;padding:12px 14px;font:600 13px system-ui;min-width:260px;max-width:92vw;pointer-events:auto;box-shadow:0 6px 24px #000a";
    const sel = (lab, id, opz, val) => `<label style="display:block;margin:6px 0">${lab}<select id="${id}" style="display:block;width:100%;margin-top:4px;padding:8px;border-radius:8px;background:#16283a;color:#fff;border:1px solid #4d7594;font:600 14px system-ui">${opz.map(([v, t]) => `<option value="${v}"${String(v) === String(val) ? " selected" : ""}>${t}</option>`).join("")}</select></label>`;
    const auto = ctx.renderer ? livelloAuto(ctx.renderer) : 2;
    const oraV = imp.ora == null ? 14.5 : imp.ora;
    pan.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;font-weight:800;margin-bottom:4px">GRAFICA<button id="gfx-chiudi" title="Chiudi" style="min-width:40px;min-height:36px;border-radius:8px;background:#16283a;color:#fff;border:1px solid #4d7594;font:700 15px system-ui">✕</button></div>`
      + sel("Qualità", "gfx-liv", [["auto", "Automatica (" + NOMI[auto] + ")"], [3, "Alta"], [2, "Media"], [1, "Bassa (telefoni)"], [0, "Spenta (grafica originale)"]], imp.livello)
      + `<label style="display:block;margin:6px 0">Ora del giorno <b id="gfx-ora-v">${fmtOra(oraV)}</b><input id="gfx-ora" type="range" min="5" max="21" step="0.25" value="${oraV}" style="display:block;width:100%;margin-top:6px"></label>`
      + sel("Nuvole", "gfx-nuv", [["auto", "Dal meteo dello scenario"], ["sereno", "Sereno"], ["sparse", "Nubi sparse"], ["coperto", "Coperto"]], imp.nuvole)
      + `<div style="opacity:.7;font-weight:500;margin-top:6px">Su telefoni lenti scegli Bassa. «Spenta» torna alla grafica originale.</div>`;
    ov.appendChild(pan);
    pan.querySelector("#gfx-chiudi").onclick = e => { e.stopPropagation(); pan.remove(); pan = null; };
    pan.querySelector("#gfx-liv").onchange = e => { const v = e.target.value; imp.livello = v === "auto" ? "auto" : +v; autoCalo = 0; salva({ livello: imp.livello }); };
    pan.querySelector("#gfx-ora").oninput = e => { imp.ora = +e.target.value; pan.querySelector("#gfx-ora-v").textContent = fmtOra(imp.ora); salva({ ora: imp.ora }); };
    pan.querySelector("#gfx-nuv").onchange = e => { imp.nuvole = e.target.value; salva({ nuvole: imp.nuvole }); };
    pan.addEventListener("pointerdown", e => e.stopPropagation()); pan.addEventListener("touchstart", e => e.stopPropagation(), { passive: true });
  }
  const fmtOra = h => String(Math.floor(h)).padStart(2, "0") + ":" + String(Math.round((h % 1) * 60)).padStart(2, "0");

  return {
    registra, ctx, imp, sole, NOMI,
    get livello() { return ctx.livello; },
    imposta(o) { Object.assign(imp, o || {}); if (o && "livello" in o) autoCalo = 0; salva(o || {}); },
    livelloAuto: () => ctx.renderer ? livelloAuto(ctx.renderer) : null,
    moduli: () => moduli.map(m => ({ nome: m.nome, min: m.min, on: m.on, guasto: !!m.guasto }))
  };
})();
