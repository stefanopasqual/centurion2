/* =====================================================================
   CENTURION · «DUDE 44» — Combat Search and Rescue sui monti Zagros
   Missione dell'Accademia (Modulo 5 · Personnel Recovery), ispirata all'operazione statunitense dell'aprile 2026
   in Iran (fonte: Wikipedia, «2026 United States F-15E rescue operation in Iran»).

   Fatti ripresi dalla fonte: il 3 aprile 2026 un F-15E Strike Eagle (nominativo DUDE 44) viene abbattuto da un
   missile spalleggiabile; i due membri dell'equipaggio si eiettano. Il pilota viene recuperato dopo circa sette ore.
   Il WSO, ferito, sale una cresta di circa 7.000 piedi nei Monti Zagros, si nasconde in una fenditura della roccia
   e usa il radiofaro solo a brevi impulsi per non farsi trovare; lo cercano anche forze ostili e nomadi armati.
   Attacchi aerei tengono lontani i convogli; due elicotteri vengono colpiti da armi leggere. Il WSO viene recuperato
   vivo il 5 aprile, di notte. Alla base avanzata (una pista agricola abbandonata a nord di Shahreza) due MC-130J
   bloccati vengono distrutti per non lasciarli al nemico e altri aerei portano via il WSO e il personale.

   Nel simulatore: luoghi scelti sul rilievo reale (quote terrarium) attorno al punto indicato dalla fonte; nominativi
   dei soccorritori (JOLLY, SANDY) tradizionali e illustrativi; procedure e tempi semplificati a scopo didattico.
   Nessuna vittima è rappresentata: gli attacchi aerei sbarrano la strada al convoglio.

   Richiede: three.js, volo.js con gli agganci dei filmati (VOLO._int, VOLO._acc, S.cineCam, S.cineHud), accademia.js.
   ===================================================================== */
const ZAGROS = (() => {
  "use strict";
  const D2R = Math.PI / 180, PI = Math.PI;
  const V3 = (x, y, z) => new THREE.Vector3(x || 0, y || 0, z || 0);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const ss = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const mix = (a, b, k) => a + (b - a) * k;
  let seme = 4407; const rnd = (a, b) => { seme = (seme * 16807) % 2147483647; return a + (seme / 2147483647) * (b - a); };
  const ID = "S2", CENTRO = [30.80, 51.60], M_LON = 111320 * Math.cos(CENTRO[0] * D2R);
  const xz = (lat, lon) => ({ x: (lon - CENTRO[1]) * M_LON, z: -(lat - CENTRO[0]) * 111320 });
  const geo = p => ({ lat: CENTRO[0] - p.z / 111320, lon: CENTRO[1] + p.x / M_LON });
  const I = () => (typeof VOLO !== "undefined" && VOLO._int) || {};
  const suoloBase = (x, z) => { try { return VOLO._acc.suolo(x, z) || 0; } catch (e) { return 0; } };
  /* Allineamento del terreno ad alta risoluzione. I riquadri satellitari del Free Flight hanno una quota propria che
     differisce di qualche metro da quella usata dalla fisica: dove il terreno base sporge copre le immagini (macchie
     marroni) e persone ed elicottero sembrano affondare. Durante la missione: terreno base abbassato sotto le immagini,
     immagini traslate perché coincidano con la fisica nel punto dell'azione, oggetti appoggiati sulla superficie visibile. */
  const AL = { c: null, dy: 0, g: null, base: null, ver: "", cache: new Map(), conta: 0, rc: null };
  function hdGruppo() {
    if (AL.g && AL.g.parent) return AL.g; AL.g = null; const sc = VOLO._int && VOLO._int.scene; if (!sc) return null;
    sc.traverse(o => { if (!AL.g && o.name === "CENTURION_HD_REAL_ELEVATION") AL.g = o; }); return AL.g;
  }
  function gruppoBase() {
    if (AL.base && AL.base.parent) return AL.base; AL.base = null; const sc = VOLO._int && VOLO._int.scene; if (!sc) return null;
    AL.base = sc.children.find(c => c.isGroup && c.children.some(m => m.isMesh && m.userData && m.userData.tx !== undefined)) || null; return AL.base;
  }
  function gruppoVita() { const sc = VOLO._int && VOLO._int.scene; let v = null; if (sc) sc.traverse(o => { if (!v && o.name === "SIMULATED_CIVILIAN_GROUND_LIFE") v = o; }); return v; }
  // quota della superficie visibile letta direttamente dalla griglia del riquadro più fine che contiene il punto
  function quotaHD(x, z, soloFine) {
    const g = hdGruppo(); if (!g || !g.children.length) return null;
    if (!AL.ord || AL.ordG !== g) { AL.ord = g.children.slice().sort((a, b) => b.renderOrder - a.renderOrder); AL.ordG = g; }
    for (const m of AL.ord) {
      if (!m.visible || !m.material || !m.material.map || !m.geometry || !m.geometry.parameters) continue;
      if (soloFine && m.renderOrder < 17) break;
      const pr = m.geometry.parameters, s = pr.widthSegments, w = pr.width, lx = x - m.position.x + w / 2, lz = z - m.position.z + w / 2;
      if (lx < 0 || lz < 0 || lx > w || lz > w) continue;
      const st = w / s, fx0 = lx / st, fz0 = lz / st, ix = Math.min(s - 1, Math.floor(fx0)), iz = Math.min(s - 1, Math.floor(fz0)), fx = fx0 - ix, fz = fz0 - iz;
      const P = m.geometry.attributes.position, Y = i => P.getY(i), a = ix + (s + 1) * iz, b = a + s + 1, d = a + 1, c = b + 1;
      const h = fx + fz <= 1 ? Y(a) + (Y(d) - Y(a)) * fx + (Y(b) - Y(a)) * fz : Y(c) + (Y(b) - Y(c)) * (1 - fx) + (Y(d) - Y(c)) * (1 - fz);
      return h + m.position.y + g.position.y;
    }
    return null;
  }
  function allinea(c) {
    if (c) AL.c = c; const g = hdGruppo(), b = gruppoBase(); AL.ord = null;
    // solo se le immagini nitide coprono l'azione (senza rete o su dispositivi senza HD il terreno base resta dov'è)
    const pronto = !!(g && AL.c && g.children.some(m => m.visible && m.renderOrder >= 15 && m.material && m.material.map && Math.abs(m.position.x - AL.c.x) < 3000 && Math.abs(m.position.z - AL.c.z) < 3000)), yb = pronto ? -80 : 0;
    if (b) b.children.forEach(m => { if (m.isMesh && m.userData && m.userData.tx !== undefined && m.position.y !== yb) { m.position.y = yb; m.updateMatrixWorld(true); } });
    if (!AL.vita && (AL.cv = (AL.cv || 0) + 1) % 30 === 1) { const vita = gruppoVita(); if (vita) { vita.visible = false; AL.vita = vita; } } else if (AL.vita && AL.vita.visible) AL.vita.visible = false;
    // livelli più fini leggermente sopra i più grossolani: il rilievo a bassa risoluzione non buca le immagini nitide
    if (g) g.children.forEach(m => { const lift = m.renderOrder >= 17 ? 2.5 : m.renderOrder >= 15 ? 1.2 : 0; if (m.position.y !== lift) { m.position.y = lift; m.updateMatrixWorld(true); AL.ver = ""; } });
    // il livello più grossolano (z12) ha un rilievo approssimato che buca le immagini nitide: attorno all'azione scende sotto
    if (g && AL.c) g.children.forEach(m => { if (m.renderOrder >= 15 || !m.geometry) return; const u = m.userData; if (u.zgC === AL.c) return;
      const pos = m.geometry.attributes.position; if (!u.zgY) { u.zgY = new Float32Array(pos.count); for (let i = 0; i < pos.count; i++) u.zgY[i] = pos.getY(i); }
      for (let i = 0; i < pos.count; i++) { const d = Math.hypot(m.position.x + pos.getX(i) - AL.c.x, m.position.z + pos.getZ(i) - AL.c.z), k = 1 - Math.min(1, Math.max(0, (d - 2200) / 1400)); pos.setY(i, u.zgY[i] - 30 * k * k * (3 - 2 * k)); }
      pos.needsUpdate = true; m.geometry.computeBoundingSphere(); m.geometry.computeBoundingBox && m.geometry.computeBoundingBox(); u.zgC = AL.c; AL.ver = ""; });
    if (!g || !AL.c) return;
    const ver = g.children.length + ":" + g.children.reduce((s, m) => s + (m.visible ? m.id : 0), 0) + ":" + g.position.y.toFixed(2);
    if (ver === AL.ver && AL.conta++ % 60) return; AL.ver = ver; AL.cache.clear();
    const fine = quotaHD(AL.c.x, AL.c.z, true), q = fine !== null ? fine : quotaHD(AL.c.x, AL.c.z, false);
    if (q === null) return;
    const dy = AL.dy - (q - suoloBase(AL.c.x, AL.c.z));
    if (Math.abs(dy - AL.dy) > 0.05) { AL.dy = dy; g.position.y = dy; g.updateMatrixWorld(true); AL.cache.clear(); }
  }
  function disallinea() {
    const g = hdGruppo(), b = gruppoBase(); if (g) { g.position.y = 0; g.updateMatrixWorld(true); }
    if (b) b.children.forEach(m => { if (m.isMesh && m.userData && m.userData.tx !== undefined) { m.position.y = 0; m.updateMatrixWorld(true); } });
    if (g) g.children.forEach(m => { m.position.y = 0; m.updateMatrixWorld(true); const u = m.userData; if (u.zgY && m.geometry) { const pos = m.geometry.attributes.position; for (let i = 0; i < pos.count; i++) pos.setY(i, u.zgY[i]); pos.needsUpdate = true; m.geometry.computeBoundingSphere(); } u.zgY = null; u.zgC = null; }); if (AL.vita) { AL.vita.visible = true; AL.vita = null; }
    AL.c = null; AL.dy = 0; AL.ver = ""; AL.cache.clear();
  }
  const suolo = (x, z) => {
    if (!AL.c) return suoloBase(x, z);
    const k = Math.round(x / 2) + "," + Math.round(z / 2); let v = AL.cache.get(k);
    if (v === undefined) { const q = quotaHD(x, z, false); v = q !== null ? q : suoloBase(x, z); if (AL.cache.size > 40000) AL.cache.clear(); AL.cache.set(k, v); }
    return v;
  };
  const FT = 3.28084, KT = 1.94384;

  // luoghi (rilievo reale: cresta del WSO a 2.195 m, LZ quasi piana a 164 m, strada di valle da Yasuj)
  const LUOGHI = {
    relitto: xz(30.7000, 51.6000),      // punto indicato dalla fonte (approssimato)
    wso: xz(30.7371, 51.5753),          // fenditura sulla cresta, ~7.200 ft
    lz: xz(30.73623, 51.57669),         // spiazzo sulla cresta
    partenza: xz(30.7737, 51.44348),    // JOLLY 11 entra da ovest: l'unica valle che sale alla cresta senza superare i 2.200 m
    ip: xz(30.72177, 51.54785),         // punto iniziale sulla valle, 3,3 km a sud-ovest del WSO
    uscita: xz(30.74656, 51.48605),     // uscita lungo la stessa valle, 12 km a ovest
    osservazione: xz(30.7529, 51.5347), // posto di osservazione con MANPADS a nord della valle
    yasuj: xz(30.6680, 51.5880)
  };
  const STRADA = [[30.6680, 51.5880], [30.6722, 51.5839], [30.6763, 51.5801], [30.6804, 51.5757], [30.6846, 51.5746], [30.6887, 51.5743], [30.6928, 51.5719], [30.6970, 51.5709], [30.7011, 51.5705], [30.7038, 51.5729], [30.7076, 51.5760], [30.7117, 51.5753], [30.7159, 51.5750], [30.7200, 51.5743], [30.7235, 51.5722], [30.7238, 51.5695]].map(([a, b]) => xz(a, b));
  const CAMPI = [xz(30.7407, 51.5499), xz(30.7229, 51.5633), xz(30.7229, 51.5829)];
  // rotta di valle pianificata (minima quota massima sul rilievo reale): partenza -> LZ
  const ROTTA = [[30.7737, 51.44348], [30.77511, 51.44623], [30.77629, 51.45035], [30.77488, 51.45309], [30.77252, 51.45584], [30.77016, 51.45859], [30.7678, 51.46133], [30.76544, 51.46408], [30.76308, 51.46683], [30.76072, 51.46957], [30.75836, 51.47232], [30.756, 51.47507], [30.75364, 51.47781], [30.75128, 51.48056], [30.74892, 51.48331], [30.74656, 51.48605], [30.7442, 51.4888], [30.74184, 51.49155], [30.73995, 51.49429], [30.73806, 51.49704], [30.73641, 51.49979], [30.73452, 51.50253], [30.73239, 51.50528], [30.73003, 51.50803], [30.72767, 51.51077], [30.72531, 51.51352], [30.72295, 51.51627], [30.72059, 51.51901], [30.71917, 51.52176], [30.71846, 51.52588], [30.71705, 51.52863], [30.71468, 51.53137], [30.7128, 51.53412], [30.7135, 51.53824], [30.71587, 51.54099], [30.71823, 51.54373], [30.72059, 51.54648], [30.72295, 51.54922], [30.72531, 51.55115], [30.72885, 51.5528], [30.73098, 51.55472], [30.73239, 51.55746], [30.73381, 51.56021], [30.73523, 51.56433], [30.73428, 51.56845], [30.73499, 51.57257], [30.73593, 51.57394]].map(([a, b]) => xz(a, b));
  const R_MANPADS = 3000, AGL_MANPADS = 91, R_ARMI = 900, AGL_ARMI = 250;

  /* ======================= particelle istanziate (una chiamata di disegno) ======================= */
  const VS_P = `#include <common>
#include <logdepthbuf_pars_vertex>
attribute vec3 aPos; attribute float aSize; attribute float aAlpha; attribute vec3 aColor; attribute float aRot;
varying vec2 vUv; varying float vAlpha; varying vec3 vColor;
void main() { vec4 mv = modelViewMatrix * vec4(aPos, 1.0); float c = cos(aRot), s = sin(aRot); vec2 q = position.xy * aSize;
  mv.xy += vec2(c * q.x - s * q.y, s * q.x + c * q.y); vUv = uv; vAlpha = aAlpha; vColor = aColor; gl_Position = projectionMatrix * mv;
  #include <logdepthbuf_vertex>
}`;
  const FS_P = `#include <common>
#include <logdepthbuf_pars_fragment>
uniform sampler2D map; varying vec2 vUv; varying float vAlpha; varying vec3 vColor;
void main() {
  #include <logdepthbuf_fragment>
  vec4 t = texture2D(map, vUv); float a = t.a * vAlpha; if (a < 0.004) discard; gl_FragColor = vec4(vColor, 1.0);
  #include <tonemapping_fragment>
  #include <encodings_fragment>
  gl_FragColor.a = a; }`;
  let TEX = null;
  function texture() {
    if (TEX) return TEX;
    const mk = (n, f) => { const c = document.createElement("canvas"); c.width = c.height = n; f(c.getContext("2d"), n); return new THREE.CanvasTexture(c); };
    TEX = {
      fumo: mk(128, (g) => { for (let i = 0; i < 26; i++) { const a = Math.random() * PI * 2, r = Math.random() * 30, x = 64 + Math.cos(a) * r, y = 64 + Math.sin(a) * r, rr = 18 + Math.random() * 26; const gr = g.createRadialGradient(x, y, 0, x, y, rr); gr.addColorStop(0, "rgba(255,255,255,0.22)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); } }),
      luce: mk(64, (g) => { const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(0.25, "rgba(255,255,255,0.65)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); })
    };
    return TEX;
  }
  function particelle(scene, n, additivo, mappa) {
    const quad = new THREE.PlaneGeometry(1, 1), geo = new THREE.InstancedBufferGeometry();
    geo.index = quad.index; geo.setAttribute("position", quad.attributes.position); geo.setAttribute("uv", quad.attributes.uv);
    const A = k => { const a = new THREE.InstancedBufferAttribute(new Float32Array(n * k), k); a.setUsage(THREE.DynamicDrawUsage); return a; };
    const aPos = A(3), aSize = A(1), aAlpha = A(1), aColor = A(3), aRot = A(1);
    geo.setAttribute("aPos", aPos); geo.setAttribute("aSize", aSize); geo.setAttribute("aAlpha", aAlpha); geo.setAttribute("aColor", aColor); geo.setAttribute("aRot", aRot); geo.instanceCount = 0;
    const mat = new THREE.ShaderMaterial({ vertexShader: VS_P, fragmentShader: FS_P, transparent: true, depthWrite: false, blending: additivo ? THREE.AdditiveBlending : THREE.NormalBlending, uniforms: { map: { value: mappa } } });
    const mesh = new THREE.Mesh(geo, mat); mesh.frustumCulled = false; mesh.renderOrder = additivo ? 7 : 6; mesh.raycast = () => {}; scene.add(mesh);
    const P = []; for (let i = 0; i < n; i++) P.push({ vivo: false }); let pr = 0;
    function emetti(o) {
      let p = null; for (let k = 0; k < n; k++) { const q = P[(pr + k) % n]; if (!q.vivo) { p = q; pr = (pr + k + 1) % n; break; } }
      if (!p) { p = P[pr]; pr = (pr + 1) % n; }
      const v = o.vel || { x: 0, y: 0, z: 0 }, c0 = new THREE.Color(o.col == null ? 0xffffff : o.col), c1 = new THREE.Color(o.col1 == null ? (o.col == null ? 0xffffff : o.col) : o.col1);
      Object.assign(p, { vivo: true, t: 0, vita: o.vita || 2, x: o.pos.x, y: o.pos.y, z: o.pos.z, vx: v.x, vy: v.y, vz: v.z, s0: o.s0 || 1, s1: o.s1 == null ? (o.s0 || 1) : o.s1, a0: o.a0 == null ? 0.8 : o.a0, inA: o.inA || 0.08,
        r0: c0.r, g0: c0.g, b0: c0.b, r1: c1.r, g1: c1.g, b1: c1.b, rot: Math.random() * PI * 2, rv: o.rv == null ? (Math.random() - 0.5) * 1.2 : o.rv, drag: o.drag == null ? 0.6 : o.drag, su: o.su || 0, g: o.g || 0 });
      return p;
    }
    function aggiorna(dt) {
      let k = 0;
      for (const p of P) {
        if (!p.vivo) continue; p.t += dt; if (p.t >= p.vita) { p.vivo = false; continue; }
        const dr = Math.exp(-p.drag * dt); p.vx *= dr; p.vz *= dr; p.vy = p.vy * dr + (p.su - p.g) * dt;
        p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.rot += p.rv * dt;
        const u = p.t / p.vita, a = p.a0 * ss(0, p.inA, u) * (1 - ss(0.45, 1, u));
        aPos.array[k * 3] = p.x; aPos.array[k * 3 + 1] = p.y; aPos.array[k * 3 + 2] = p.z;
        aSize.array[k] = mix(p.s0, p.s1, 1 - Math.pow(1 - u, 2)); aAlpha.array[k] = a; aRot.array[k] = p.rot;
        aColor.array[k * 3] = mix(p.r0, p.r1, u); aColor.array[k * 3 + 1] = mix(p.g0, p.g1, u); aColor.array[k * 3 + 2] = mix(p.b0, p.b1, u); k++;
      }
      geo.instanceCount = k; aPos.needsUpdate = aSize.needsUpdate = aAlpha.needsUpdate = aColor.needsUpdate = aRot.needsUpdate = true;
    }
    function dispose() { scene.remove(mesh); geo.dispose(); mat.dispose(); }
    return { emetti, aggiorna, dispose };
  }

  /* ======================= modelli procedurali ======================= */
  const mStd = (c, r, m, extra) => new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: r == null ? 0.85 : r, metalness: m || 0 }, extra || {}));
  function mesh(geo, mat, x, y, z) { const o = new THREE.Mesh(geo, mat); o.position.set(x || 0, y || 0, z || 0); o.raycast = () => {}; return o; }
  const luceSprite = (col, s, op) => { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture().luce, color: col, transparent: true, opacity: op == null ? 1 : op, blending: THREE.AdditiveBlending, depthWrite: false })); sp.scale.set(s, s, 1); sp.raycast = () => {}; return sp; };
  let CAMO = null;
  function camo() {
    if (CAMO) return CAMO;
    const c = document.createElement("canvas"); c.width = c.height = 128; const g = c.getContext("2d"); g.fillStyle = "#8c7f62"; g.fillRect(0, 0, 128, 128);
    ["#6f6750", "#a6977a", "#5a5440", "#7b7158"].forEach(col => { g.fillStyle = col; for (let i = 0; i < 18; i++) { g.beginPath(); g.ellipse(Math.random() * 128, Math.random() * 128, 5 + Math.random() * 12, 3 + Math.random() * 7, Math.random() * PI, 0, PI * 2); g.fill(); } });
    CAMO = new THREE.CanvasTexture(c); CAMO.wrapS = CAMO.wrapT = THREE.RepeatWrapping; CAMO.repeat.set(2, 2); return CAMO;
  }
  // figura umana articolata (1,78 m): bacino come radice, giunti come gruppi per le pose
  // equipaggio di DUDE 44: il modello 3D del pilota (js/pilota3d.js) al posto della figura semplificata, quando è caricato
  function vestiPilota(g) { const P3 = window.PILOTA3D; if (!P3 || !g) return g; const fai = () => { if (P3.veste(g)) P3.posa(g, g.userData.posaNome); }; if (P3.pronto) fai(); else P3.carica().then(fai); return g; }
  function persona(o) {
    o = o || {};
    const tuta = o.camo ? new THREE.MeshStandardMaterial({ map: camo(), roughness: 0.92 }) : mStd(o.tuta || 0x5b6148), scuro = mStd(o.attrezzi || 0x2e2f2a), pelle = mStd(o.pelle || 0xa47c5e, 0.7), casco = mStd(o.casco || 0x5f5a48, 0.6);
    const R = new THREE.Group(); R.name = o.nome || "persona";
    const bac = new THREE.Group(); bac.position.y = 0.98; R.add(bac); const busto = new THREE.Group(); bac.add(busto);
    busto.add(mesh(new THREE.CapsuleGeometry(0.17, 0.38, 4, 10), tuta, 0, 0.3, 0));
    if (o.giubbotto !== false) { const v = mesh(new THREE.CapsuleGeometry(0.19, 0.22, 4, 12), o.giubbotto ? mStd(o.giubbotto) : scuro, 0, 0.34, 0.01); v.scale.set(1.06, 1, 0.84); busto.add(v); }
    if (o.zaino) { const z = mesh(new THREE.CapsuleGeometry(0.13, 0.2, 4, 10), mStd(o.zaino), 0, 0.36, -0.21); z.scale.set(1.15, 1, 0.72); busto.add(z); }
    const collo = new THREE.Group(); collo.position.y = 0.62; busto.add(collo);
    collo.add(mesh(new THREE.SphereGeometry(0.11, 12, 10), pelle, 0, 0.1, 0.01));
    if (o.turbante) { const t = mesh(new THREE.SphereGeometry(0.13, 12, 8, 0, PI * 2, 0, PI * 0.55), mStd(o.turbante), 0, 0.12, 0); t.scale.set(1, 0.8, 1); collo.add(t); }
    else if (o.casco !== false) { collo.add(mesh(new THREE.SphereGeometry(0.135, 14, 10, 0, PI * 2, 0, PI * 0.6), casco, 0, 0.13, 0)); }
    let nvg = null; if (o.nvg) { nvg = new THREE.Group(); nvg.add(mesh(new THREE.BoxGeometry(0.09, 0.05, 0.08), scuro, -0.03, 0, 0)); nvg.add(mesh(new THREE.BoxGeometry(0.09, 0.05, 0.08), scuro, 0.03, 0, 0)); nvg.position.set(0, 0.17, 0.13); collo.add(nvg); }
    const arto = (r, l, mat) => { const g = new THREE.Group(); g.add(mesh(new THREE.CapsuleGeometry(r, l, 3, 8), mat, 0, -l / 2 - r, 0)); return g; };
    const spalle = [], gomiti = [], anche = [], ginocchia = [];
    [-1, 1].forEach(s => {
      const sp = arto(0.055, 0.24, tuta); sp.position.set(s * 0.23, 0.5, 0); busto.add(sp); spalle.push(sp);
      const go = arto(0.048, 0.22, tuta); go.position.y = -0.34; sp.add(go); gomiti.push(go); go.add(mesh(new THREE.SphereGeometry(0.045, 8, 6), o.guanti ? scuro : pelle, 0, -0.33, 0));
      const an = arto(0.075, 0.36, tuta); an.position.set(s * 0.1, -0.02, 0); bac.add(an); anche.push(an);
      const gi = arto(0.06, 0.36, tuta); gi.position.y = -0.5; an.add(gi); ginocchia.push(gi); gi.add(mesh(new THREE.BoxGeometry(0.11, 0.09, 0.24), scuro, 0, -0.5, 0.05));
    });
    let fucile = null; if (o.fucile) { fucile = new THREE.Group(); fucile.add(mesh(new THREE.BoxGeometry(0.05, 0.08, 0.72), scuro, 0, 0, 0.12)); fucile.add(mesh(new THREE.BoxGeometry(0.04, 0.14, 0.05), scuro, 0, -0.08, 0.02)); fucile.position.set(0.1, 0.36, 0.26); busto.add(fucile); }
    if (o.borsa) busto.add(mesh(new THREE.BoxGeometry(0.26, 0.2, 0.14), mStd(0x6a2020), -0.24, 0.05, -0.05));
    // strobo a infrarossi sulla spalla: si vede solo con il visore notturno
    const strobo = luceSprite(0xffffff, 1.4, 1); strobo.position.set(0.16, 0.56, -0.08); strobo.visible = false; busto.add(strobo);
    R.userData.j = { bac, busto, collo, spalle, gomiti, anche, ginocchia, fucile, strobo, nvg };
    return R;
  }
  function posa(P, nome, k) {
    P.userData.posaNome = nome; if (P.userData.p3d && window.PILOTA3D) PILOTA3D.posa(P, nome);
    const j = P.userData.j; if (!j) return;
    const set = (o, x, y, z) => o.rotation.set(x || 0, y || 0, z || 0);
    set(j.busto); set(j.collo); j.bac.position.y = 0.98; j.spalle.forEach(o => set(o)); j.gomiti.forEach(o => set(o)); j.anche.forEach(o => set(o)); j.ginocchia.forEach(o => set(o)); if (j.fucile) set(j.fucile);
    const sw = Math.sin((k || 0) * PI * 2);
    if (nome === "cammina" || nome === "corsa") {
      const a = nome === "corsa" ? 0.75 : 0.42; j.anche[0].rotation.x = sw * a; j.anche[1].rotation.x = -sw * a;
      j.ginocchia[0].rotation.x = Math.max(0, -sw) * a * 1.3 + 0.1; j.ginocchia[1].rotation.x = Math.max(0, sw) * a * 1.3 + 0.1;
      j.spalle[0].rotation.x = -sw * a * 0.6; j.spalle[1].rotation.x = sw * a * 0.6; j.gomiti.forEach(o => o.rotation.x = -0.6);
      j.busto.rotation.x = nome === "corsa" ? 0.25 : 0.06; j.bac.position.y = 0.98 - Math.abs(sw) * 0.04;
      if (j.fucile) { j.spalle[1].rotation.x = -0.9; j.gomiti[1].rotation.x = -0.9; }
    } else if (nome === "ginocchio") { j.bac.position.y = 0.55; j.anche[0].rotation.x = -1.4; j.ginocchia[0].rotation.x = 1.45; j.anche[1].rotation.x = 0.35; j.ginocchia[1].rotation.x = 1.9; j.spalle.forEach(o => o.rotation.x = -1.2); j.gomiti.forEach(o => o.rotation.x = -0.4); j.busto.rotation.x = 0.12; }
    else if (nome === "rannicchiato") { j.bac.position.y = 0.38; j.anche.forEach(o => o.rotation.x = -1.9); j.ginocchia.forEach(o => o.rotation.x = 2.1); j.busto.rotation.x = 0.35; j.spalle.forEach(o => o.rotation.x = -0.9); j.gomiti.forEach(o => o.rotation.x = -1.4); j.collo.rotation.x = 0.3; }
    else if (nome === "seduto") { j.bac.position.y = 0.2; j.anche.forEach(o => o.rotation.x = -1.45); j.ginocchia[0].rotation.x = 0.9; j.busto.rotation.x = -0.25; j.spalle.forEach(o => o.rotation.x = -0.3); }
    else if (nome === "saluta") { j.spalle[1].rotation.z = -2.6 + 0.35 * sw; j.gomiti[1].rotation.z = -0.3; }
    else if (nome === "cura") { j.bac.position.y = 0.5; j.anche[0].rotation.x = -1.5; j.ginocchia[0].rotation.x = 1.5; j.anche[1].rotation.x = 0.2; j.ginocchia[1].rotation.x = 1.9; j.busto.rotation.x = 0.55; j.spalle.forEach((o, i) => o.rotation.x = -1.0 + 0.15 * Math.sin((k || 0) * PI * 2 + i)); j.gomiti.forEach(o => o.rotation.x = -0.5); }
    else if (nome === "appeso") { j.spalle.forEach((o, i) => { o.rotation.z = (i ? -1 : 1) * 2.7; }); j.anche.forEach((o, i) => o.rotation.x = -0.15 + i * 0.1); j.ginocchia.forEach(o => o.rotation.x = 0.3); }
    else if (nome === "seggiolino") { j.bac.position.y = 0.45; j.anche.forEach(o => o.rotation.x = -1.5); j.ginocchia.forEach(o => o.rotation.x = 1.4); j.spalle.forEach(o => o.rotation.x = -0.2); }
    else if (nome === "sostenuto") { j.spalle.forEach((o, i) => o.rotation.z = (i ? -1 : 1) * 1.4); j.anche[0].rotation.x = sw * 0.3; j.anche[1].rotation.x = -0.1; j.ginocchia[0].rotation.x = Math.max(0, -sw) * 0.4; }
    else if (nome === "punta") { j.spalle[1].rotation.x = -1.5; j.gomiti[1].rotation.x = -0.2; if (j.fucile) { j.spalle[0].rotation.x = -1.3; j.gomiti[0].rotation.x = -0.5; } }
  }
  function paracadute(col) {
    const G = new THREE.Group(), seg = 28, R = 4.4, geo = new THREE.SphereGeometry(R, seg, 10, 0, PI * 2, 0, 1.2), c = [], pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) { const a = Math.atan2(pos.getZ(i), pos.getX(i)); const s = Math.floor(((a + PI) / (PI * 2)) * seg) % 2; const cc = new THREE.Color(s ? (col || 0xc8b48a) : 0xe6e0d0); c.push(cc.r, cc.g, cc.b); }
    geo.setAttribute("color", new THREE.Float32BufferAttribute(c, 3));
    const cal = mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, side: THREE.DoubleSide })); cal.scale.set(1, 0.62, 1); cal.position.y = 7.2; G.add(cal);
    const lp = [], yb = 7.2 + R * Math.cos(1.2) * 0.62, rb = R * Math.sin(1.2);
    for (let i = 0; i < 16; i++) { const a = i / 16 * PI * 2; lp.push(Math.cos(a) * rb, yb, Math.sin(a) * rb, (i % 2 ? 0.2 : -0.2), 1.55, 0); }
    G.add(new THREE.LineSegments(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(lp, 3)), new THREE.LineBasicMaterial({ color: 0xcfcac0, transparent: true, opacity: 0.7 }))); return G;
  }
  function seggiolino() { const G = new THREE.Group(), gr = mStd(0x2f3336, 0.6, 0.3); G.add(mesh(new THREE.BoxGeometry(0.62, 0.12, 0.6), gr, 0, 0.45, 0)); G.add(mesh(new THREE.BoxGeometry(0.62, 1.1, 0.14), gr, 0, 0.95, -0.3)); G.add(mesh(new THREE.BoxGeometry(0.5, 0.32, 0.16), mStd(0x1a222a), 0, 1.6, -0.28)); return G; }
  function camion(fari) {
    const G = new THREE.Group(), v = mStd(0x4f553c), s = mStd(0x1e1e1e), ve = mStd(0x223038, 0.2, 0.4);
    G.add(mesh(new THREE.BoxGeometry(2.3, 1.6, 2.0), v, 0, 1.5, 2.2)); G.add(mesh(new THREE.BoxGeometry(2.2, 0.7, 0.05), ve, 0, 1.85, 3.21)); G.add(mesh(new THREE.BoxGeometry(2.4, 1.5, 3.6), mStd(0x474c35), 0, 1.65, -0.7));
    [[-1.05, 2.2], [1.05, 2.2], [-1.05, -1.4], [1.05, -1.4], [-1.05, -0.2], [1.05, -0.2]].forEach(([x, z]) => { const r = mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.35, 14), s, x, 0.5, z); r.rotation.z = PI / 2; G.add(r); });
    const luci = []; if (fari) [-0.8, 0.8].forEach(x => { const l = luceSprite(0xfff1c8, 3.2, 0.95); l.position.set(x, 1.05, 3.25); G.add(l); luci.push(l); });
    G.userData.luci = luci; return G;
  }
  function tenda() {
    const G = new THREE.Group(), tela = mStd(0x2a2420, 0.95);
    const t = mesh(new THREE.CylinderGeometry(0.2, 3.4, 2.4, 6, 1, true), new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 0.95, side: THREE.DoubleSide }), 0, 1.2, 0); t.scale.set(1, 1, 0.65); G.add(t);
    G.add(mesh(new THREE.BoxGeometry(6.2, 0.1, 4.2), tela, 0, 0.05, 0)); return G;
  }
  function rocce(n, r) { const G = new THREE.Group(), m = mStd(0x6d655a, 0.95); for (let i = 0; i < n; i++) { const s = rnd(0.6, r); const o = mesh(new THREE.DodecahedronGeometry(s, 0), m, rnd(-r * 2, r * 2), s * 0.4, rnd(-r * 2, r * 2)); o.rotation.set(rnd(0, 3), rnd(0, 3), rnd(0, 3)); o.scale.y = rnd(0.5, 0.9); G.add(o); } return G; }
  let PIETRA = null;
  function pietra() {
    if (PIETRA) return PIETRA; const c = document.createElement("canvas"); c.width = c.height = 256; const g = c.getContext("2d"); g.fillStyle = "#857b6d"; g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 2600; i++) { const v = 90 + Math.random() * 90 | 0; g.fillStyle = `rgba(${v},${v - 6},${v - 14},${0.25 + Math.random() * 0.35})`; const s = 1 + Math.random() * 5; g.fillRect(Math.random() * 256, Math.random() * 256, s, s); }
    g.strokeStyle = "rgba(40,34,28,0.55)"; for (let i = 0; i < 26; i++) { g.lineWidth = 0.6 + Math.random() * 1.4; g.beginPath(); let x = Math.random() * 256, y = Math.random() * 256; g.moveTo(x, y); for (let k = 0; k < 6; k++) { x += (Math.random() - 0.5) * 40; y += Math.random() * 22; g.lineTo(x, y); } g.stroke(); }
    PIETRA = new THREE.CanvasTexture(c); PIETRA.wrapS = PIETRA.wrapT = THREE.RepeatWrapping; PIETRA.repeat.set(2, 2); return PIETRA;
  }
  // masso irregolare: icosaedro deformato con rumore, base appiattita, grana di pietra
  function masso(r, sx, sy, sz, col) {
    const g = new THREE.IcosahedronGeometry(r, 4), pos = g.attributes.position, v = new THREE.Vector3();
    const f1 = rnd(1.2, 2.4), f2 = rnd(2.5, 4.5), ph = rnd(0, 6);
    for (let i = 0; i < pos.count; i++) { v.fromBufferAttribute(pos, i); const n = v.clone().normalize(); const d = 1 + 0.16 * Math.sin(n.x * f1 * 3 + ph) * Math.cos(n.z * f1 * 2.6) + 0.08 * Math.sin(n.y * f2 * 3 + n.x * 5); v.multiplyScalar(d); if (v.y < -r * 0.35) v.y = -r * 0.35; pos.setXYZ(i, v.x * sx, v.y * sy, v.z * sz); }
    g.computeVertexNormals(); return mesh(g, new THREE.MeshStandardMaterial({ color: col || 0x8a8070, map: pietra(), roughness: 1 }), 0, 0, 0);
  }
  function fenditura() {   // due grandi massi che lasciano una spaccatura: il riparo del WSO
    const G = new THREE.Group();
    const a = masso(2.2, 1.3, 1.1, 1.6, 0x5c554b); a.position.set(-3.2, 1.2, -0.6); a.rotation.y = 0.4; G.add(a);
    const b = masso(2.0, 1.2, 1.2, 1.5, 0x625a4f); b.position.set(3.0, 1.1, -0.8); b.rotation.y = -0.3; G.add(b);
    const c = masso(1.6, 1.4, 0.8, 1.2, 0x564f46); c.position.set(0.1, 2.6, -2.2); c.rotation.y = 1.1; G.add(c);
    for (let i = 0; i < 9; i++) { const s = masso(rnd(0.25, 0.7), 1, rnd(0.5, 0.8), 1, 0x6a6257); s.position.set(rnd(-4, 4), 0.1, rnd(-1, 3.5)); G.add(s); }
    return G;
  }
  function rottamiF15() {
    const G = new THREE.Group(), m1 = mStd(0x50565c, 0.5, 0.4), m2 = mStd(0x161718, 0.9), m3 = mStd(0x6b7177, 0.5, 0.4);
    for (let i = 0; i < 18; i++) { const p = mesh(new THREE.BoxGeometry(rnd(0.6, 3.4), rnd(0.08, 0.5), rnd(0.5, 2.6)), i % 3 ? m2 : m1, rnd(-16, 16), 0.2, rnd(-20, 12)); p.rotation.set(rnd(-0.6, 0.6), rnd(0, PI), rnd(-0.4, 0.4)); G.add(p); }
    [-1, 1].forEach(s => { const d = mesh(new THREE.BoxGeometry(0.15, 3.0, 2.8), m3, s * 3 + 2, 1.4, -7); d.rotation.set(0.3, 0.5 * s, 0.4 * s); G.add(d); });
    const crat = new THREE.Mesh(new THREE.CircleGeometry(24, 32), new THREE.MeshBasicMaterial({ color: 0x100d0b, transparent: true, opacity: 0.85, depthWrite: false })); crat.rotation.x = -PI / 2; crat.position.y = 0.15; G.add(crat);
    return G;
  }
  // A-10 Thunderbolt II stilizzato (ala dritta, motori in gondola sul dorso, doppia deriva)
  function a10() {
    const G = new THREE.Group(), g = mStd(0x5d6468, 0.6, 0.3), sc = mStd(0x3d4245, 0.6, 0.3);
    const f = mesh(new THREE.CylinderGeometry(0.75, 0.55, 15.5, 14), g); f.rotation.x = PI / 2; G.add(f);
    const naso = mesh(new THREE.ConeGeometry(0.75, 1.6, 14), g, 0, 0, 8.5); naso.rotation.x = PI / 2; G.add(naso);
    G.add(mesh(new THREE.BoxGeometry(17.5, 0.28, 2.6), g, 0, -0.2, 1.2));
    [-1, 1].forEach(s => { const e = mesh(new THREE.CylinderGeometry(0.62, 0.62, 3.2, 14), sc, s * 1.5, 1.1, -3.8); e.rotation.x = PI / 2; G.add(e); G.add(mesh(new THREE.BoxGeometry(0.2, 2.6, 2.0), g, s * 3.1, 1.0, -7.3)); });
    G.add(mesh(new THREE.BoxGeometry(6.6, 0.18, 1.8), g, 0, 0.4, -7.3)); G.add(mesh(new THREE.SphereGeometry(0.55, 12, 8, 0, PI * 2, 0, PI / 2), mStd(0x1b2a33, 0.2, 0.6), 0, 0.55, 4.6));
    return G;
  }
  // C-130J (MC-130J) e bimotore di sostituzione (tipo C-295): fusoliera, ala alta, motori e eliche, impennaggi
  function cargo(o) {
    const G = new THREE.Group(), L = o.L, R = o.R, col = mStd(o.col, 0.65, 0.2), sc = mStd(0x2a2d2f, 0.6, 0.3);
    const f = mesh(new THREE.CylinderGeometry(R, R, L * 0.72, 18), col); f.rotation.x = PI / 2; G.add(f);
    const muso = mesh(new THREE.SphereGeometry(R, 18, 12, 0, PI * 2, 0, PI / 2), col, 0, 0, L * 0.36); muso.rotation.x = PI / 2; muso.scale.set(1, 1.25, 1); G.add(muso);
    const coda = mesh(new THREE.CylinderGeometry(R, R * 0.35, L * 0.28, 18), col, 0, R * 0.35, -L * 0.5); coda.rotation.x = PI / 2; G.add(coda);
    G.add(mesh(new THREE.BoxGeometry(o.ap, 0.45, o.corda), col, 0, R * 0.95, L * 0.04));
    const eliche = [];
    o.motori.forEach(x => { const n = mesh(new THREE.CylinderGeometry(0.62, 0.55, 3.8, 12), col, x, R * 0.75, L * 0.04 + o.corda * 0.55); n.rotation.x = PI / 2; G.add(n);
      const e = new THREE.Group(); e.position.set(x, R * 0.75, L * 0.04 + o.corda * 0.55 + 2.0); for (let k = 0; k < o.pale; k++) { const p = mesh(new THREE.BoxGeometry(0.22, o.elica, 0.06), sc, 0, o.elica / 2, 0); const q = new THREE.Group(); q.rotation.z = k * PI * 2 / o.pale; q.add(p); e.add(q); } G.add(e); eliche.push(e); });
    G.add(mesh(new THREE.BoxGeometry(0.4, o.deriva, 3.6), col, 0, R + o.deriva / 2, -L * 0.56)); G.add(mesh(new THREE.BoxGeometry(o.ap * 0.36, 0.25, 3.0), col, 0, R * 0.4, -L * 0.6));
    [-1, 1].forEach(s => { const r = mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.5, 12), sc, s * R * 0.75, -R - 0.1, -1); r.rotation.z = PI / 2; G.add(r); });
    G.userData.eliche = eliche; G.userData.terra = R + 0.65; return G;
  }
  const mc130 = () => cargo({ L: 30, R: 2.2, ap: 40.4, corda: 4.1, motori: [-11.5, -5.6, 5.6, 11.5], pale: 6, elica: 2.0, deriva: 6.4, col: 0x4b5054 });
  const bimotore = () => cargo({ L: 24, R: 1.6, ap: 25.8, corda: 2.8, motori: [-4.6, 4.6], pale: 6, elica: 1.9, deriva: 4.8, col: 0x8a9096 });

  /* ======================= tappeto satellitare sul rilievo, dove si svolge l'azione ======================= */
  function tappeto(sc, lat, lon, z, nt, conv) {
    const n = 2 ** z, lr = lat * D2R, tx = Math.floor((lon + 180) / 360 * n), ty = Math.floor((1 - Math.log(Math.tan(lr) + 1 / Math.cos(lr)) / PI) / 2 * n), h = Math.floor(nt / 2);
    const G = new THREE.Group(); G.name = "tappeto"; const SEG = 22, loader = new THREE.TextureLoader(); loader.setCrossOrigin("anonymous"); const pezzi = [];
    for (let X = tx - h; X <= tx + h; X++) for (let Y = ty - h; Y <= ty + h; Y++) {
      const geo = new THREE.PlaneGeometry(1, 1, SEG, SEG), pos = geo.attributes.position, uv = geo.attributes.uv, mondo = [];
      for (let i = 0; i < pos.count; i++) { const u = uv.getX(i), v = 1 - uv.getY(i), lo = (X + u) / n * 360 - 180, la = Math.atan(Math.sinh(PI * (1 - 2 * (Y + v) / n))) / D2R, w = conv(la, lo); mondo.push(w); pos.setXYZ(i, w.x, 0, w.z); }
      const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, metalness: 0, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
      const m = new THREE.Mesh(geo, mat); m.visible = false; m.frustumCulled = false; m.raycast = () => {}; G.add(m); pezzi.push({ m, mondo });
      const url = typeof VISTA3D !== "undefined" && VISTA3D.tileUrl ? VISTA3D.tileUrl("sat", z, X, Y) : `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${Y}/${X}`;
      loader.load(url, tex => { if (THREE.sRGBEncoding !== undefined && tex.encoding !== undefined) tex.encoding = THREE.sRGBEncoding; tex.anisotropy = 8; mat.map = tex; mat.needsUpdate = true; m.visible = true; }, undefined, () => {});
    }
    const quote = () => { pezzi.forEach(({ m, mondo }) => { const pos = m.geometry.attributes.position; mondo.forEach((w, i) => pos.setY(i, suolo(w.x, w.z) + 0.3)); pos.needsUpdate = true; m.geometry.computeVertexNormals(); m.geometry.computeBoundingSphere(); }); };
    quote(); G.userData.quote = quote; sc.add(G); return G;
  }

  /* ======================= mondo della missione ======================= */
  let W = null;
  function piazza(o, p, dy) { o.position.set(p.x, suolo(p.x, p.z) + (dy || 0), p.z); }
  function lungoStrada(s) {   // s in metri dall'inizio della strada (Yasuj) -> posizione e direzione
    let rest = s;
    for (let i = 0; i < STRADA.length - 1; i++) { const a = STRADA[i], b = STRADA[i + 1], l = Math.hypot(b.x - a.x, b.z - a.z); if (rest <= l) { const k = rest / l; return { x: a.x + (b.x - a.x) * k, z: a.z + (b.z - a.z) * k, dir: Math.atan2(b.x - a.x, b.z - a.z) }; } rest -= l; }
    const a = STRADA[STRADA.length - 2], b = STRADA[STRADA.length - 1]; return { x: b.x, z: b.z, dir: Math.atan2(b.x - a.x, b.z - a.z) };
  }
  const LSTRADA = (() => { let l = 0; for (let i = 0; i < STRADA.length - 1; i++) l += Math.hypot(STRADA[i + 1].x - STRADA[i].x, STRADA[i + 1].z - STRADA[i].z); return l; })();
  function prepara(S) {
    chiudi(); seme = 4407;
    const sc = I().scene; if (!sc) return null;
    const T = texture();
    W = { S, sc, oggetti: [], fumo: particelle(sc, 900, false, T.fumo), fuoco: particelle(sc, 700, true, T.luce), traccianti: particelle(sc, 1800, true, T.luce), t: 0,
      esposizione: 0, espMax: 0, colpi: 0, fuocoT: 0, impulsi: [], prossimoImpulso: null, convoglio: { s: 600, fermo: false, colpito: false }, sandy: null, avvisoT: 0, contatto: false, recuperato: false };
    const add = o => { sc.add(o); W.oggetti.push(o); return o; };
    const L = LUOGHI;
    // relitto dell'F-15E che brucia ancora (due giorni dopo restano focolai e fumo)
    W.relitto = add(rottamiF15()); piazza(W.relitto, L.relitto);
    W.sotto = [add(sottobosco(L.lz, 150, 520, 260, 7)), add(sottobosco(L.wso, 70, 260, 90, 11)), add(sottobosco(L.relitto, 90, 200, 120, 23))];
    // WSO nella fenditura, rannicchiato, strobo IR spento finché non sente l'elicottero
    W.fend = add(fenditura()); piazza(W.fend, L.wso); W.fend.rotation.y = Math.atan2(L.lz.x - L.wso.x, L.lz.z - L.wso.z);   // apertura verso la LZ
    W.wso = add(vestiPilota(persona({ nome: "DUDE 44B (WSO)", tuta: 0x5d6447, giubbotto: 0x3b4230, casco: 0x8b8d84 }))); W.fend.updateMatrixWorld(true); const pw = W.fend.localToWorld(V3(0, 0, -0.6)); piazza(W.wso, { x: pw.x, z: pw.z }); W.wso.rotation.y = W.fend.rotation.y; posa(W.wso, "rannicchiato");
    // luci chimiche IR che segnano la LZ (le posa il WSO quando sente l'elicottero): solo con il visore
    W.chem = []; [[-9, -9], [9, -9], [9, 9], [-9, 9]].forEach(([a, b]) => { const l = luceSprite(0x9dff9d, 2.4, 0.9); l.position.set(L.lz.x + a, suolo(L.lz.x + a, L.lz.z + b) + 0.4, L.lz.z + b); l.visible = false; add(l); W.chem.push(l); });
    // posto di osservazione con MANPADS (sulla rotta diretta) e squadra di ricerca al relitto
    W.posto = add(new THREE.Group()); piazza(W.posto, L.osservazione); W.posto.add(camion(false));
    [[3, 1, 0.6, "ginocchio"], [4.2, -1.5, 2.2, "punta"], [-2.5, 2.5, 3.6, "cammina"]].forEach(([x, z, r, p]) => { const q = persona({ tuta: 0x44463a, giubbotto: 0x2c2c26, casco: 0x3a3a30, fucile: true }); q.position.set(x, 0, z); q.rotation.y = r; posa(q, p, 0.2); W.posto.add(q); });
    W.ricerca = add(new THREE.Group()); piazza(W.ricerca, { x: L.relitto.x + 60, z: L.relitto.z - 40 }); [0, 1].forEach(i => { const c = camion(true); c.position.set(i * 8, 0, i * 4); c.rotation.y = 0.6; W.ricerca.add(c); });
    // accampamenti dei nomadi (armati di fucili da caccia): tende, fuoco, uomini
    W.campi = CAMPI.map((p, k) => { const g = add(new THREE.Group()); piazza(g, p); g.rotation.y = k * 1.3;
      [[0, 0], [9, 4], [-7, 6]].forEach(([x, z], i) => { if (k === 2 && i === 2) return; const t = tenda(); t.position.set(x, 0, z); t.rotation.y = i; g.add(t); });
      [[2, -6, "seduto"], [4, -5, "in piedi"], [-1, -7, "punta"]].forEach(([x, z, ps], i) => { const q = persona({ tuta: 0x3e3830, giubbotto: false, turbante: 0x2a2520, casco: false, fucile: i > 0, pelle: 0x8d6a52 }); q.position.set(x, 0, z); q.rotation.y = 1 + i; posa(q, ps, 0.1); g.add(q); });
      const fuoco = luceSprite(0xff9a3c, 6, 0.95); fuoco.position.set(2, 0.8, -4); g.add(fuoco); const pl = new THREE.PointLight(0xff8a3a, 2.4, 40); pl.position.set(2, 1.5, -4); g.add(pl);
      return { g, p, fuoco, pl }; });
    // convoglio dei Pasdaran sulla strada di valle da Yasuj: quattro camion con i fari accesi
    W.mezzi = [0, 1, 2, 3].map(() => add(camion(true)));
    piazzaElicottero(S, L.partenza, Math.atan2(L.ip.x - L.partenza.x, -(L.ip.z - L.partenza.z)) / D2R, 120, 30);
    S.pausa = true;   // fermo finché il rilievo non è caricato e parte il filmato: niente volo alla cieca
    preparaFuoco(S);
    return W;
  }
  function piazzaElicottero(S, p, hdgDeg, agl, v) {
    const P = S.pl, h = hdgDeg * D2R; P.pos.set(p.x, suolo(p.x, p.z) + agl, p.z);
    P.Q.copy(VOLO._acc.assetto(h, 0, 0)); P.vel.set(Math.sin(h) * v, 0, -Math.cos(h) * v); P.rigid6 = null; P.rotorSim = null; P.aTerra = false; S.thr = 0.68;
    if (P.obj) { P.obj.position.copy(P.pos); P.obj.quaternion.copy(P.Q); }
  }
  // sassi e cespugli sparsi: dettaglio vicino al suolo dove l'immagine satellitare da sola è sfocata
  function sottobosco(c, raggio, nSassi, nCesp, seme) {
    let s = seme || 1; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
    const G = new THREE.Group(); G.name = "sottobosco";
    const gs = new THREE.IcosahedronGeometry(1, 1), ps = gs.attributes.position;
    for (let i = 0; i < ps.count; i++) { const x = ps.getX(i), y = ps.getY(i), z = ps.getZ(i), k = 0.72 + 0.5 * Math.abs(Math.sin(x * 5.1 + z * 3.7 + y * 2.3)); ps.setXYZ(i, x * k, Math.max(-0.35, y) * k * 0.65, z * k); }
    gs.computeVertexNormals();
    const gc = new THREE.IcosahedronGeometry(1, 1), pc = gc.attributes.position;
    for (let i = 0; i < pc.count; i++) { const x = pc.getX(i), y = pc.getY(i), z = pc.getZ(i), k = 0.75 + 0.45 * Math.abs(Math.sin(x * 7.3 - z * 4.1 + y * 5.7)); pc.setXYZ(i, x * k, Math.max(-0.2, y) * k, z * k); }
    gc.computeVertexNormals();
    const sassi = new THREE.InstancedMesh(gs, new THREE.MeshStandardMaterial({ color: 0xa89c88, map: pietra(), roughness: 1, flatShading: true }), nSassi);
    const cesp = new THREE.InstancedMesh(gc, new THREE.MeshStandardMaterial({ color: 0x3d4529, roughness: 1, flatShading: true }), nCesp);
    const dati = [];
    for (let i = 0; i < nSassi; i++) { const r = 6 + (raggio - 6) * Math.sqrt(rnd()), a = rnd() * 6.283, k = 0.12 + Math.pow(rnd(), 3) * 1.5; dati.push({ m: sassi, i, x: c.x + Math.cos(a) * r, z: c.z + Math.sin(a) * r, s: [k * (0.8 + rnd() * 0.6), k * (0.5 + rnd() * 0.6), k * (0.8 + rnd() * 0.6)], yaw: rnd() * 6.283, dy: -0.12 * k }); }
    for (let i = 0; i < nCesp; i++) { const r = 6 + (raggio - 6) * Math.sqrt(rnd()), a = rnd() * 6.283, k = 0.35 + rnd() * 0.8; dati.push({ m: cesp, i, x: c.x + Math.cos(a) * r, z: c.z + Math.sin(a) * r, s: [k, k * (0.55 + rnd() * 0.3), k * (0.9 + rnd() * 0.3)], yaw: rnd() * 6.283, dy: 0.05 }); }
    const M = new THREE.Matrix4(), Q = new THREE.Quaternion(), E = new THREE.Euler(), P = new THREE.Vector3(), S = new THREE.Vector3();
    const quote = () => { dati.forEach(d => { P.set(d.x, suolo(d.x, d.z) + d.dy, d.z); Q.setFromEuler(E.set(0, d.yaw, 0)); S.set(d.s[0], d.s[1], d.s[2]); M.compose(P, Q, S); d.m.setMatrixAt(d.i, M); }); sassi.instanceMatrix.needsUpdate = true; cesp.instanceMatrix.needsUpdate = true; };
    sassi.frustumCulled = false; cesp.frustumCulled = false; sassi.raycast = () => {}; cesp.raycast = () => {};
    G.add(sassi, cesp); quote(); G.userData.quote = quote; return G;
  }
  function riallinea() {
    if (!W) return; const L = LUOGHI;
    [[W.relitto, L.relitto], [W.fend, L.wso], [W.posto, L.osservazione], [W.ricerca, { x: L.relitto.x + 60, z: L.relitto.z - 40 }]].forEach(([o, p]) => { o.position.y = suolo(p.x, p.z); });
    if (W.sotto) W.sotto.forEach(g => g.userData.quote());
    W.wso.position.y = suolo(W.wso.position.x, W.wso.position.z); W.campi.forEach(c => { c.g.position.y = suolo(c.p.x, c.p.z); }); if (W.tappeto && (W.tapT = (W.tapT || 0) + 1) % 3 === 1) W.tappeto.userData.quote();
    W.chem.forEach(l => { l.position.y = suolo(l.position.x, l.position.z) + 0.4; });
  }
  function terrenoPronto() { const d = VOLO.debug, m = d && /^(\d+)\/(\d+)$/.exec(String(d.terreno || "")); return !!m && +m[2] > 0 && +m[1] >= +m[2] * 0.95; }
  function info(S) {
    const P = S.pl, L = LUOGHI, d = a => Math.hypot(P.pos.x - a.x, P.pos.z - a.z), brg = a => (Math.atan2(a.x - P.pos.x, -(a.z - P.pos.z)) / D2R + 360) % 360;
    const agl = P.pos.y - suolo(P.pos.x, P.pos.z), v = Math.hypot(P.vel.x, P.vel.z);
    const dCampo = Math.min(...CAMPI.map(d)), conv = W && W.mezzi ? Math.min(...W.mezzi.map(m => d(m.position))) : 1e9;
    return { dWSO: d(L.wso), dLZ: d(L.lz), brgLZ: brg(L.lz), dIP: d(L.ip), brgIP: brg(L.ip), dUscita: d(L.uscita), brgUscita: brg(L.uscita), dPosto: d(L.osservazione), dRelitto: d(L.relitto), dCampo, dConvoglio: conv,
      agl, aglFt: agl * FT, kt: v * KT, quotaFt: P.pos.y * FT, inManpads: d(L.osservazione) < R_MANPADS || d(L.relitto) < R_MANPADS, esposto: (d(L.osservazione) < R_MANPADS || d(L.relitto) < R_MANPADS) && agl > AGL_MANPADS,
      sottoTiro: (dCampo < R_ARMI || (conv < R_ARMI && !(W && W.convoglio.fermo))) && agl < AGL_ARMI,
      esposizione: W ? W.esposizione : 0, colpi: W ? W.colpi : 0, nvg: !!(S.nvg && S.cam === "cockpit"), aTerra: !!P.aTerra, vivo: !!P.vivo };
  }
  // ultima stima della posizione del WSO dagli impulsi del radiofaro
  function stima() { return W && W.impulsi.length ? W.impulsi[W.impulsi.length - 1] : null; }
  function impulso() {   // brevi trasmissioni: la posizione arriva con un errore che si riduce
    const n = W.impulsi.length, R = [1200, 520, 220, 90][Math.min(3, n)], a = [2.1, 4.4, 0.9, 3.3][n % 4], e = R * [0.55, 0.5, 0.45, 0.3][Math.min(3, n)];
    W.impulsi.push({ x: LUOGHI.wso.x + Math.sin(a) * e, z: LUOGHI.wso.z - Math.cos(a) * e, r: R, t: W.t });
    try { VOLO._acc.messaggio(n === 0 ? "RADIOFARO · impulso di DUDE 44B: posizione approssimata sul GPS" : `RADIOFARO · nuovo impulso: incertezza ${R} m`, 3.2); } catch (e) {}
  }
  function aggiorna(dt, S) {
    if (!W || W.S !== S) return;
    W.t += dt; allinea(LUOGHI.lz); if ((W.allT = (W.allT || 0) - dt) <= 0) { W.allT = 2; riallinea(); }
    const k = info(S), P = S.pl;
    // MANPADS: esposizione cumulata come per gli STOS
    if (k.esposto) { W.esposizione += dt; if ((W.avvisoT -= dt) <= 0) { W.avvisoT = 3; try { VOLO._acc.messaggio("MANPADS IN VISTA · scendi sotto 300 ft dal suolo", 2.5, "warn"); } catch (e) {} } }
    else W.esposizione = Math.max(0, W.esposizione - dt * 0.5);
    W.espMax = Math.max(W.espMax, W.esposizione);
    // armi leggere: vicino ai campi o al convoglio, bassi e lenti si viene colpiti (traccianti verso l'elicottero)
    if (k.sottoTiro) { W.fuocoT -= dt;
      if (Math.random() < dt * 6) { const da = k.dCampo < R_ARMI ? CAMPI.reduce((a, b) => Math.hypot(P.pos.x - a.x, P.pos.z - a.z) < Math.hypot(P.pos.x - b.x, P.pos.z - b.z) ? a : b) : W.mezzi[0].position;
        const o = V3(da.x, suolo(da.x, da.z) + 1.5, da.z), dir = P.pos.clone().sub(o).add(V3(rnd(-25, 25), rnd(-10, 20), rnd(-25, 25))).normalize();
        W.traccianti.emetti({ pos: o, vel: dir.multiplyScalar(420), vita: 2.2, s0: 2.2, s1: 1.6, a0: 1, inA: 0.01, col: 0xffb24a, col1: 0xff5a1a, drag: 0, rv: 0 }); }
      if (W.fuocoT <= 0) { W.fuocoT = 4.5; if (Math.random() < 0.5 + (k.kt < 40 ? 0.3 : 0)) { W.colpi++; try { VOLO._acc.messaggio(`COLPITI · armi leggere (${W.colpi})`, 2.2, "warn"); } catch (e) {} } } }
    else W.fuocoT = Math.min(W.fuocoT, 1.5);
    // convoglio: avanza verso la cresta finché SANDY non sbarra la strada
    const C = W.convoglio;
    if (W.fase >= 2 && !C.fermo) { C.s = Math.min(LSTRADA - 300, C.s + dt * 9); if (W.sandy == null) W.sandy = W.t + 22; }
    W.mezzi.forEach((m, i) => { const q = lungoStrada(Math.max(0, C.s - i * 34)); m.position.set(q.x, suolo(q.x, q.z), q.z); m.rotation.y = q.dir; m.userData.luci.forEach(l => l.visible = !C.fermo); });
    if (W.sandy != null && !C.colpito && W.t >= W.sandy) attaccoSandy();
    if (C.colpito) { const q = C.punto; if ((W.focT = (W.focT || 0) - dt) <= 0) { W.focT = 0.09; W.fuoco.emetti({ pos: V3(q.x + rnd(-6, 6), suolo(q.x, q.z) + rnd(0.5, 2), q.z + rnd(-6, 6)), vel: V3(0, rnd(3, 6), 0), vita: rnd(0.5, 1.1), s0: rnd(2.5, 4.5), s1: 1, a0: 0.9, col: 0xffc060, col1: 0xff3a08, drag: 0.4 }); W.fumo.emetti({ pos: V3(q.x, suolo(q.x, q.z) + 3, q.z), vel: V3(rnd(-1, 1), rnd(5, 8), rnd(-1, 1)), vita: rnd(9, 13), s0: 6, s1: 30, a0: 0.4, col: 0x2a2724, col1: 0x55524e, drag: 0.15, su: 0.2 }); } }
    // relitto: focolai e fumo
    if ((W.relT = (W.relT || 0) - dt) <= 0) { W.relT = 0.12; const L = LUOGHI.relitto, y = suolo(L.x, L.z); W.fuoco.emetti({ pos: V3(L.x + rnd(-10, 10), y + rnd(0.3, 1.2), L.z + rnd(-12, 8)), vel: V3(0, rnd(2, 4), 0), vita: rnd(0.4, 0.9), s0: rnd(1.5, 3), s1: 0.8, a0: 0.8, col: 0xffb050, col1: 0xff3a08, drag: 0.4 }); W.fumo.emetti({ pos: V3(L.x, y + 3, L.z), vel: V3(rnd(-1, 1), rnd(4, 6), rnd(-1, 1)), vita: rnd(10, 14), s0: 5, s1: 26, a0: 0.3, col: 0x222120, col1: 0x4a4744, drag: 0.15, su: 0.15 }); }
    // fuochi dei campi che tremolano
    W.campi.forEach((c, i) => { const f = 0.8 + 0.2 * Math.sin(W.t * 11 + i) + 0.1 * Math.sin(W.t * 23 + i * 3); c.fuoco.material.opacity = 0.75 * f; c.pl.intensity = 2.4 * f; });
    // strobo IR del WSO e luci chimiche: accesi quando sente l'elicottero; visibili solo con il visore notturno
    const sente = k.dWSO < 3000 || W.recuperato; const visore = k.nvg;
    W.wso.userData.j.strobo.visible = sente && visore && !W.recuperato && (W.t % 1.0) < 0.12;
    W.chem.forEach(l => { l.visible = sente && visore && !W.recuperato; });
    if (!W.contatto && sente && W.fase >= 3) { W.contatto = true; try { VOLO._acc.messaggio("DUDE 44B: «ti sento, strobo IR acceso, luci chimiche sulla LZ»", 4); } catch (e) {} }
    // impulsi del radiofaro (fase di ricerca): ogni 35 s, poi più spesso quando è vicino
    if (W.fase >= 2 && !W.recuperato) { if (W.prossimoImpulso == null) W.prossimoImpulso = W.t + 4; if (W.t >= W.prossimoImpulso) { impulso(); W.prossimoImpulso = W.t + (W.impulsi.length < 2 ? 35 : 25); } }
    combattimento(dt, S);
    W.fumo.aggiorna(dt); W.fuoco.aggiorna(dt); W.traccianti.aggiorna(dt);
    strumenti(S, k);
  }
  function attaccoSandy() {
    const C = W.convoglio; C.colpito = true; C.fermo = true; const q = lungoStrada(C.s + 220); C.punto = q;
    try { VOLO._acc.messaggio("SANDY 1 (A-10): bombe sulla strada davanti al convoglio, il convoglio si ferma", 4.5); } catch (e) {}
    for (let i = 0; i < 3; i++) setTimeout(() => { if (!W) return; const p = V3(q.x + rnd(-20, 20), suolo(q.x, q.z), q.z + rnd(-20, 20));
      for (let k = 0; k < 40; k++) W.fuoco.emetti({ pos: p.clone().add(V3(rnd(-4, 4), rnd(1, 4), rnd(-4, 4))), vel: V3(rnd(-18, 18), rnd(8, 30), rnd(-18, 18)), vita: rnd(0.4, 1.0), s0: rnd(6, 12), s1: 2, a0: 1, col: 0xfff0b0, col1: 0xff4a10, drag: 1.2 });
      for (let k = 0; k < 16; k++) W.fumo.emetti({ pos: p.clone().add(V3(rnd(-6, 6), rnd(2, 6), rnd(-6, 6))), vel: V3(rnd(-6, 6), rnd(6, 14), rnd(-6, 6)), vita: rnd(8, 12), s0: 8, s1: 34, a0: 0.5, col: 0x3a3632, col1: 0x6a6560, drag: 0.4, su: 0.3 }); }, i * 420);
    W.sandyPassaggio = { t0: W.t, p: q };
  }

  /* ======================= navigatore GPS e marcatori ======================= */
  const gradiMin = (v, pos, neg, c) => { const a = Math.abs(v), gr = Math.floor(a), mi = (a - gr) * 60; return `${v >= 0 ? pos : neg}${String(gr).padStart(c, "0")}°${mi.toFixed(2).padStart(5, "0")}′`; };
  const km = d => d < 1000 ? `${Math.round(d)} m` : `${(d / 1000).toFixed(1).replace(".", ",")} km`;
  function puntoAttivo(k) {
    const L = LUOGHI, e = stima();
    if (W.recuperato) return { n: "USCITA", p: L.uscita, d: k.dUscita, b: k.brgUscita };
    if (W.fase >= 4) return { n: "LZ", p: L.lz, d: k.dLZ, b: k.brgLZ };
    if (W.fase >= 2 && e) { const P = W.S.pl.pos; return { n: "WSO?", p: e, d: Math.hypot(e.x - P.x, e.z - P.z), b: (Math.atan2(e.x - P.x, -(e.z - P.z)) / D2R + 360) % 360, r: e.r }; }
    return { n: "IP", p: L.ip, d: k.dIP, b: k.brgIP };
  }
  function strumenti(S, k) {
    const ov = I().overlay; if (!ov) return;
    if (!W.nav) {
      W.nav = document.createElement("canvas"); W.nav.id = "zg-gps"; Object.assign(W.nav.style, { position: "absolute", left: "12px", top: "70px", pointerEvents: "none", zIndex: 30 }); ov.appendChild(W.nav);
      W.mk = document.createElement("canvas"); W.mk.id = "zg-mk"; Object.assign(W.mk.style, { position: "absolute", inset: "0", width: "100%", height: "100%", pointerEvents: "none", zIndex: 29 }); ov.appendChild(W.mk);
    }
    if ((W.uiT = (W.uiT || 0) - 1) > 0) return; W.uiT = 3;
    const fila = ov.querySelector("#vl-top, .vl-top"), rf = fila ? fila.getBoundingClientRect() : null, ro = ov.getBoundingClientRect();
    const larg = innerHeight < 500 ? 108 : 140, alt = Math.round(larg * 344 / 264), dpr = Math.min(3, window.devicePixelRatio || 1), top = Math.round((rf && rf.bottom > 0 ? rf.bottom - ro.top : 60) + 10);
    if (W.navTop !== top || W.navW !== larg) { W.navTop = top; W.navW = larg; Object.assign(W.nav.style, { top: top + "px", width: larg + "px", height: alt + "px" }); W.nav.width = Math.round(larg * dpr); W.nav.height = Math.round(alt * dpr); }
    const g = W.nav.getContext("2d"), P = S.pl, f = V3(0, 0, 1).applyQuaternion(P.Q), hdg = (Math.atan2(f.x, -f.z) / D2R + 360) % 360, att = puntoAttivo(k);
    g.setTransform(W.nav.width / 264, 0, 0, W.nav.height / 344, 0, 0); g.clearRect(0, 0, 264, 344);
    g.fillStyle = "rgba(6,10,8,0.82)"; g.strokeStyle = "rgba(120,255,150,0.55)"; g.lineWidth = 2; g.beginPath(); g.roundRect ? g.roundRect(1, 1, 262, 342, 10) : g.rect(1, 1, 262, 342); g.fill(); g.stroke();
    g.font = "700 22px Consolas, monospace"; g.textAlign = "left"; g.fillStyle = "#5dff8f"; g.fillText("GPS", 14, 29); g.textAlign = "right"; g.font = "600 16px Consolas, monospace"; g.fillStyle = k.nvg ? "#5dff8f" : "#9aa59c"; g.fillText(k.nvg ? "NVG ON" : "NVG off (N)", 250, 28);
    // mappa orientata con la prua in alto, scala 1 px = 40 m (10 km di lato)
    const cx = 132, cy = 150, sc = 1 / 40, rot = -hdg * D2R;
    const scr = p => { const dx = (p.x - P.pos.x) * sc, dz = (p.z - P.pos.z) * sc; return { x: cx + dx * Math.cos(rot) - dz * Math.sin(rot), y: cy + dx * Math.sin(rot) + dz * Math.cos(rot) }; };
    g.save(); g.beginPath(); g.rect(8, 40, 248, 220); g.clip();
    // minacce: MANPADS (rosso), armi leggere ai campi e al convoglio (arancio)
    [[LUOGHI.osservazione, R_MANPADS, "255,60,60"], [LUOGHI.relitto, R_MANPADS, "255,60,60"]].forEach(([p, r, c]) => { const s = scr(p); g.fillStyle = `rgba(${c},0.15)`; g.strokeStyle = `rgba(${c},0.9)`; g.beginPath(); g.arc(s.x, s.y, r * sc, 0, PI * 2); g.fill(); g.stroke(); });
    CAMPI.forEach(p => { const s = scr(p); g.fillStyle = "rgba(255,160,40,0.16)"; g.strokeStyle = "rgba(255,170,60,0.9)"; g.beginPath(); g.arc(s.x, s.y, R_ARMI * sc, 0, PI * 2); g.fill(); g.stroke(); });
    if (!W.convoglio.fermo && W.fase >= 2) { const s = scr(W.mezzi[0].position); g.strokeStyle = "rgba(255,170,60,0.95)"; g.setLineDash([4, 3]); g.beginPath(); g.arc(s.x, s.y, R_ARMI * sc, 0, PI * 2); g.stroke(); g.setLineDash([]); }
    W.mezzi.forEach(m => { const s = scr(m.position); g.fillStyle = W.convoglio.fermo ? "#8a6a4a" : "#ffb24a"; g.fillRect(s.x - 2, s.y - 2, 4, 4); });
    if (W.F) W.F.nemici.forEach(q => { if (!q.vivo) return; const s = scr(q.pos); g.fillStyle = q.tipo === "tecnico" ? "#ff3030" : "#ff5a5a"; g.beginPath(); g.arc(s.x, s.y, q.tipo === "tecnico" ? 4 : 2.5, 0, PI * 2); g.fill(); });
    // rotta di valle pianificata
    g.strokeStyle = "rgba(100,225,255,0.55)"; g.setLineDash([6, 5]); g.lineWidth = 2; g.beginPath(); ROTTA.forEach((p, i) => { const s = scr(p); i ? g.lineTo(s.x, s.y) : g.moveTo(s.x, s.y); }); g.stroke(); g.setLineDash([]);
    // strada
    g.strokeStyle = "rgba(200,190,160,0.35)"; g.lineWidth = 1.5; g.beginPath(); STRADA.forEach((p, i) => { const s = scr(p); i ? g.lineTo(s.x, s.y) : g.moveTo(s.x, s.y); }); g.stroke();
    // stima del WSO (cerchio di incertezza) e punto attivo
    const e = stima(); if (e && !W.recuperato) { const s = scr(e); g.strokeStyle = "rgba(255,150,40,0.95)"; g.setLineDash([5, 4]); g.beginPath(); g.arc(s.x, s.y, e.r * sc, 0, PI * 2); g.stroke(); g.setLineDash([]); g.fillStyle = "#ff9a2a"; g.beginPath(); g.moveTo(s.x, s.y - 6); g.lineTo(s.x + 6, s.y); g.lineTo(s.x, s.y + 6); g.lineTo(s.x - 6, s.y); g.fill(); }
    const a = scr(att.p); g.strokeStyle = "#ff6ae6"; g.lineWidth = 3.5; g.beginPath(); g.moveTo(cx, cy); g.lineTo(a.x, a.y); g.stroke();
    [["IP", LUOGHI.ip], ["LZ", LUOGHI.lz], ["USC", LUOGHI.uscita]].forEach(([n, p]) => { const s = scr(p); g.fillStyle = "#64e1ff"; g.beginPath(); g.arc(s.x, s.y, 4, 0, PI * 2); g.fill(); g.font = "600 12px Consolas, monospace"; g.textAlign = "left"; g.fillText(n, s.x + 6, s.y + 4); });
    g.restore();
    g.fillStyle = "#e9fff0"; g.beginPath(); g.moveTo(cx, cy - 9); g.lineTo(cx + 6, cy + 7); g.lineTo(cx, cy + 3); g.lineTo(cx - 6, cy + 7); g.fill();
    // dati del punto attivo
    g.textAlign = "left"; g.font = "700 20px Consolas, monospace"; g.fillStyle = "#ff8af0"; g.fillText(att.n, 14, 286); g.textAlign = "right"; g.fillStyle = "#e9fff0"; g.fillText(km(att.d), 250, 286);
    const gs = Math.max(1, Math.hypot(P.vel.x, P.vel.z)), ete = att.d / gs; g.font = "600 15px Consolas, monospace"; g.textAlign = "left"; g.fillStyle = "#cfe9d6";
    g.fillText(`RTA ${String(Math.round(att.b)).padStart(3, "0")}°  ${Math.floor(ete / 60)}:${String(Math.round(ete % 60)).padStart(2, "0")}`, 14, 308);
    const prossimo = W.prossimoImpulso != null && !W.recuperato && W.fase >= 2 ? Math.max(0, W.prossimoImpulso - W.t) : null;
    g.fillText(att.r ? `±${att.r} m  impulso ${Math.round(prossimo || 0)} s` : `${Math.round(k.aglFt)} ft AGL  ${Math.round(k.kt)} kt`, 14, 330);
    // marcatori sullo schermo (come nel visore del casco)
    const cam = I().camera, mk = W.mk, mg = mk.getContext("2d"); const w = mk.clientWidth, h = mk.clientHeight;
    if (mk.width !== Math.round(w * dpr)) { mk.width = Math.round(w * dpr); mk.height = Math.round(h * dpr); } mg.setTransform(dpr, 0, 0, dpr, 0, 0); mg.clearRect(0, 0, w, h);
    if (!cam || S.cineHud === false) return;
    const proietta = (p, y) => { const v = V3(p.x, (y != null ? y : suolo(p.x, p.z)) + 2, p.z).project(cam); return v.z < 1 ? { x: (v.x + 1) / 2 * w, y: (1 - v.y) / 2 * h } : null; };
    const disegna = (p, col, txt, forma) => { const s = proietta(p); if (!s) return; mg.strokeStyle = col; mg.fillStyle = col; mg.lineWidth = 2; mg.beginPath(); if (forma === "rombo") { mg.moveTo(s.x, s.y - 9); mg.lineTo(s.x + 9, s.y); mg.lineTo(s.x, s.y + 9); mg.lineTo(s.x - 9, s.y); mg.closePath(); } else mg.arc(s.x, s.y, 8, 0, PI * 2); mg.stroke(); mg.font = "600 13px Consolas, monospace"; mg.textAlign = "center"; mg.fillText(txt, s.x, s.y - 14); };
    if (e && !W.recuperato && W.fase >= 2) disegna(e, "#ff9a2a", `WSO? ±${e.r} m`, "rombo");
    if (W.fase >= 4 && !W.recuperato) disegna(LUOGHI.lz, "#64e1ff", `LZ ${km(k.dLZ)}`);
    if (W.recuperato) disegna(LUOGHI.uscita, "#64e1ff", `USCITA ${km(k.dUscita)}`);
    else if (W.fase < 2) disegna(LUOGHI.ip, "#64e1ff", `IP ${km(k.dIP)}`);
  }

  /* ======================= combattimento: mitragliatrici di porta, squadre ostili, PJ a terra, SANDY ======================= */
  // HH-60 (UH-60 nel simulatore) con due mitragliatrici di porta: settori di tiro a destra e a sinistra (30°-150° dalla prua).
  // Tasto 1: armi in sicura / armi libere (i mitraglieri ingaggiano da soli); tasto 2: prendi tu la mitragliatrice destra, poi
  // la sinistra, poi la rendi al mitragliere (in vista mitragliere l'elicottero tiene l'hovering, frecce o trascinamento per
  // mirare, Spazio o FUOCO per sparare); tasto 3: chiama SANDY (passaggio dell'A-10 con il cannone sul gruppo più vicino).
  const ARMI = { arco: [30, 150], gittata: 900, cadenza: 0.055 };
  const ARMA_OFF = { dx: V3(-1.25, 0.15, 1.3), sx: V3(1.25, 0.15, 1.3) };   // la destra dell'elicottero è -X locale (prua +Z)   // posizione delle armi nel riferimento dell'elicottero
  const TASTI = {};
  let tastiAgganciati = false;
  function agganciaTasti() {
    if (tastiAgganciati) return; tastiAgganciati = true;
    const blocca = ["arrowup", "arrowdown", "arrowleft", "arrowright", "w", "a", "s", "d", " "];
    window.addEventListener("keydown", e => {
      if (!W || !W.F || !VOLO.attivo) return; const k = e.key.toLowerCase();
      if (k === "1" || k === "2" || k === "3") { if (!e.repeat) comando(k); e.preventDefault(); e.stopImmediatePropagation(); return; }
      if (W.F.manuale && blocca.includes(k)) { TASTI[k] = true; e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
    window.addEventListener("keyup", e => { const k = e.key.toLowerCase(); if (TASTI[k]) { TASTI[k] = false; if (W && W.F && W.F.manuale) { e.preventDefault(); e.stopImmediatePropagation(); } } }, true);
  }
  function messaggio(t, d, c) { try { VOLO._acc.messaggio(t, d || 2.5, c); } catch (e) {} }
  function comando(k) {
    const F = W.F; if (!F) return;
    if (k === "1") { F.libere = !F.libere; messaggio(F.libere ? "MITRAGLIERI · ARMI LIBERE" : "MITRAGLIERI · ARMI IN SICURA", 2.2); }
    else if (k === "2") { F.manuale = F.manuale === null ? "dx" : F.manuale === "dx" ? "sx" : null; F.aim = { yaw: F.manuale === "sx" ? -90 : 90, pitch: -12 };
      if (F.manuale) { F.tieni = { pos: W.S.pl.pos.clone(), Q: W.S.pl.Q.clone() }; messaggio(`MITRAGLIATRICE ${F.manuale === "dx" ? "DESTRA" : "SINISTRA"} · frecce per mirare, Spazio per sparare`, 3); }
      else { F.tieni = null; messaggio("MITRAGLIATRICE AL MITRAGLIERE", 2); } }
    else if (k === "3") chiamaSandy();
    aggiornaPulsanti();
  }
  function aggiornaPulsanti() {
    const F = W && W.F; if (!F || !F.ui) return; const b = F.ui.querySelectorAll("button");
    b[0].textContent = F.libere ? "🔫 ARMI LIBERE" : "🔫 IN SICURA"; b[0].classList.toggle("on", F.libere);
    b[1].textContent = F.manuale ? `🎯 MITRAGLIERA ${F.manuale === "dx" ? "DX" : "SX"}` : "🎯 MITRAGLIERA"; b[1].classList.toggle("on", !!F.manuale);
    const pronto = F.sandyPronto <= W.t && F.sandyResidui > 0; b[2].textContent = F.sandyResidui > 0 ? (pronto ? `✈ SANDY (${F.sandyResidui})` : `✈ SANDY ${Math.ceil(F.sandyPronto - W.t)} s`) : "✈ SANDY —"; b[2].classList.toggle("on", pronto);
    b[3].style.display = F.manuale ? "block" : "none";
  }
  function preparaFuoco(S) {
    const ov = I().overlay;
    W.F = { libere: false, manuale: null, aim: { yaw: 90, pitch: -12 }, colpi: { dx: 0, sx: 0 }, sparaT: { dx: 0, sx: 0 }, raffica: { dx: 0, sx: 0 }, pausa: { dx: 0, sx: 0 }, bersaglio: { dx: null, sx: null },
      fuocoManuale: false, sandyPronto: 0, sandyResidui: 3, sandy: null, nemici: [], pj: [], uccisi: 0, tSquadra: 0, ondate: 0 };
    agganciaTasti();
    if (ov && !document.getElementById("zg-armi")) {
      const st = document.createElement("style"); st.id = "zg-armi-stile";
      st.textContent = `#zg-armi{position:absolute;right:10px;top:46%;display:flex;flex-direction:column;gap:6px;z-index:31}
#zg-armi button{font:700 12px Consolas,monospace;color:#cfe9d6;background:rgba(6,12,8,.82);border:1px solid rgba(120,255,150,.45);border-radius:8px;padding:7px 9px;min-width:132px;text-align:left;cursor:pointer}
#zg-armi button.on{color:#06110a;background:#78ff96}#zg-armi .fuoco{background:rgba(120,20,10,.85);color:#fff;border-color:#ff8a6a;text-align:center;font-size:14px;padding:12px}
#zg-mira{position:absolute;inset:0;z-index:28;display:none;touch-action:none}`;
      document.head.appendChild(st);
      const ui = document.createElement("div"); ui.id = "zg-armi"; ui.innerHTML = `<button type="button" title="Tasto 1"></button><button type="button" title="Tasto 2"></button><button type="button" title="Tasto 3"></button><button type="button" class="fuoco">FUOCO</button>`;
      ov.appendChild(ui); W.F.ui = ui; const bb = ui.querySelectorAll("button");
      bb[0].onclick = () => comando("1"); bb[1].onclick = () => comando("2"); bb[2].onclick = () => comando("3");
      const f = bb[3]; f.onpointerdown = e => { W.F.fuocoManuale = true; e.preventDefault(); }; f.onpointerup = f.onpointerleave = () => { if (W && W.F) W.F.fuocoManuale = false; };
      // trascinamento sullo schermo per mirare in vista mitragliere
      const m = document.createElement("div"); m.id = "zg-mira"; ov.appendChild(m); W.F.mira = m; let ult = null;
      m.onpointerdown = e => { ult = [e.clientX, e.clientY]; m.setPointerCapture(e.pointerId); };
      m.onpointermove = e => { if (!ult || !W || !W.F) return; W.F.aim.yaw += (e.clientX - ult[0]) * 0.12; W.F.aim.pitch = clamp(W.F.aim.pitch - (e.clientY - ult[1]) * 0.12, -60, 12); ult = [e.clientX, e.clientY]; };
      m.onpointerup = () => { ult = null; };
    } else if (document.getElementById("zg-armi")) { W.F.ui = document.getElementById("zg-armi"); W.F.mira = document.getElementById("zg-mira"); }
    aggiornaPulsanti();
  }
  // squadre ostili: Pasdaran (divisa) e nomadi armati (abiti scuri), un pick-up con mitragliatrice pesante
  function nuovoNemico(p, tipo) {
    const naz = tipo === "pasdaran", o = persona(naz ? { tuta: 0x4d5340, giubbotto: 0x3a3e30, casco: 0x3f4434, fucile: true } : { tuta: 0x3e3830, giubbotto: false, turbante: 0x2a2520, casco: false, fucile: true, pelle: 0x8d6a52 });
    W.sc.add(o); W.oggetti.push(o); o.position.set(p.x, suolo(p.x, p.z), p.z);
    const lampo = luceSprite(0xffd890, 2.6, 1); lampo.visible = false; o.userData.j.busto.add(lampo); lampo.position.set(0.12, 0.38, 0.75);
    return { obj: o, lampo, pos: V3(p.x, suolo(p.x, p.z), p.z), stato: "avanza", t: rnd(0, 2), vivo: true, tipo, sparaT: rnd(0, 1), sopp: 0, meta: null, passo: rnd(0, 1), v: rnd(3.6, 4.4) };
  }
  function nuovoTecnico(p) {
    const g = new THREE.Group(), v = mStd(0xb9b2a2), s = mStd(0x1e1e1e);
    g.add(mesh(new THREE.BoxGeometry(1.8, 0.9, 4.6), v, 0, 0.95, 0)); g.add(mesh(new THREE.BoxGeometry(1.7, 0.8, 1.6), v, 0, 1.75, 0.7));
    [[-0.85, 1.4], [0.85, 1.4], [-0.85, -1.4], [0.85, -1.4]].forEach(([x, z]) => { const r = mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.3, 12), s, x, 0.38, z); r.rotation.z = PI / 2; g.add(r); });
    const mg = mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.6, 8), s, 0, 2.1, -1.1); mg.rotation.x = PI / 2; g.add(mg);
    const lampo = luceSprite(0xffd890, 2.2, 0.9); lampo.position.set(0, 2.1, -0.2); lampo.visible = false; g.add(lampo);
    W.sc.add(g); W.oggetti.push(g); g.position.set(p.x, suolo(p.x, p.z), p.z);
    return { obj: g, lampo, pos: V3(p.x, suolo(p.x, p.z), p.z), stato: "avanza", t: 0, vivo: true, tipo: "tecnico", sparaT: 0, sopp: 0, meta: null, v: 6, hp: 14 };
  }
  // un gruppo che sbuca a 260-330 m dalla LZ e sale verso posizioni di tiro a 120-210 m (il pick-up resta più indietro)
  function ondata(dirDeg, n, tipo, tecnico) {
    const L = LUOGHI, a = dirDeg * D2R, rb = rnd(260, 330), base = V3(L.lz.x + Math.sin(a) * rb, 0, L.lz.z - Math.cos(a) * rb);
    for (let i = 0; i < n; i++) { const q = nuovoNemico({ x: base.x + rnd(-30, 30), z: base.z + rnd(-30, 30) }, tipo); q.meta = postazione(a, 120, 210); q.gruppo = W.F.ondate; W.F.nemici.push(q); }
    if (tecnico) { const t = nuovoTecnico({ x: base.x + 20, z: base.z }); t.meta = postazione(a, 200, 300); t.gruppo = W.F.ondate; W.F.nemici.push(t); }
    W.F.ondate++;
  }
  // linea di vista sul rilievo (12 campioni, tolleranza per i pendii sfiorati)
  function vista(a, b) { for (let i = 1; i < 12; i++) { const u = i / 12; const x = mix(a.x, b.x, u), z = mix(a.z, b.z, u), y = mix(a.y, b.y, u); if (y < suolo(x, z) - 0.6) return false; } return true; }
  // una postazione di tiro nella direzione indicata, a una distanza tra rMin e rMax, da cui si vede la LZ
  function postazione(a, rMin, rMax) {
    const L = LUOGHI, lz = V3(L.lz.x, suolo(L.lz.x, L.lz.z) + 20, L.lz.z);
    let best = null, bm = -1e9;
    for (let k = 0; k < 60; k++) { const ra = a + rnd(-0.8, 0.8), rr = rnd(k < 40 ? rMin : 160, rMax), p = V3(L.lz.x + Math.sin(ra) * rr, 0, L.lz.z - Math.cos(ra) * rr); p.y = suolo(p.x, p.z) + 1.3; if (vista(p, lz)) return p;
      let m = 99; for (let i = 1; i < 12; i++) { const u = i / 12; m = Math.min(m, mix(p.y, lz.y, u) - suolo(mix(p.x, lz.x, u), mix(p.z, lz.z, u))); } if (m > bm) { bm = m; best = p; } }
    return best;
  }
  function tracciante(da, a, col, vel) {
    const dir = a.clone().sub(da), d = dir.length(); dir.normalize(); const v = vel || 820;
    const vv = dir.clone().multiplyScalar(v), vita = Math.min(2.2, d / v);
    for (let i = 0; i < 9; i++) W.traccianti.emetti({ pos: da.clone().addScaledVector(dir, -i * 3.6), vel: vv, vita: Math.max(0.05, vita - i * 3.6 / v), s0: 4.2 - i * 0.38, s1: 3.6 - i * 0.33, a0: 1 - i * 0.09, inA: 0.01, col, col1: col, drag: 0, rv: 0 });
  }
  function polvere(p, forte) { const y = suolo(p.x, p.z); W.fumo.emetti({ pos: V3(p.x, y + 0.4, p.z), vel: V3(rnd(-1, 1), rnd(2, 5), rnd(-1, 1)), vita: rnd(0.8, 1.6), s0: forte ? 2.2 : 1.1, s1: forte ? 6 : 3, a0: 0.45, col: 0x8a7d66, drag: 1.2 }); if (forte || Math.random() < 0.3) W.fuoco.emetti({ pos: V3(p.x, y + 0.5, p.z), vel: V3(0, 1, 0), vita: forte ? 0.2 : 0.12, s0: forte ? 3.2 : 1.4, s1: 0.6, a0: 1, col: 0xfff0c0, drag: 2 }); }
  function abbatti(q) {
    if (!q.vivo) return; q.vivo = false; W.F.uccisi++; q.lampo.visible = false;
    if (q.tipo === "tecnico") { for (let i = 0; i < 30; i++) W.fuoco.emetti({ pos: q.pos.clone().add(V3(rnd(-2, 2), rnd(0.5, 2.5), rnd(-2, 2))), vel: V3(rnd(-8, 8), rnd(4, 14), rnd(-8, 8)), vita: rnd(0.4, 1), s0: rnd(3, 6), s1: 1, a0: 1, col: 0xffd080, col1: 0xff3a08, drag: 1 }); q.bruciaT = 40; return; }
    q.cade = 0; q.cadeDir = rnd(0, 1) < 0.5 ? 1 : -1;
  }
  function sopprimi(p, r, s) { W.F.nemici.forEach(q => { if (q.vivo && q.pos.distanceTo(p) < r) { q.sopp = Math.max(q.sopp, s); if (q.stato !== "riparo") { q.stato = "riparo"; q.t = s; } } }); }
  // colpo su un punto: chi è entro il raggio letale cade, chi è vicino si ripara
  function impattoColpo(p, letale) {
    polvere(p, false);
    W.F.nemici.forEach(q => { if (!q.vivo) return; const d = Math.hypot(q.pos.x - p.x, q.pos.z - p.z);
      if (q.tipo === "tecnico") { if (d < 3) { q.hp -= 1; if (q.hp <= 0) abbatti(q); } }
      else if (d < letale && Math.random() < (letale > 3 ? 0.6 : q.stato === "riparo" ? 0.03 : 0.12)) abbatti(q); /* la .50 inchioda più che abbattere; il cannone dell'A-10 no */ else if (d < 6) { q.sopp = Math.max(q.sopp, 2); if (q.stato !== "riparo") { q.stato = "riparo"; q.t = 2; } } });
  }
  function puntoArma(lato) { const P = W.S.pl; return ARMA_OFF[lato].clone().applyQuaternion(P.Q).add(P.pos); }
  function direzioneArma(lato, yawDeg, pitchDeg) { const P = W.S.pl, f = V3(0, 0, 1).applyQuaternion(P.Q).setY(0).normalize(), h = Math.atan2(f.x, f.z) + yawDeg * D2R * -1; const cp = Math.cos(pitchDeg * D2R); return V3(Math.sin(h) * cp, Math.sin(pitchDeg * D2R), Math.cos(h) * cp).normalize(); }
  function suTerreno(o, dir, max) { const p = o.clone(); for (let s = 0; s < max; s += 6) { p.addScaledVector(dir, 6); if (p.y <= suolo(p.x, p.z)) return p; } return null; }
  function relativoAllaPrua(p) { const P = W.S.pl, f = V3(0, 0, 1).applyQuaternion(P.Q).setY(0).normalize(); const v = V3(p.x - P.pos.x, 0, p.z - P.pos.z).normalize(); return Math.atan2(f.x * v.z - f.z * v.x, f.x * v.x + f.z * v.z) / D2R; }   // gradi, + a destra
  function spara(lato, punto, sigma, dt) {
    const F = W.F; F.sparaT[lato] -= dt; if (F.sparaT[lato] > 0) return; F.sparaT[lato] = ARMI.cadenza;
    const da = puntoArma(lato), d = da.distanceTo(punto), err = sigma * d / 500;
    const imp = V3(punto.x + rnd(-1, 1) * err, 0, punto.z + rnd(-1, 1) * err); imp.y = suolo(imp.x, imp.z) + 0.3;
    F.colpi[lato]++; if (F.colpi[lato] % 3 === 0) tracciante(da, imp, 0xff6a3a, 880);
    W.fuoco.emetti({ pos: da.clone(), vel: V3(0, 0, 0), vita: 0.05, s0: 1.4, s1: 0.6, a0: 1, col: 0xffe0a0, drag: 0 });
    impattoColpo(imp, sigma < 2 ? 1.5 : 1.1);
  }
  function chiamaSandy() {
    const F = W.F; if (F.sandyResidui <= 0) { messaggio("SANDY 1: senza munizioni per il cannone", 2.5); return; }
    if (F.sandyPronto > W.t) { messaggio(`SANDY 1: in posizione tra ${Math.ceil(F.sandyPronto - W.t)} s`, 2); return; }
    const vivi = F.nemici.filter(q => q.vivo); if (!vivi.length) { messaggio("SANDY 1: nessun bersaglio vicino alla LZ", 2); return; }
    // il gruppo più vicino alla LZ
    const L = LUOGHI; vivi.sort((a, b) => Math.hypot(a.pos.x - L.lz.x, a.pos.z - L.lz.z) - Math.hypot(b.pos.x - L.lz.x, b.pos.z - L.lz.z));
    const c = vivi[0].pos.clone(); const dalLZ = V3(c.x - L.lz.x, 0, c.z - L.lz.z).normalize(), asse = V3(-dalLZ.z, 0, dalLZ.x);   // passaggio parallelo alla LZ: non spara verso i PJ
    F.sandy = { t: 0, c, asse, obj: a10(), spari: 0 }; W.sc.add(F.sandy.obj); W.oggetti.push(F.sandy.obj);
    F.sandyResidui--; F.sandyPronto = W.t + 35; messaggio("SANDY 1: «in arrivo da est, passaggio con il cannone sul gruppo più vicino»", 3.5);
  }
  function aggiornaSandy(dt) {
    const F = W.F, s = F.sandy; if (!s) return; s.t += dt;
    const k = s.t, x = -1800 + k * 190, pos = s.c.clone().addScaledVector(s.asse, x); pos.y = s.c.y + 320 - Math.max(0, 1 - Math.abs(x) / 1500) * 210 + Math.max(0, x) * 0.25;
    s.obj.position.copy(pos); const fw = s.asse.clone(); fw.y = x < 0 ? -0.2 : 0.18; s.obj.quaternion.copy(VOLO._acc.assetto(Math.atan2(fw.x, -fw.z), Math.atan2(fw.y, 1), x > 200 ? -0.5 : 0));
    // raffica del GAU-8: 2 secondi, una fila di impatti che attraversa il gruppo
    if (x > -900 && x < -500) { s.spari += dt; const u = (x + 900) / 400, p = s.c.clone().addScaledVector(s.asse, mix(-60, 60, u)); for (let i = 0; i < 3; i++) { const q = p.clone().add(V3(rnd(-6, 6), 0, rnd(-6, 6))); polvere(q, true); impattoColpo(q, 4.5); }
      if (Math.random() < 0.6) tracciante(pos, p, 0xffb070, 1100); W.fuoco.emetti({ pos: pos.clone(), vel: V3(0, 0, 0), vita: 0.06, s0: 6, s1: 2, a0: 1, col: 0xfff0b0, drag: 0 }); sopprimi(p, 45, 8); }
    if (k > 22) { W.sc.remove(s.obj); F.sandy = null; }
  }
  function aggiornaNemici(dt) {
    const F = W.F, P = W.S.pl, L = LUOGHI, hP = P.pos.clone().add(V3(0, 1, 0));
    F.nemici.forEach(q => {
      if (!q.vivo) {
        if (q.cade != null && q.cade < 1) { q.cade = Math.min(1, q.cade + dt * 2.2); q.obj.rotation.set(q.cadeDir * 1.45 * ss(0, 1, q.cade), q.obj.rotation.y, 0); q.obj.position.y = suolo(q.pos.x, q.pos.z) + 0.15 * q.cade; posa(q.obj, "appeso"); }
        if (q.bruciaT > 0) { q.bruciaT -= dt; if (Math.random() < 0.5) { W.fuoco.emetti({ pos: q.pos.clone().add(V3(rnd(-1.5, 1.5), rnd(0.8, 2), rnd(-2, 2))), vel: V3(0, rnd(2, 4), 0), vita: rnd(0.4, 0.8), s0: rnd(2, 3.5), s1: 0.8, a0: 0.9, col: 0xffc060, col1: 0xff3a08, drag: 0.4 }); W.fumo.emetti({ pos: q.pos.clone().add(V3(0, 2.5, 0)), vel: V3(rnd(-0.5, 0.5), rnd(3, 5), rnd(-0.5, 0.5)), vita: rnd(6, 9), s0: 2.5, s1: 12, a0: 0.4, col: 0x1e1c1a, col1: 0x4a4744, drag: 0.2, su: 0.15 }); } }
        return; }
      q.t -= dt; q.sopp = Math.max(0, q.sopp - dt); q.lampo.visible = false;
      if (W.recuperato && q.stato === "spara") { q.stato = "riparo"; q.t = 999; }   // WSO a bordo: l'elicottero se ne va, il gruppo resta indietro
      const dLZ = Math.hypot(q.pos.x - L.lz.x, q.pos.z - L.lz.z);
      if (q.stato === "avanza") {
        const m = q.meta, dx = m.x - q.pos.x, dz = m.z - q.pos.z, d = Math.hypot(dx, dz);
        if (d < 4 || q.t < -70) { q.stato = "spara"; q.t = rnd(3, 6); }
        else { const v = q.v * dt; q.pos.x += dx / d * v; q.pos.z += dz / d * v; q.obj.rotation.y = Math.atan2(dx, dz); }
        if (q.tipo !== "tecnico") posa(q.obj, "corsa", (q.passo += dt * 1.6));
      } else if (q.stato === "riparo") {
        if (q.tipo !== "tecnico") posa(q.obj, "rannicchiato");
        if (q.t <= 0 && (q.sopp <= 0 || Math.random() < 0.02)) { const occ = q.pos.clone().add(V3(0, 1.2, 0)); if (vista(occ, hP)) { q.stato = "spara"; q.t = rnd(3, 6); } else { const a = Math.atan2(q.pos.x - L.lz.x, -(q.pos.z - L.lz.z)); q.meta = postazione(a, Math.max(150, dLZ - 160), Math.max(200, dLZ - 40)); q.stato = "avanza"; q.t = 0; } }
      } else if (q.stato === "spara") {
        q.obj.rotation.y = Math.atan2(hP.x - q.pos.x, hP.z - q.pos.z); if (q.tipo !== "tecnico") posa(q.obj, "ginocchio");
        const occhio = q.pos.clone().add(V3(0, q.tipo === "tecnico" ? 2.1 : 1.2, 0)), d = occhio.distanceTo(hP);
        const vede = d < 750 && vista(occhio, hP); if (!vede) { q.cieco = (q.cieco || 0) + dt; if (q.cieco > 1.5) { q.cieco = 0; const a = Math.atan2(q.pos.x - L.lz.x, -(q.pos.z - L.lz.z)); q.meta = postazione(a, Math.max(150, dLZ - 160), Math.max(200, dLZ - 40)); q.stato = "avanza"; q.t = 0; } } else q.cieco = 0;
        if (vede) { q.sparaT -= dt; if (q.sparaT <= 0) { q.sparaT = q.tipo === "tecnico" ? 0.09 : rnd(0.12, 0.3); q.lampo.visible = true;
            const mira = hP.clone().add(V3(rnd(-9, 9), rnd(-4, 7), rnd(-9, 9))); if (Math.random() < 0.55) tracciante(occhio, mira, 0x7dff7a, 700);
            const p = (q.tipo === "tecnico" ? 0.025 : 0.006) * (1 - d / 800) * (q.sopp > 0 ? 0.25 : 1);
            if (Math.random() < p && (W.F.colpitoT || 0) <= W.t) { W.F.colpitoT = W.t + 1.2; W.colpi++; messaggio(`COLPITI · ${q.tipo === "tecnico" ? "mitragliatrice pesante" : "armi leggere"} (${W.colpi})`, 2, "warn");
              for (let i = 0; i < 10; i++) W.fuoco.emetti({ pos: hP.clone().add(V3(rnd(-1.5, 1.5), rnd(-0.5, 1), rnd(-2, 2))), vel: V3(rnd(-6, 6), rnd(0, 6), rnd(-6, 6)), vita: 0.3, s0: 0.6, s1: 0.2, a0: 1, col: 0xfff0a0, drag: 1 }); } } }
        if (q.t <= 0) { q.stato = dLZ > 140 && Math.random() < 0.5 ? "riparo" : "spara"; q.t = rnd(2, 5); if (q.stato === "riparo" && Math.random() < 0.6) { const a = Math.atan2(q.pos.x - L.lz.x, -(q.pos.z - L.lz.z)) + rnd(-0.25, 0.25), r = Math.max(80, dLZ - rnd(50, 90)); q.meta = V3(L.lz.x + Math.sin(a) * r, 0, L.lz.z - Math.cos(a) * r); q.stato = "avanza"; q.t = 0; } }
      }
      q.pos.y = suolo(q.pos.x, q.pos.z); q.obj.position.copy(q.pos); if (q.tipo !== "tecnico") q.obj.rotation.x = 0;
    });
  }
  function aggiornaArmi(dt) {
    const F = W.F, P = W.S.pl;
    ["dx", "sx"].forEach(lato => {
      if (F.manuale === lato) {
        const yaw = clamp(F.aim.yaw * (lato === "dx" ? 1 : -1), ARMI.arco[0] - 10, ARMI.arco[1] + 10) * (lato === "dx" ? 1 : -1); F.aim.yaw = yaw;
        const dir = direzioneArma(lato, yaw, F.aim.pitch), o = puntoArma(lato), hit = suTerreno(o, dir, 1400); F.mirino = hit;
        if ((TASTI[" "] || F.fuocoManuale) && hit) spara(lato, hit, 1.0, dt);
        return; }
      if (!F.libere) return;
      // mitragliere: bersaglio vivo più vicino nel suo settore, a vista, entro la gittata; raffiche di 1,5 s
      if (F.pausa[lato] > 0) { F.pausa[lato] -= dt; return; }
      let b = F.bersaglio[lato]; const o = puntoArma(lato);
      const valido = q => q && q.vivo && q.pos.distanceTo(o) < ARMI.gittata && (() => { const a = relativoAllaPrua(q.pos) * (lato === "dx" ? 1 : -1); return a > ARMI.arco[0] && a < ARMI.arco[1]; })() && vista(o, q.pos.clone().add(V3(0, 1, 0)));
      if (!valido(b)) { b = null; let best = 1e9; F.nemici.forEach(q => { if (!q.vivo) return; const d = q.pos.distanceTo(o); if (d < best && valido(q)) { best = d; b = q; } }); F.bersaglio[lato] = b; F.raffica[lato] = 0; }
      if (!b) return;
      F.raffica[lato] += dt; spara(lato, b.pos.clone().add(V3(0, 0.8, 0)), 3.2, dt);
      if (F.raffica[lato] > 1.5) { F.raffica[lato] = 0; F.pausa[lato] = rnd(0.8, 1.8); }
    });
  }
  // il team di PJ a terra durante la difesa della LZ: due al perimetro (sparano), due salgono dal WSO e lo riportano
  function preparaPJ() {
    const pj = { camo: true, giubbotto: 0x3f3d30, casco: 0x4d4b3c, attrezzi: 0x22231f, fucile: true, zaino: 0x4a4637, nvg: true, guanti: true };
    W.F.pj = [0, 1, 2, 3].map(i => { const o = persona(Object.assign({ nome: "PJ " + (i + 1) }, pj, i === 1 ? { borsa: true } : {})); W.sc.add(o); W.oggetti.push(o); const l = luceSprite(0xffd890, 1.4, 0.9); l.visible = false; o.userData.j.busto.add(l); l.position.set(0.12, 0.38, 0.75); return { obj: o, lampo: l, sparaT: rnd(0, 1) }; });
  }
  function aggiornaPJ(dt, tf) {
    const F = W.F, L = LUOGHI, P = W.S.pl; if (!F.pj.length) return;
    const lz = V3(F.difesa ? F.difesa.pos.x : P.pos.x, 0, F.difesa ? F.difesa.pos.z : P.pos.z); lz.y = suolo(lz.x, lz.z); const ws = W.wso.position.clone(), vW = ws.clone().sub(lz).setY(0).normalize(), lat = V3(-vW.z, 0, vW.x);
    const terra = p => { p.y = suolo(p.x, p.z); return p; };
    F.pj.forEach((p, i) => {
      const o = p.obj; o.visible = true; p.lampo.visible = false;
      if (i >= 2) {   // perimetro: corsa in posizione, poi in ginocchio a sparare al nemico più vicino entro 450 m
        const pos = terra(lz.clone().addScaledVector(lat, i === 2 ? 22 : -22).addScaledVector(vW, -8)), k = ss(0, 4, tf), cur = terra(lz.clone().lerp(pos, k));
        o.position.copy(cur);
        let b = null, best = 450; F.nemici.forEach(q => { if (q.vivo) { const d = q.pos.distanceTo(cur); if (d < best) { best = d; b = q; } } });
        if (k < 1) { o.rotation.y = Math.atan2(pos.x - lz.x, pos.z - lz.z); posa(o, "corsa", tf * 1.6); }
        else if (b) { o.rotation.y = Math.atan2(b.pos.x - cur.x, b.pos.z - cur.z); posa(o, "ginocchio"); p.sparaT -= dt; if (p.sparaT <= 0) { p.sparaT = rnd(0.25, 0.6); p.lampo.visible = true; const da = cur.clone().add(V3(0, 1.1, 0)); if (Math.random() < 0.5) tracciante(da, b.pos.clone().add(V3(rnd(-3, 3), 1, rnd(-3, 3))), 0xff6a3a, 800); if (Math.random() < 0.08) impattoColpo(b.pos.clone(), 1.5); else sopprimi(b.pos, 8, 2.5); } }
        else posa(o, "ginocchio");
      } else {        // capo squadra e paramedico: su dal WSO (0-20 s), autenticazione e cure (20-55 s), ritorno con il WSO (55-75 s)
        const vicino = terra(ws.clone().addScaledVector(vW, -1.4).addScaledVector(lat, i ? 0.9 : -0.9));
        if (tf < 20) { const k = ss(0, 20, tf); o.position.copy(terra(lz.clone().lerp(vicino, k))); o.rotation.y = Math.atan2(vicino.x - lz.x, vicino.z - lz.z); posa(o, "corsa", tf * 1.6); }
        else if (tf < 55) { o.position.copy(vicino); o.rotation.y = Math.atan2(ws.x - vicino.x, ws.z - vicino.z); posa(o, i ? "cura" : "punta", tf); }
        else { const k = ss(55, 75, tf), pos = terra(vicino.clone().lerp(lz.clone().addScaledVector(lat, i ? 3 : 1.6), k)); o.position.copy(pos); o.rotation.y = Math.atan2(lz.x - vicino.x, lz.z - vicino.z); posa(o, "cammina", tf * 1.1); }
      }
    });
    // il WSO: esce dalla fenditura, curato, poi sostenuto dai due PJ
    if (tf < 20) posa(W.wso, tf > 12 ? "saluta" : "rannicchiato", tf);
    else if (tf < 55) posa(W.wso, "seduto");
    else { const k = ss(55, 75, tf), a = ws.clone().lerp(lz.clone().addScaledVector(lat, 2.3), k); a.y = suolo(a.x, a.z); W.wso.position.copy(a); W.wso.rotation.y = Math.atan2(lz.x - ws.x, lz.z - ws.z); posa(W.wso, "sostenuto", tf * 1.1); }
  }
  // tiene fermo l'elicottero (a terra sulla LZ o in vista mitragliere); la pedaliera Q/E lo ruota sul posto
  function tieniElicottero(S, pos, Q) {
    const P = S.pl; P.pos.copy(pos); P.Q.copy(Q); P.vel.set(0, 0, 0); P.rigid6 = null;
    const sim = P.rotorSim; if (sim) { sim.r = P.pos.toArray(); sim.v = [0, 0, 0]; sim.q = [Q.x, Q.y, Q.z, Q.w]; if (sim.w) sim.w = [0, 0, 0]; }
    if (P.obj) { P.obj.position.copy(P.pos); P.obj.quaternion.copy(P.Q); }
  }
  function combattimento(dt, S) {
    const F = W.F; if (!F || C) return;
    if (W.fase === 5 && F.difesa) {   // difesa della LZ: elicottero a terra, ruota con Q/E
      const d = F.difesa; d.t += dt; const ruota = (TASTIQE.q ? 1 : 0) - (TASTIQE.e ? 1 : 0);
      if (ruota) d.Q.premultiply(new THREE.Quaternion().setFromAxisAngle(V3(0, 1, 0), ruota * dt * 0.6));
      tieniElicottero(S, d.salita && d.t < 6 ? d.salita.clone().lerp(d.pos, ss(0, 6, d.t)) : d.pos, d.Q);
      if (d.t > 3 && F.ondate === 0) ondata(d.dir[0], 5, "pasdaran", false);
      if (d.t > 22 && F.ondate === 1) ondata(d.dir[1], 4, "nomadi", false);
      if (d.t > 40 && F.ondate === 2) { ondata(d.dir[2], 5, "pasdaran", true); messaggio("ATTENZIONE · pick-up con mitragliatrice pesante da sud", 3.5, "warn"); }
      if (d.t > 58 && F.ondate === 3) ondata(d.dir[0] + 40, 4, "nomadi", false);
      aggiornaPJ(dt, d.t);
    } else if (F.manuale && F.tieni) tieniElicottero(S, F.tieni.pos, F.tieni.Q);
    aggiornaArmi(dt); aggiornaNemici(dt); aggiornaSandy(dt);
    if (F.mira) F.mira.style.display = F.manuale ? "block" : "none";
    if ((F.uiT = (F.uiT || 0) - dt) <= 0) { F.uiT = 0.5; aggiornaPulsanti(); }
    // camera del mitragliere
    if (F.manuale) { S.cineCam = (d2, cam) => { const lato = F.manuale; if (!lato) { S.cineCam = null; return; } const o = puntoArma(lato).add(V3(0, 0.45, 0)), dir = direzioneArma(lato, F.aim.yaw, F.aim.pitch); cam.position.copy(o).addScaledVector(dir, -0.6); cam.up.set(0, 1, 0); cam.lookAt(o.clone().addScaledVector(dir, 50)); cam.fov = 55; cam.updateProjectionMatrix();
        const vel = 60; if (TASTI.arrowleft || TASTI.a) F.aim.yaw -= vel * d2; if (TASTI.arrowright || TASTI.d) F.aim.yaw += vel * d2; if (TASTI.arrowup || TASTI.w) F.aim.pitch = Math.min(12, F.aim.pitch + vel * 0.6 * d2); if (TASTI.arrowdown || TASTI.s) F.aim.pitch = Math.max(-60, F.aim.pitch - vel * 0.6 * d2); }; F.camMitra = true; }
    else if (F.camMitra) { F.camMitra = false; if (S.cineCam && !C) S.cineCam = null; }
  }
  const TASTIQE = {};
  window.addEventListener("keydown", e => { const k = e.key.toLowerCase(); if (k === "q" || k === "e") TASTIQE[k] = true; });
  window.addEventListener("keyup", e => { const k = e.key.toLowerCase(); if (k === "q" || k === "e") TASTIQE[k] = false; });

  /* ======================= filmato: imbarco sotto il fuoco e decollo ======================= */
  function filmatoImbarco(S, fine) {
    const F = W.F, P = S.pl; if (!F) { fine && fine(); return; }
    F.manuale = null; F.tieni = null; S.cineCam = null; const libPrima = F.libere; F.libere = true;
    const H0 = P.pos.clone(), Q0 = P.Q.clone(), fw = V3(0, 0, 1).applyQuaternion(Q0).setY(0).normalize(), dx = V3(-fw.z, 0, fw.x);   // dx: destra dell elicottero (prua x su)
    const gh = (P.A && P.A.gearHeight) || 1.85, Hg = V3(H0.x, suolo(H0.x, H0.z) + gh, H0.z);
    const porta = Hg.clone().addScaledVector(dx, 2.2); porta.y = suolo(porta.x, porta.z);
    const parti = F.pj.map(p => p.obj.position.clone()), wsoDa = W.wso.position.clone();
    let sandyFatto = false; const hdg = Math.atan2(fw.x, -fw.z);
    cinema(17, (t, dt, cam) => {
      // team e WSO verso il portellone, poi a bordo
      F.pj.forEach((p, i) => { const k = ss(0, i >= 2 ? 5.5 : 4.5, t), pos = parti[i].clone().lerp(porta, k); pos.y = suolo(pos.x, pos.z); p.obj.position.copy(pos); p.obj.visible = k < 0.98; p.obj.rotation.y = Math.atan2(porta.x - pos.x, porta.z - pos.z); posa(p.obj, i >= 2 && t < 2.5 ? "ginocchio" : "corsa", t * 1.7); p.lampo.visible = i >= 2 && t < 2.5 && Math.random() < 0.3; });
      { const k = ss(0, 4.2, t), pos = wsoDa.clone().lerp(porta, k); pos.y = suolo(pos.x, pos.z); W.wso.position.copy(pos); W.wso.visible = k < 0.98; posa(W.wso, "sostenuto", t * 1.2); }
      // elicottero: a terra fino a 5,6 s, poi stacco, cabrata e uscita lungo la valle
      let H = H0.clone().lerp(Hg, ss(0, 2.2, t)), pitch = 0;
      if (t > 5.6) { const u = t - 5.6; H.y += Math.min(u, 2.5) * 4 + Math.max(0, u - 2.5) * 6; H.addScaledVector(fw, Math.max(0, u - 1.8) ** 2 * 3.2); pitch = -ss(6.8, 9, t) * 12 * D2R; }
      P.pos.copy(H); P.Q.copy(VOLO._acc.assetto(hdg, pitch, 0)); if (P.obj) { P.obj.visible = true; P.obj.position.copy(H); P.obj.quaternion.copy(P.Q); const r = P.obj.userData && P.obj.userData.uh60Rotors; if (r) { if (r.main) r.main.rotation[r.main.userData.centurionRotorAxis || "z"] += dt * 27; if (r.tail) r.tail.rotation[r.tail.userData.centurionRotorAxis || "y"] += dt * 135; } }
      // i mitraglieri continuano il fuoco di soppressione; il nemico risponde; SANDY copre l'uscita
      W.t += dt; aggiornaArmi(dt); aggiornaNemici(dt); aggiornaSandy(dt);
      if (!sandyFatto && t > 5) { sandyFatto = true; F.sandyPronto = 0; F.sandyResidui = Math.max(1, F.sandyResidui); chiamaSandy(); }
      const hAGL = H.y - suolo(H.x, H.z); if (hAGL < 25 && Math.random() < 0.7) { const a = rnd(0, PI * 2), rr = rnd(4, 9), p = V3(H.x + Math.cos(a) * rr, 0, H.z + Math.sin(a) * rr); p.y = suolo(p.x, p.z) + 0.4; W.fumo.emetti({ pos: p, vel: V3(Math.cos(a) * 12, rnd(0.3, 1.5), Math.sin(a) * 12), vita: rnd(0.9, 1.4), s0: 1.2, s1: 4.5, a0: 0.12, col: 0x6e6658, drag: 1.2 }); }
      // inquadrature e didascalie
      etichetta("05 APR 2026 · 03:12 · DIFESA DELLA LZ");
      if (t < 5.6) { didascalia(t < 2.5 ? "Tutti a bordo!" : "DUDE 44 Bravo è sull'elicottero", t < 2.5 ? "Il perimetro rientra per ultimo, coperto dai mitraglieri di porta" : "Traccianti verdi: il fuoco nemico; rossi: il nostro");
        inquadra(cam, porta.clone().addScaledVector(fw, 14).addScaledVector(dx, 9).add(V3(0, 1.6, 0)), porta.clone().addScaledVector(fw, -6).add(V3(0, 1.2, 0)), 52, t < 0.05 ? 0 : 1.5, dt); dissolvenza(Math.max(0, 1 - t * 2)); }
      else if (t < 11) { didascalia(t < 8 ? "Stacco sotto il fuoco" : "SANDY 1 copre l'uscita", t < 8 ? "Collettivo su: a 2.200 m la potenza è al limite" : "L'A-10 passa con il cannone sul gruppo più vicino");
        inquadra(cam, Hg.clone().addScaledVector(dx, -45).addScaledVector(fw, 30).add(V3(0, 12, 0)), H.clone().add(V3(0, 2, 0)), 46, t < 5.65 ? 0 : 2, dt); }
      else { didascalia("JOLLY 11: «DUDE 44 Bravo a bordo, usciamo»", "Bassi nella valle verso ovest");
        inquadra(cam, H.clone().addScaledVector(fw, -55).addScaledVector(dx, 18).add(V3(0, 10, 0)), H.clone().addScaledVector(fw, 30), 50, t < 11.05 ? 0 : 2, dt); dissolvenza(ss(16, 17, t)); }
    }, () => { F.libere = libPrima; F.pj.forEach(p => { p.obj.visible = false; }); W.wso.visible = false; W.recuperato = true; F.difesa = null;
      P.rotorSim = null; P.vel.copy(fw).multiplyScalar(22); P.vel.y = 2; fine && fine(); });
  }

  /* ======================= cinema: inquadrature, didascalie, barre ======================= */
  let C = null;
  function stile() {
    if (document.getElementById("zg-stile")) return;
    const st = document.createElement("style"); st.id = "zg-stile";
    st.textContent = `#volo.zg-cine > :not(.zg-tieni){visibility:hidden!important}
#volo.zg-cine .zg-tieni{visibility:visible!important}
#zg-cine{position:absolute;inset:0;pointer-events:none;z-index:60;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
#zg-cine .barra{position:absolute;left:0;right:0;height:9vh;background:#000}
#zg-cine .vign{position:absolute;inset:0;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 55%,rgba(0,0,0,.5) 100%)}
#zg-cine .did{position:absolute;left:6vw;bottom:12vh;max-width:72vw;color:#f3f1ea;text-shadow:0 2px 6px #000;transition:opacity .6s}
#zg-cine .did b{display:block;font-size:clamp(15px,2.2vw,26px);letter-spacing:.06em;text-transform:uppercase}
#zg-cine .did span{font-size:clamp(12px,1.5vw,18px);opacity:.9}
#zg-cine .tag{position:absolute;right:6vw;top:calc(9vh + 14px);color:#ffd27a;font:700 clamp(11px,1.3vw,15px) Consolas,monospace;letter-spacing:.08em;text-shadow:0 1px 4px #000}
#zg-cine .fade{position:absolute;inset:0;background:#000;opacity:0}
#zg-cine .lampo{position:absolute;inset:0;background:#fff7e0;opacity:0}
#zg-cine .salta{position:absolute;right:16px;bottom:calc(9vh + 12px);pointer-events:auto;background:rgba(0,0,0,.55);color:#fff;border:1px solid rgba(255,255,255,.4);border-radius:18px;padding:8px 14px;font-size:14px;cursor:pointer}
#zg-fob{position:fixed;inset:0;z-index:100050;background:#000;display:none}#zg-fob canvas{width:100%;height:100%;display:block}`;
    document.head.appendChild(st);
  }
  const NVG_FILTRO = "grayscale(1) brightness(1.2) contrast(1.3) sepia(1) hue-rotate(58deg) saturate(3.2)";
  function cinema(durata, scena, fine) {
    const S = VOLO.stato, it = I(), ov = it.overlay; if (!S || !ov || !it.renderer) { fine && fine(); return; }
    stile(); finisci(true);
    C = { S, t: 0, durata, scena, fine, nvg: false };
    S.pausa = true; S.cineHud = false; C.near = it.camera.near; it.camera.near = 0.2; C.espPrima = it.renderer.toneMappingExposure; C.esp = 1;   // il visore del volo alza l'esposizione: il filmato parte da quella base
    it.renderer.domElement.classList.add("zg-tieni"); ov.classList.add("zg-cine");
    const ui = document.createElement("div"); ui.id = "zg-cine"; ui.className = "zg-tieni";
    ui.innerHTML = `<div class="vign"></div><div class="barra" style="top:0"></div><div class="barra" style="bottom:0"></div><div class="tag"></div><div class="did"><b></b><span></span></div><div class="lampo"></div><div class="fade"></div><button class="salta" type="button">Salta ›</button>`;
    ov.appendChild(ui); C.ui = ui; ui.querySelector(".salta").onclick = () => { C.t = C.durata; };
    C.luci = [new THREE.HemisphereLight(0x5d6f98, 0x1a1510, 0.22), new THREE.DirectionalLight(0xa8b8e8, 0.42), new THREE.PointLight(0xc8d4ff, 1.6, 320, 1.4)]; C.luci[1].position.set(-0.5, 0.8, 0.35).multiplyScalar(100000); C.fill = C.luci[2]; C.luci.forEach(l => it.scene.add(l));
    visore(false);
    S.cineCam = (dtR, cam) => {
      if (!C) return; const dt = Math.min(0.05, dtR); C.t += dt;
      try { C.scena(C.t, dt, cam); } catch (e) { console.warn("ZAGROS filmato", e); C.t = C.durata; }
      if (C && C.fill) C.fill.position.copy(cam.position);
      cam.updateProjectionMatrix();
      if (W) { W.fumo.aggiorna(dt); W.fuoco.aggiorna(dt); W.traccianti.aggiorna(dt); }
      if (C.t >= C.durata) finisci();
    };
  }
  function visore(on) { if (!C) return; C.nvg = on; const r = I().renderer; if (!r) return; r.domElement.style.filter = on ? NVG_FILTRO : "contrast(1.08) saturate(1.05)"; r.toneMappingExposure = on ? 1.5 : C.esp * 1.15; if (C.fill) C.fill.intensity = on ? 0.18 : 1.6; }
  function didascalia(titolo, testo) { if (!C || !C.ui) return; const d = C.ui.querySelector(".did"); d.querySelector("b").textContent = titolo || ""; d.querySelector("span").textContent = testo || ""; d.style.opacity = titolo || testo ? 1 : 0; }
  function etichetta(t) { if (C && C.ui) C.ui.querySelector(".tag").textContent = t || ""; }
  function dissolvenza(v) { if (C && C.ui) C.ui.querySelector(".fade").style.opacity = v; }
  function lampo(v) { if (C && C.ui) C.ui.querySelector(".lampo").style.opacity = v; }
  function finisci(silenzioso) {
    if (!C) return; const c = C, S = c.S, it = I(); C = null;
    S.cineCam = null; S.cineHud = true; S.pausa = false; if (it.camera && c.near) it.camera.near = c.near; (c.luci || []).forEach(l => { if (it.scene) it.scene.remove(l); });
    if (it.overlay) it.overlay.classList.remove("zg-cine"); if (c.ui) c.ui.remove(); if (it.renderer) { it.renderer.domElement.style.filter = ""; if (c.espPrima != null) it.renderer.toneMappingExposure = c.espPrima; }
    if (!silenzioso && c.fine) try { c.fine(); } catch (e) { console.warn(e); }
  }
  function inquadra(cam, pos, guarda, fov, morbido, dt) {
    if (morbido && C.camPos) { const k = 1 - Math.exp(-dt * morbido); C.camPos.lerp(pos, k); C.camGuarda.lerp(guarda, k); } else { C.camPos = pos.clone(); C.camGuarda = guarda.clone(); }
    const g = suolo(C.camPos.x, C.camPos.z) + 1.4; if (C.camPos.y < g) C.camPos.y = g;
    for (let k = 0; k < 12; k++) { let ok = true; for (let i = 1; i < 10; i++) { const u = i / 10, x = mix(C.camPos.x, C.camGuarda.x, u), z = mix(C.camPos.z, C.camGuarda.z, u), y = mix(C.camPos.y, C.camGuarda.y, u); if (y < suolo(x, z) + 0.6) { ok = false; break; } } if (ok) break; C.camPos.y += 3; }
    cam.position.copy(C.camPos); cam.up.set(0, 1, 0); cam.lookAt(C.camGuarda); cam.fov = fov || 50;
  }
  // insegna statunitense a bassa visibilità (stella e barre grigie) al posto della coccarda del modello procedurale generico
  let INSEGNA_USA = null;
  function insegnaUSA() {
    if (INSEGNA_USA) return INSEGNA_USA; const c = document.createElement("canvas"); c.width = c.height = 128; const g = c.getContext("2d");
    g.fillStyle = "#4a4f55"; g.fillRect(4, 52, 120, 26); g.beginPath(); g.arc(64, 64, 34, 0, Math.PI * 2); g.fill();
    g.fillStyle = "#7d838a"; g.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 12 : 30; g.lineTo(64 + Math.cos(a) * r, 66 + Math.sin(a) * r); } g.closePath(); g.fill();
    g.fillRect(10, 58, 34, 12); g.fillRect(84, 58, 34, 12);
    INSEGNA_USA = new THREE.CanvasTexture(c); return INSEGNA_USA;
  }
  const insegnaIta = mt => { const im = mt && mt.map && mt.map.image; return !!(im && im.width === 128 && im.height === 128 && im.getContext); };
  const marcaUSA = m => { if (m) m.traverse(o => { if (!o.material) return; const nuovo = mt => { if (!insegnaIta(mt)) return mt; const c = mt.clone(); c.map = insegnaUSA(); c.needsUpdate = true; return c; }; o.material = Array.isArray(o.material) ? o.material.map(nuovo) : nuovo(o.material); }); return m; };   // materiale clonato: gli altri aerei non cambiano
  const nuovoF15 = () => typeof VISTA3D === "undefined" ? Promise.resolve(null) : VISTA3D.modelloPromise("f15", undefined, { tipoId: "F15", numero: "44" }).then(marcaUSA).catch(() => null);

  /* ======================= filmato 1: DUDE 44 abbattuto ======================= */
  function filmatoAbbattimento(S, fine) {
    if (!W) { fine && fine(); return; }
    const attesa = new Promise(ok => { const t0 = performance.now(); const prova = () => { if (terrenoPronto() || performance.now() - t0 > 10000) ok(); else setTimeout(prova, 300); }; prova(); });
    Promise.all([nuovoF15(), attesa]).then(([mod]) => { if (!W) return; riallinea();
      { const L0 = LUOGHI; piazzaElicottero(S, L0.partenza, Math.atan2(L0.ip.x - L0.partenza.x, -(L0.ip.z - L0.partenza.z)) / D2R, 120, 30); }
      const L = LUOGHI, sc = W.sc, gR = suolo(L.relitto.x, L.relitto.z), Rp = V3(L.relitto.x, gR, L.relitto.z);
      const jet = new THREE.Group(); sc.add(jet); W.oggetti.push(jet); jet.add(mod || VISTA3D.jetFallback(0x5a6066));
      let tettoGLB = null; jet.traverse(o => { if (o.isMesh && /canopy/i.test(o.name)) tettoGLB = o; });
      jet.updateMatrixWorld(true); const bbJ = new THREE.Box3().setFromObject(jet); [-0.65, 0.65].forEach(x => { const s = luceSprite(0xff9a50, 2.6, 0.85); s.position.set(x, (bbJ.min.y + bbJ.max.y) / 2 - 0.2, bbJ.min.z + 0.2); jet.add(s); });
      // rotta da sud-est sopra le creste, colpito al motore destro, cabrata, doppia eiezione, impatto sul pianoro
      const hdg = 320 * D2R, f = V3(Math.sin(hdg), 0, -Math.cos(hdg)), r = V3(Math.cos(hdg), 0, Math.sin(hdg));
      const K = [[0, 3200, 1400, 0], [2.5, 2550, 1380, 60], [5.5, 1650, 1600, 170], [7.0, 1250, 1640, 210], [9.8, 520, 850, 120], [11.5, 0, 0, 0]];
      const punti = K.map(([t, d, agl, lat], i) => { const p = Rp.clone().addScaledVector(f, -d).addScaledVector(r, lat); p.y = i === K.length - 1 ? gR : suolo(p.x, p.z) + agl; return p; });
      const curva = new THREE.CatmullRomCurve3(punti, false, "centripetal");
      const uDi = t => { t = clamp(t, 0, 11.5); for (let i = 0; i < K.length - 1; i++) if (t <= K[i + 1][0]) return (i + (t - K[i][0]) / (K[i + 1][0] - K[i][0])) / (K.length - 1); return 1; };
      const posJet = t => curva.getPoint(uDi(t)), velJet = t => posJet(Math.min(11.5, t + 0.02)).sub(posJet(Math.max(0, t - 0.02))).multiplyScalar(25);
      const rollio = t => t < 2.6 ? 0 : t < 6.3 ? ss(2.6, 6.3, t) * 32 : 32 + ss(6.3, 11.5, t) * 115;
      const orient = t => { const v = velJet(t); return VOLO._acc.assetto(Math.atan2(v.x, -v.z), Math.atan2(v.y, Math.hypot(v.x, v.z)), rollio(t) * D2R); };
      // missile dal posto della squadra di ricerca, scia luminosa, flare del caccia
      const lancio = V3(L.relitto.x + 900, 0, L.relitto.z + 1400); lancio.y = suolo(lancio.x, lancio.z) + 2;
      const tImp = 2.6, tLancio = 0.5;
      const missile = new THREE.Group(); missile.add(luceSprite(0xfff0c0, 7, 1)); sc.add(missile); W.oggetti.push(missile);
      const seg = [seggiolino(), seggiolino()], pil = [vestiPilota(persona({ tuta: 0x5d6447, giubbotto: 0x3b4230, casco: 0x8b8d84 })), vestiPilota(persona({ tuta: 0x5d6447, giubbotto: 0x3b4230, casco: 0x8b8d84 }))], para = [paracadute(0xc8b48a), paracadute(0xa6987a)];
      [...seg, ...pil, ...para].forEach(o => { o.visible = false; sc.add(o); W.oggetti.push(o); });
      const te = [6.3, 6.65], E = [{}, {}];
      const vento = V3(3.0, 0, -1.2), discesa = [V3(-1, 0, 0.6).normalize(), V3(-0.4, 0, -1).normalize()];   // il WSO deriva verso la cresta
      let impattato = false, colpito = false, mt = null;
      const did = [
        [0, "3 aprile 2026 · Monti Zagros", "F-15E Strike Eagle «DUDE 44»: pilota e WSO (ufficiale sistemi d'arma)"],
        [2.4, "Missile spalleggiabile", "Un MANPADS da una squadra a terra; i flare non bastano"],
        [4.4, "Colpito", "Fuoco al motore destro: il pilota cabra per guadagnare quota"],
        [6.2, "Doppia eiezione", "Prima il WSO dal posto posteriore, poi il pilota"],
        [10.6, "Impatto", "Il relitto brucia sul pianoro: tutta la zona sa dove cercare"],
        [13.6, "Due paracadute, due destini", "Il vento li separa: uno scende in valle, l'altro verso la cresta"],
        [20.5, "Il pilota", "Recuperato dai soccorritori circa sette ore dopo l'abbattimento"],
        [24.0, "Il WSO", "Ferito e stordito, sale una cresta di circa 7.000 ft e si nasconde in una fenditura"],
        [28.0, "Radiofaro a brevi impulsi", "Lo cercano anche forze ostili e nomadi armati: trasmette pochissimo"],
        [31.5, "5 aprile · 02:40", "JOLLY 11 (HH-60) entra nella valle con il team di Pararescue"]
      ];
      cinema(35, (t, dt, cam) => {
        const dd = [...did].reverse().find(x => t >= x[0]); if (dd) didascalia(dd[1], dd[2]); etichetta(t < 13.5 ? "03 APR 2026 · ZAGROS" : t < 31 ? "03–05 APR 2026" : "05 APR 2026 · 02:40");
        dissolvenza(t < 0.8 ? 1 - t / 0.8 : t > 34.2 ? (t - 34.2) / 0.8 : 0);
        const tj = Math.min(t, 11.5), P = posJet(tj); jet.position.copy(P); jet.quaternion.copy(orient(tj)); jet.visible = !impattato;
        if (tettoGLB) tettoGLB.visible = t < te[0];
        // flare e missile
        if (t > 1.6 && t < 3.4 && Math.random() < 0.5) { const q = P.clone(); W.fuoco.emetti({ pos: q, vel: velJet(tj).multiplyScalar(0.3).add(V3(rnd(-20, 20), rnd(-30, -10), rnd(-20, 20))), vita: rnd(1.6, 2.6), s0: 5, s1: 2, a0: 1, col: 0xfff6d8, col1: 0xffa040, drag: 0.6, g: 6 }); }
        if (t >= tLancio && t < tImp) { const k = ss(tLancio, tImp, t), b = lancio.clone().lerp(posJet(tImp), k * k); b.y += Math.sin(k * PI) * 120; missile.position.copy(b); missile.visible = true;
          if (mt) { const n = Math.max(1, Math.round(mt.distanceTo(b) / 6)); for (let i = 1; i <= n; i++) W.fumo.emetti({ pos: mt.clone().lerp(b, i / n), vel: V3(rnd(-0.5, 0.5), rnd(0, 1), rnd(-0.5, 0.5)), vita: rnd(3, 5), s0: 2.5, s1: 9, a0: 0.45, col: 0xd8d4cc, col1: 0x8a8680, drag: 0.4 }); } mt = b.clone(); }
        else missile.visible = false;
        if (!colpito && t >= tImp) { colpito = true; lampo(0.65); for (let i = 0; i < 50; i++) W.fuoco.emetti({ pos: P.clone(), vel: V3(rnd(-30, 30), rnd(-30, 30), rnd(-30, 30)), vita: rnd(0.3, 0.8), s0: rnd(8, 16), s1: 3, a0: 1, col: 0xfff2c0, col1: 0xff5a10, drag: 1.6 }); }
        if (colpito) { lampo(Math.max(0, 0.65 - (t - tImp) * 1.6)); if (!impattato && Math.random() < 0.9) { W.fuoco.emetti({ pos: P.clone().add(V3(rnd(-1, 1), rnd(-1, 1), rnd(-1, 1))), vel: V3(rnd(-3, 3), rnd(-2, 3), rnd(-3, 3)), vita: rnd(0.4, 0.8), s0: rnd(4, 7), s1: 2, a0: 1, col: 0xffd080, col1: 0xff3a08, drag: 1 }); W.fumo.emetti({ pos: P.clone(), vel: V3(rnd(-2, 2), rnd(0, 3), rnd(-2, 2)), vita: rnd(5, 8), s0: 4, s1: 18, a0: 0.5, col: 0x1e1d1c, col1: 0x45423f, drag: 0.3 }); } }
        // eiezioni: seggiolino con razzo, separazione, paracadute
        for (let i = 0; i < 2; i++) {
          const e = E[i], t0 = te[i];
          if (t < t0) { seg[i].visible = pil[i].visible = para[i].visible = false; continue; }
          if (!e.p) { const q = posJet(t0); e.p = q.clone().add(V3(0, 2.5, 0)); e.v = velJet(t0).multiplyScalar(0.55).add(V3(0, 42, 0)).addScaledVector(discesa[i], 12); }
          const u = t - t0;
          if (u < 1.2) { e.v.y -= 9.81 * dt; e.v.multiplyScalar(Math.exp(-0.6 * dt)); e.p.addScaledVector(e.v, dt); seg[i].visible = true; seg[i].position.copy(e.p); seg[i].rotation.set(u * 2, 0, u * 1.2); pil[i].visible = true; pil[i].position.copy(e.p); posa(pil[i], "seggiolino");
            if (u < 0.5) W.fuoco.emetti({ pos: e.p.clone().add(V3(0, -0.5, 0)), vel: V3(rnd(-2, 2), -16, rnd(-2, 2)), vita: 0.3, s0: 2.5, s1: 1, a0: 1, col: 0xfff2b0, col1: 0xff7a20, drag: 2 }); }
          else { seg[i].visible = u < 3.5; if (seg[i].visible) { seg[i].position.y -= 30 * dt; }
            if (!e.gonfio) { e.gonfio = t; e.dep = e.p.clone(); }
            const k = t - e.gonfio, h = Math.max(0, e.dep.y - suolo(e.dep.x, e.dep.z) - 2), scende = Math.min(h, k * 6.8);
            const pos = e.dep.clone().addScaledVector(vento, k).addScaledVector(discesa[i], k * 7); pos.y = e.dep.y - scende;
            pil[i].visible = true; pil[i].position.copy(pos); posa(pil[i], "appeso"); para[i].visible = true; para[i].position.copy(pos); para[i].scale.setScalar(ss(0, 0.9, k)); para[i].rotation.set(0.08 * Math.sin(t * 1.7 + i), t * 0.15, 0.06 * Math.cos(t * 1.3 + i)); e.ora = pos; }
        }
        if (!impattato && t >= 11.5) { impattato = true; lampo(0.9); const q = Rp.clone().add(V3(0, 3, 0));
          for (let i = 0; i < 90; i++) W.fuoco.emetti({ pos: q.clone().add(V3(rnd(-8, 8), rnd(0, 6), rnd(-8, 8))), vel: V3(rnd(-40, 40), rnd(10, 60), rnd(-40, 40)), vita: rnd(0.6, 1.6), s0: rnd(10, 22), s1: 4, a0: 1, col: 0xfff0b0, col1: 0xff4010, drag: 1.0 });
          for (let i = 0; i < 40; i++) W.fumo.emetti({ pos: q.clone().add(V3(rnd(-10, 10), rnd(2, 10), rnd(-10, 10))), vel: V3(rnd(-10, 10), rnd(8, 22), rnd(-10, 10)), vita: rnd(10, 15), s0: 12, s1: 50, a0: 0.55, col: 0x2a2622, col1: 0x5a5550, drag: 0.35, su: 0.3 }); }
        if (impattato) lampo(Math.max(0, 0.9 - (t - 11.5) * 1.4));
        // inquadrature
        const fJ = velJet(tj).normalize(), rJ = V3(-fJ.z, 0, fJ.x).normalize();
        if (t < 2.4) inquadra(cam, P.clone().addScaledVector(fJ, -34).addScaledVector(rJ, 14).add(V3(0, 6, 0)), P.clone().addScaledVector(fJ, 25), 46, 0, dt);
        else if (t < 4.4) { const mm = missile.visible ? missile.position : P; inquadra(cam, P.clone().addScaledVector(fJ, -40).addScaledVector(rJ, -45).add(V3(0, 16, 0)), P.clone().lerp(mm, 0.35), 56, 0, dt); }
        else if (t < 6.2) inquadra(cam, P.clone().addScaledVector(fJ, -36).addScaledVector(rJ, 24).add(V3(0, 5, 0)), P, 46, 0, dt);
        else if (t < 10.6) { if (!C.ass) C.ass = { f: fJ.clone(), r: rJ.clone() }; const m = E[0].ora || E[0].p || P; inquadra(cam, m.clone().addScaledVector(C.ass.r, t < 7.4 ? 18 : 24).addScaledVector(C.ass.f, -9).add(V3(0, 4, 0)), m.clone().add(V3(0, t < 7.4 ? 0.5 : 4, 0)), 52, 0, dt); }
        else if (t < 13.6) inquadra(cam, Rp.clone().addScaledVector(f, -190).addScaledVector(r, 110).add(V3(0, 45, 0)), Rp.clone().add(V3(0, 14, 0)), 40, 2, dt);
        else if (t < 20.5) { const b2 = E[1].ora || Rp, a2 = E[0].ora || Rp; inquadra(cam, b2.clone().add(V3(26, 6, 26)), b2.clone().add(V3(0, 4, 0)), 44, 1.5, dt); }
        else if (t < 24.0) { const a2 = E[0].ora || Rp; inquadra(cam, a2.clone().add(V3(-22, 4, 20)), a2.clone().add(V3(0, 4, 0)), 42, 2, dt); }
        else if (t < 31.5) { if (!C.cresta) { C.cresta = true; visore(true); [...pil, ...para, ...seg].forEach(o => o.visible = false); }
          W.wso.userData.j.strobo.visible = (t % 1) < 0.12 && t > 28; const q = W.wso.position; W.fend.updateMatrixWorld(true); const oc = W.fend.localToWorld(V3(1.2 - (t - 24) * 0.12, 1.1, 4.6));
          inquadra(cam, oc, q.clone().add(V3(0, 0.6, 0)), 44, t < 24.05 ? 0 : 1.2, dt); }
        else { visore(false); const p2 = S.pl.pos, fh = V3(0, 0, 1).applyQuaternion(S.pl.Q).setY(0).normalize(); if (S.pl.obj) S.pl.obj.visible = true; inquadra(cam, p2.clone().addScaledVector(fh, -38).add(V3(8, 9, 0)), p2.clone().addScaledVector(fh, 20), 46, t < 31.6 ? 0 : 2, dt); }
      }, () => { [...seg, ...pil, ...para, jet, missile].forEach(o => { sc.remove(o); }); W.wso.userData.j.strobo.visible = false; const L0 = LUOGHI; piazzaElicottero(S, L0.partenza, Math.atan2(L0.ip.x - L0.partenza.x, -(L0.ip.z - L0.partenza.z)) / D2R, 120, 30); fine && fine(); });
    });
  }

  /* ======================= filmato 2: il recupero del WSO, di notte ======================= */
  function filmatoRecupero(S, fine) {
    if (!W) { fine && fine(); return; }
    const sc = W.sc, P = S.pl, L = LUOGHI;
    const lz = V3(L.lz.x, suolo(L.lz.x, L.lz.z), L.lz.z), ws = W.wso.position.clone();
    const vW = ws.clone().sub(lz).setY(0).normalize(), hdgU = Math.atan2(vW.z, vW.x);
    const P0 = P.pos.clone(), Q0 = P.Q.clone(), Qa = VOLO._acc.assetto(hdgU, 0, 0), gh = (P.A && P.A.gearHeight) || 1.85, posaH = lz.clone().add(V3(0, gh, 0));
    const fw = V3(Math.sin(hdgU), 0, -Math.cos(hdgU)), dx = V3(Math.cos(hdgU), 0, Math.sin(hdgU));
    const porta = posaH.clone().addScaledVector(dx, 2.2).add(V3(0, -gh + 0.1, 0));
    const pj = { camo: true, giubbotto: 0x3f3d30, casco: 0x4d4b3c, attrezzi: 0x22231f, fucile: true, zaino: 0x4a4637, nvg: true, guanti: true };
    const team = [persona(Object.assign({ nome: "PJ 1 (capo)" }, pj)), persona(Object.assign({ nome: "PJ 2" }, pj, { borsa: true, fucile: false })), persona(Object.assign({ nome: "PJ 3" }, pj)), persona(Object.assign({ nome: "PJ 4" }, pj))];
    team.forEach(p => { p.visible = false; sc.add(p); W.oggetti.push(p); });
    const perimetro = [60, 160, 250, 330].map(a => { const q = hdgU + a * D2R; return lz.clone().add(V3(Math.sin(q) * 18, 0, -Math.cos(q) * 18)); });
    const lat = V3(-vW.z, 0, vW.x), presso = ws.clone().addScaledVector(vW, -1.4);
    const terra = (a, b, k) => { const p = a.clone().lerp(b, k); p.y = suolo(p.x, p.z); return p; };
    const metti = (p, pos, verso) => { p.visible = true; p.position.copy(pos); if (verso) p.rotation.set(0, Math.atan2(verso.x - pos.x, verso.z - pos.z), 0); };
    const rotori = () => { const u = P.obj && P.obj.userData; return u && u.uh60Rotors; };
    const ruota = dt => { const r = rotori(); if (!r) return; const a = r.main && r.main.userData.centurionRotorAxis || "z", b = r.tail && r.tail.userData.centurionRotorAxis || "y"; if (r.main) r.main.rotation[a] += dt * 27; if (r.tail) r.tail.rotation[b] += dt * 135; };
    const sandy = a10(); sandy.visible = false; sc.add(sandy); W.oggetti.push(sandy);
    const camPrima = S.cam; S.cam = "chase"; try { if (P.obj && window.CENTURION_COCKPIT) CENTURION_COCKPIT.setView(P.obj, S.cfg.aereo, false); } catch (e) {}
    W.chem.forEach(l => l.visible = true);
    cinema(33, (t, dt, cam) => {
      const verso = porta.clone().addScaledVector(vW, Math.max(0, 9 - Math.max(0, t - 17) * 1.6));
      let H;
      if (t < 3) { const k = ss(0, 3, t); H = P0.clone().lerp(posaH, k); P.Q.copy(Q0).slerp(Qa, k); }
      else if (t < 26.5) { H = posaH.clone(); P.Q.copy(Qa); }
      else { const k = t - 26.5; H = posaH.clone().add(V3(0, Math.min(k, 3) * 3.5 + Math.max(0, k - 3) * 6, 0)).addScaledVector(fw, Math.max(0, k - 2) ** 2 * 3.4); P.Q.copy(VOLO._acc.assetto(hdgU, -ss(27, 29.5, t) * 11 * D2R, 0)); }
      P.pos.copy(H); if (P.obj) { P.obj.visible = true; P.obj.position.copy(H); P.obj.quaternion.copy(P.Q); } ruota(dt);
      const hAGL = H.y - suolo(H.x, H.z);
      if (hAGL < 30 && Math.random() < 0.6) { const a = rnd(0, PI * 2), rr = rnd(4, 9), p = V3(H.x + Math.cos(a) * rr, 0, H.z + Math.sin(a) * rr); p.y = suolo(p.x, p.z) + 0.4; const sp = rnd(10, 16) * (1 - hAGL / 35);
        W.fumo.emetti({ pos: p, vel: V3(Math.cos(a) * sp, rnd(0.3, 1.6), Math.sin(a) * sp), vita: rnd(0.9, 1.5), s0: 1.2, s1: 4.5, a0: 0.1, col: 0x6e6658, drag: 1.2 }); }
      team.forEach((p, i) => {
        const esce = 3.2 + i * 0.45; if (t < esce) { p.visible = false; return; }
        if (i >= 2) { const dest = perimetro[i === 2 ? 0 : 3], kc = ss(esce, esce + 3, t);
          if (t < 23 + i * 0.4) { const pos = terra(porta, dest, kc); metti(p, pos, kc < 1 ? dest : pos.clone().add(dest.clone().sub(lz))); posa(p, kc < 1 ? "corsa" : "ginocchio", t * 1.6); }
          else { const kr = ss(23 + i * 0.4, 25.6 + i * 0.3, t); const pos = terra(dest, porta, kr); metti(p, pos, porta); posa(p, "corsa", t * 1.6); p.visible = kr < 0.98; } }
        else { const lato = i ? 0.9 : -0.9, vicino = presso.clone().addScaledVector(lat, lato);
          if (t < 9) { const d0 = porta.distanceTo(vicino), d = Math.min(d0, (t - esce) * 3.4); const a = terra(porta, vicino, d / d0); metti(p, a, vicino); posa(p, "corsa", t * 1.7); }
          else if (t < 17) { const a = vicino.clone(); a.y = suolo(a.x, a.z); metti(p, a, ws); posa(p, t < 9.6 ? "corsa" : (i ? "cura" : "punta"), t * 1.2); }
          else if (t < 24) { const a = verso.clone().addScaledVector(lat, lato * 0.7); a.y = suolo(a.x, a.z); metti(p, a, porta); posa(p, "cammina", t * 1.1); }
          else p.visible = t < 24.6; }
      });
      // il WSO: esce dalla fenditura, autenticazione, cure, sostenuto fino all'elicottero
      W.wso.visible = t < 24.4;
      if (t < 9.5) { posa(W.wso, t > 7 ? "saluta" : "rannicchiato", t); W.wso.userData.j.strobo.visible = (t % 1) < 0.12; }
      else if (t < 17) { W.wso.userData.j.strobo.visible = false; posa(W.wso, "seduto"); }
      else if (t < 24.4) { const a = verso.clone(); a.y = suolo(a.x, a.z); W.wso.position.copy(a); W.wso.rotation.set(0, Math.atan2(porta.x - a.x, porta.z - a.z), 0); posa(W.wso, "sostenuto", t * 1.1); }
      // SANDY 1 in orbita alta: passa sopra durante il decollo
      const ks = t - 27.5; sandy.visible = ks > -1 && ks < 3.5; if (sandy.visible) { const p = posaH.clone().addScaledVector(fw, -700 + ks * 210).addScaledVector(dx, -120); p.y = posaH.y + 180; sandy.position.copy(p); sandy.quaternion.copy(VOLO._acc.assetto(hdgU, 0.05, -0.3)); }
      // inquadrature e didascalie
      if (t < 3.5) { didascalia("JOLLY 11 sulla LZ · 2.200 m", "Aria rarefatta: poca riserva di potenza, avvicinamento lento sulle luci chimiche IR"); etichetta("05 APR 2026 · 03:05 · NVG"); visore(true); dissolvenza(Math.max(0, 1 - t * 1.6));
        inquadra(cam, lz.clone().addScaledVector(dx, -34).addScaledVector(fw, 16).add(V3(0, 2.5, 0)), H.clone().add(V3(0, 1, 0)), 46, t < 0.05 ? 0 : 2, dt); }
      else if (t < 9) { didascalia("Pararescue a terra", "Due PJ formano il perimetro; capo squadra e paramedico salgono verso lo strobo"); etichetta("NVG");
        inquadra(cam, porta.clone().addScaledVector(fw, 10).addScaledVector(vW, 3).add(V3(0, 2.4, 0)), porta.clone().addScaledVector(vW, 14).add(V3(0, 1, 0)), 50, t < 3.55 ? 0 : 2, dt); }
      else if (t < 17) { didascalia(t < 12.5 ? "Autenticazione" : "Prime cure", t < 12.5 ? "Domande della scheda personale (ISOPREP): non è una trappola, è lui" : "Commozione, ferite e ipotermia: stabilizzato in pochi minuti"); etichetta("NVG");
        visore(t < 13); W.fend.updateMatrixWorld(true); inquadra(cam, W.fend.localToWorld(V3(2.4, 1.6, 6.2)), ws.clone().add(V3(0, 0.7, 0)), 44, t < 9.05 ? 0 : 1.5, dt); }
      else if (t < 24.4) { didascalia("Verso l'elicottero", "Sostenuto da due PJ; il perimetro resta in posizione fino all'imbarco"); etichetta("NVG"); visore(true);
        inquadra(cam, porta.clone().addScaledVector(lat, 12).addScaledVector(fw, -6).add(V3(0, 3, 0)), verso.clone().add(V3(0, 1, 0)), 44, t < 17.05 ? 0 : 1.6, dt); }
      else if (t < 27) { didascalia("Superstite a bordo", "«JOLLY 11: DUDE 44 Bravo a bordo, team completo»"); etichetta("NVG");
        inquadra(cam, posaH.clone().addScaledVector(dx, -24).addScaledVector(fw, 18).add(V3(0, 7, 0)), posaH.clone().add(V3(0, 1, 0)), 46, t < 24.45 ? 0 : 2, dt); }
      else { didascalia("Uscita", "Bassi nella valle verso ovest; SANDY 1 copre dall'alto"); etichetta("05 APR 2026 · 03:14"); visore(false);
        inquadra(cam, posaH.clone().addScaledVector(fw, 80).addScaledVector(dx, -40).add(V3(0, 10, 0)), H.clone().add(V3(0, 4, 0)), 52, 2, dt); dissolvenza(ss(31.8, 33, t)); }
    }, () => { team.forEach(p => sc.remove(p)); sc.remove(sandy); W.wso.visible = false; W.recuperato = true; S.cam = camPrima === "cockpit" ? "cockpit" : "chase";
      // l'elicottero riparte da dove lo lascia il filmato
      P.rotorSim = null; P.vel.copy(fw).multiplyScalar(18); P.vel.y = 3; fine && fine(); });
  }

  /* ======================= filmato 3: la base avanzata (scena propria, immagini satellitari reali) ======================= */
  let FOB = null;
  function filmatoFOB(fine) {
    stile();
    const ov = document.createElement("div"); ov.id = "zg-fob"; ov.innerHTML = `<canvas></canvas><div id="zg-cine" style="position:absolute"><div class="vign"></div><div class="barra" style="top:0"></div><div class="barra" style="bottom:0"></div><div class="tag"></div><div class="did"><b></b><span></span></div><div class="lampo"></div><div class="fade"></div><button class="salta" type="button">Salta ›</button></div>`;
    document.body.appendChild(ov); ov.style.display = "block";
    const Sv = typeof VOLO !== "undefined" ? VOLO.stato : null; if (Sv) { Sv.pausa = true; Sv.cineHud = false; }
    const cv = ov.querySelector("canvas"), ui = ov.querySelector("#zg-cine");
    const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true }); renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1)); renderer.setSize(innerWidth, innerHeight, false);
    if (THREE.sRGBEncoding !== undefined && renderer.outputEncoding !== undefined) renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
    const camera = new THREE.PerspectiveCamera(42, innerWidth / Math.max(1, innerHeight), 1, 30000), sc = new THREE.Scene();
    // alba: cielo freddo con l'orizzonte arancio a est
    const cielo = new THREE.Mesh(new THREE.SphereGeometry(20000, 32, 16), new THREE.ShaderMaterial({ side: THREE.BackSide, depthWrite: false, uniforms: {},
      vertexShader: "varying vec3 vW; void main(){ vW = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",
      fragmentShader: "varying vec3 vW; void main(){ vec3 d = normalize(vW); float h = max(d.y, 0.0); float est = pow(max(0.0, dot(normalize(vec3(d.x,0.0,d.z)), vec3(1.0,0.0,0.0))), 3.0); vec3 c = mix(vec3(0.85,0.55,0.32)*(0.55+0.45*est), vec3(0.16,0.22,0.38), pow(h, 0.45)); gl_FragColor = vec4(c, 1.0); }" }));
    sc.add(cielo); sc.fog = new THREE.Fog(0x8a7468, 2500, 16000);
    sc.add(new THREE.HemisphereLight(0x8fa4c8, 0x4a3a2c, 0.7)); const sole = new THREE.DirectionalLight(0xffb070, 1.3); sole.position.set(1000, 160, 120); sc.add(sole);
    // terreno: piano + immagini satellitari z16 della pista agricola abbandonata (coordinate della fonte)
    const O = { lat: 32.2213, lon: 51.9014 }, C0 = 40075016.686 * Math.cos(O.lat * D2R), merc = (lat, lon) => { const lr = lat * D2R; return { u: (lon + 180) / 360, v: (1 - Math.log(Math.tan(lr) + 1 / Math.cos(lr)) / PI) / 2 }; }, m0 = merc(O.lat, O.lon);
    const base = new THREE.Mesh(new THREE.PlaneGeometry(40000, 40000), new THREE.MeshStandardMaterial({ color: 0xa08a6a, roughness: 1 })); base.rotation.x = -PI / 2; base.position.y = -0.4; sc.add(base);
    const z = 16, n = 2 ** z, tm = C0 / n, x0 = Math.floor(m0.u * n), y0 = Math.floor(m0.v * n), loader = new THREE.TextureLoader(); loader.setCrossOrigin("anonymous"); const attese = [];
    for (let X = x0 - 5; X <= x0 + 5; X++) for (let Y = y0 - 5; Y <= y0 + 5; Y++) {
      const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 }), m = new THREE.Mesh(new THREE.PlaneGeometry(tm, tm), mat); m.rotation.x = -PI / 2; m.visible = false; m.position.set(((X + 0.5) / n - m0.u) * C0, 0.02, ((Y + 0.5) / n - m0.v) * C0); sc.add(m);
      const url = typeof VISTA3D !== "undefined" && VISTA3D.tileUrl ? VISTA3D.tileUrl("sat", z, X, Y) : `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${Y}/${X}`;
      attese.push(new Promise(res => loader.load(url, t => { if (THREE.sRGBEncoding !== undefined && t.encoding !== undefined) t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; mat.map = t; mat.needsUpdate = true; m.visible = true; res(); }, undefined, () => res())));
    }
    // la pista vera (immagine satellitare): 1.220 x 60 m, orientata 110/290 gradi; gli oggetti stanno nel suo riferimento (+Z lungo la pista verso est-sud-est)
    const PG = new THREE.Group(); PG.rotation.y = 70 * D2R; sc.add(PG); PG.updateMatrixWorld(true); const L2W = (x, y, z) => PG.localToWorld(V3(x, y, z));
    const T = texture(), fumo = particelle(sc, 600, false, T.fumo), fuoco = particelle(sc, 500, true, T.luce);
    const mc = [mc130(), mc130()], rimp = [bimotore(), bimotore(), bimotore()];
    mc[0].position.set(-46, mc[0].userData.terra - 0.7, -230); mc[0].rotation.set(0.02, 0.35, 0.05); mc[1].position.set(44, mc[1].userData.terra - 0.6, -110); mc[1].rotation.set(-0.02, -0.25, -0.04); mc.forEach(m => PG.add(m));
    rimp.forEach((m, i) => { m.position.set(0, m.userData.terra, -760 - i * 160); PG.add(m); });
    const gente = []; for (let i = 0; i < 14; i++) { const p = persona({ camo: true, giubbotto: 0x3f3d30, casco: 0x4d4b3c, fucile: i % 3 !== 0, zaino: 0x4a4637 }); p.position.set(rnd(-30, 30), 0, rnd(-260, -60)); PG.add(p); gente.push({ p, a: p.position.clone() }); }
    const did = [[0, "Base avanzata · pista agricola abbandonata", "A nord di Shahreza, provincia di Isfahan: la difendono le forze speciali"], [6, "Due MC-130J bloccati", "Non possono ripartire: per circa due ore il personale resta senza un'uscita"],
      [12, "Arrivano gli aerei di rimpiazzo", "Imbarcano il WSO e circa cento operatori"], [19, "Niente resta al nemico", "I due MC-130J vengono distrutti dopo la partenza"], [24.5, "DUDE 44 Bravo è a casa", "Recuperato vivo: nessun soldato americano ucciso nell'operazione"]];
    let t = 0, salta = false, esploso = false; ui.querySelector(".salta").onclick = () => { salta = true; };
    const dur = 29;
    FOB = { attivo: true, ov, renderer, disegna: (dt) => {
      t += dt; const d = [...did].reverse().find(x => t >= x[0]); const db = ui.querySelector(".did"); db.querySelector("b").textContent = d[1]; db.querySelector("span").textContent = d[2]; ui.querySelector(".tag").textContent = t < 19 ? "05 APR 2026 · 05:40" : "05 APR 2026 · 06:30";
      ui.querySelector(".fade").style.opacity = t < 0.8 ? 1 - t / 0.8 : t > dur - 1 ? (t - dur + 1) : 0;
      mc.forEach(m => m.userData.eliche.forEach(e => e.rotation.z += dt * (t < 19 ? 2 : 0)));
      rimp.forEach((m, i) => { m.userData.eliche.forEach(e => e.rotation.z += dt * 40); const ta = 6 + i * 1.6, tp = 15.5 + i * 1.4;
        if (t < ta) m.position.z = -760 - i * 160; else if (t < tp) { const k = ss(ta, ta + 4, t); m.position.set(i % 2 ? 8 : -8, m.userData.terra, mix(-760 - i * 160, -330 - i * 60, k)); m.rotation.set(0, 0, 0); }
        else { const k = t - tp; m.position.set(i % 2 ? 8 : -8, m.userData.terra + Math.max(0, k - 3.2) ** 2 * 2.4, -330 - i * 60 + k * k * 10); m.rotation.set(-Math.min(0.2, Math.max(0, k - 3.2) * 0.07), 0, 0); } });
      gente.forEach((g, i) => { const k = ss(9 + i * 0.25, 15 + i * 0.2, t), dest = V3((i % 3) === 1 ? 8 : -8, 0, -330 - (i % 3) * 60); g.p.position.copy(g.a.clone().lerp(dest, k)); g.p.visible = k < 0.97; g.p.rotation.y = Math.atan2(dest.x - g.a.x, dest.z - g.a.z); posa(g.p, k > 0 && k < 1 ? "corsa" : "ginocchio", t * 1.6 + i); });
      if (!esploso && t >= 20.5) { esploso = true; mc.forEach(m => { const mp = m.getWorldPosition(V3()); for (let i = 0; i < 90; i++) fuoco.emetti({ pos: mp.clone().add(V3(rnd(-10, 10), rnd(0, 5), rnd(-12, 12))), vel: V3(rnd(-25, 25), rnd(8, 45), rnd(-25, 25)), vita: rnd(0.6, 1.5), s0: rnd(10, 20), s1: 4, a0: 1, col: 0xfff0b0, col1: 0xff4010, drag: 1 }); }); ui.querySelector(".lampo").style.opacity = 0.7; }
      if (esploso) { ui.querySelector(".lampo").style.opacity = Math.max(0, 0.7 - (t - 20.5) * 1.5); mc.forEach(m => { m.rotation.z += dt * 0.004; const mp = m.getWorldPosition(V3()); if (Math.random() < 0.8) { fuoco.emetti({ pos: mp.clone().add(V3(rnd(-12, 12), rnd(0, 4), rnd(-14, 14))), vel: V3(0, rnd(4, 9), 0), vita: rnd(0.5, 1.1), s0: rnd(5, 9), s1: 2, a0: 0.9, col: 0xffc060, col1: 0xff3a08, drag: 0.4 }); fumo.emetti({ pos: mp.clone().add(V3(rnd(-8, 8), 6, rnd(-8, 8))), vel: V3(rnd(-2, 2), rnd(10, 16), rnd(-2, 2)), vita: rnd(10, 14), s0: 10, s1: 45, a0: 0.5, col: 0x1e1c1a, col1: 0x56524e, drag: 0.2, su: 0.2 }); } }); }
      fumo.aggiorna(dt); fuoco.aggiorna(dt);
      // inquadrature
      const cam = camera;
      if (t < 6) { const k = t / 6; cam.position.copy(L2W(mix(-520, -360, k), mix(190, 130, k), mix(160, 60, k))); cam.lookAt(L2W(0, 0, -150)); cam.fov = 40; }
      else if (t < 12) { cam.position.copy(L2W(-95, 7, -120)); cam.lookAt(L2W(mc[0].position.x, 4, mc[0].position.z)); cam.fov = 38; }
      else if (t < 19) { cam.position.copy(L2W(70, 6, -250)); const r0 = rimp[Math.min(2, Math.floor((t - 12) / 2.5))].position; cam.lookAt(L2W(r0.x, 4, r0.z)); cam.fov = 44; }
      else if (t < 24.5) { cam.position.copy(L2W(-300, 80, 200)); cam.lookAt(L2W(0, 10, -170)); cam.fov = 34; }
      else { const r0 = rimp[0].position; cam.position.copy(L2W(-160, 45, r0.z - 260)); cam.lookAt(L2W(r0.x, r0.y, r0.z)); cam.fov = 40; }
      cam.updateProjectionMatrix(); renderer.render(sc, cam);
      if (t >= dur || salta) chiudiFOB(fine);
    } };
    Promise.race([Promise.all(attese), new Promise(r => setTimeout(r, 2500))]).then(() => { if (!FOB) return; let last = performance.now(); const ciclo = now => { if (!FOB || !FOB.attivo) return; if (!FOB.esterno) { FOB.disegna(Math.min(0.05, (now - last) / 1000)); } last = now; FOB.raf = requestAnimationFrame(ciclo); }; FOB.raf = requestAnimationFrame(ciclo); FOB.pronto = true; });
  }
  function chiudiFOB(fine) { if (!FOB) return; const f = FOB; FOB = null; f.attivo = false; cancelAnimationFrame(f.raf); try { f.renderer.dispose(); } catch (e) {} f.ov.remove(); const Sv = typeof VOLO !== "undefined" ? VOLO.stato : null; if (Sv) { Sv.pausa = false; Sv.cineHud = true; } fine && fine(); }

  function chiudi() {
    finisci(true); if (FOB) chiudiFOB(); disallinea();
    if (!W) return; const sc = W.sc;
    W.oggetti.forEach(o => sc.remove(o)); W.fumo.dispose(); W.fuoco.dispose(); W.traccianti.dispose();
    if (W.nav) W.nav.remove(); if (W.mk) W.mk.remove(); ['zg-armi', 'zg-mira'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); });
    if (W.F && W.F.camMitra && W.S) W.S.cineCam = null; W = null;
  }

  /* ======================= lezione S3: la base avanzata (pista agricola abbandonata vicino a Mahyar) ======================= */
  // Pista vera dalle immagini satellitari: centro 32.2213 N 51.9014 E, circa 1.220 x 60 m, orientata 110/290 gradi.
  // Mappa propria centrata sulla pista; tutto il resto (aerei, mezzi, persone, luci) è ricostruito in 3D sul rilievo reale.
  const FOB_C = [32.2213, 51.9014], FOB_ID = "S3", M_LON_F = 111320 * Math.cos(FOB_C[0] * D2R);
  const xzF = (lat, lon) => ({ x: (lon - FOB_C[1]) * M_LON_F, z: -(lat - FOB_C[0]) * 111320 });
  const PISTA = { c: xzF(32.2213, 51.9014), hdg: 110, L: 1220, Wd: 60 };
  const asseP = V3(Math.sin(PISTA.hdg * D2R), 0, -Math.cos(PISTA.hdg * D2R)), latP = V3(-asseP.z, 0, asseP.x);   // asse verso est-sud-est; laterale a sud-ovest
  const sulPista = (u, w) => ({ x: PISTA.c.x + asseP.x * u + latP.x * w, z: PISTA.c.z + asseP.z * u + latP.z * w });
  const LF = { lz: sulPista(-470, 70), partenza: xzF(32.140, 51.855), ip: xzF(32.205, 51.880), manpads: xzF(32.188, 51.955) };   // latP punta a sud-sud-ovest: w > 0 è il lato sud
  const R_MAN_F = 3000;
  let WF = null;
  // modelli più curati per la base: C-130J (MC-130J), bimotore da trasporto di rimpiazzo, MH-6, fuoristrada
  function lathe(profilo, seg) { const g = new THREE.LatheGeometry(profilo.map(([r, z]) => new THREE.Vector2(r, z)), seg || 20); g.rotateX(PI / 2); return g; }
  function cargoBello(o) {
    const G = new THREE.Group(), col = mStd(o.col, 0.6, 0.25), scuro = mStd(0x1c2024, 0.4, 0.4), vetro = mStd(0x0e151b, 0.15, 0.7);
    const R = o.R, L = o.L;
    // fusoliera: muso arrotondato, cilindro, coda che sale verso la deriva (profilo ruotato)
    const prof = [[0.01, L * 0.5], [R * 0.55, L * 0.485], [R * 0.85, L * 0.45], [R, L * 0.38], [R, -L * 0.18], [R * 0.85, -L * 0.3], [R * 0.45, -L * 0.45], [0.2, -L * 0.5]];
    const f = mesh(lathe(prof, 22), col); f.scale.set(1, 1.08, 1); G.add(f);
    const coda = mesh(new THREE.BoxGeometry(R * 1.3, R * 0.5, L * 0.22), col, 0, R * 0.45, -L * 0.39); coda.rotation.x = -0.28; G.add(coda);   // rampa e coda che sale
    G.add(mesh(new THREE.BoxGeometry(R * 1.2, R * 0.28, R * 0.5), vetro, 0, R * 0.62, L * 0.43));   // parabrezza
    [-1, 1].forEach(s => { const sp = mesh(new THREE.CapsuleGeometry(R * 0.32, L * 0.22, 4, 10), col, s * R * 0.95, -R * 0.55, -L * 0.02); sp.rotation.x = PI / 2; G.add(sp); });   // carenature del carrello
    // ala alta rastremata
    const ala = new THREE.Shape(); ala.moveTo(-o.ap / 2, -o.corda * 0.35); ala.lineTo(o.ap / 2, -o.corda * 0.35); ala.lineTo(o.ap / 2 - 1, o.corda * 0.25); ala.lineTo(1.2, o.corda * 0.65); ala.lineTo(-1.2, o.corda * 0.65); ala.lineTo(-o.ap / 2 + 1, o.corda * 0.25); ala.closePath();
    const ag = new THREE.ExtrudeGeometry(ala, { depth: 0.35, bevelEnabled: false }); ag.rotateX(PI / 2); const am = mesh(ag, col, 0, R * 1.02, L * 0.06); G.add(am);
    const eliche = [];
    o.motori.forEach(x => {
      const n = mesh(lathe([[0.05, 2.6], [0.55, 2.3], [0.7, 1.4], [0.65, -1.4], [0.3, -2.4]], 14), col, x, R * 0.78, L * 0.06 + o.corda * 0.35); G.add(n);
      const e = new THREE.Group(); e.position.set(x, R * 0.78, L * 0.06 + o.corda * 0.35 + 2.75);
      { const og = mesh(new THREE.ConeGeometry(0.32, 0.8, 12), scuro, 0, 0, 0.2); og.rotation.x = PI / 2; e.add(og); }
      for (let k = 0; k < o.pale; k++) { const q = new THREE.Group(); q.rotation.z = k * PI * 2 / o.pale; const pala = mesh(new THREE.BoxGeometry(0.26, o.elica, 0.05), scuro, 0, o.elica / 2, 0); pala.rotation.y = 0.35; q.add(pala); e.add(q); }
      const disco = mesh(new THREE.CircleGeometry(o.elica, 24), new THREE.MeshBasicMaterial({ color: 0x222222, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide })); e.add(disco); e.userData.disco = disco;
      G.add(e); eliche.push(e); });
    const der = new THREE.Shape(); der.moveTo(0, 0); der.lineTo(-o.corda * 1.3, 0); der.lineTo(-o.corda * 0.55, o.deriva); der.lineTo(o.corda * 0.05, o.deriva); der.closePath();
    const dg = new THREE.ExtrudeGeometry(der, { depth: 0.3, bevelEnabled: false }); dg.rotateY(-PI / 2); const dm = mesh(dg, col, 0.15, R * 0.75, -L * 0.29); G.add(dm);
    const ts = mesh(new THREE.BoxGeometry(o.ap * 0.38, 0.22, o.corda * 0.7), col, 0, R * 0.95, -L * 0.45); G.add(ts);
    [-1, 1].forEach(s => { [0.06, -0.06].forEach(dz => { const r = mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.45, 14), scuro, s * R * 0.95, -R - 0.05, -L * 0.02 + dz * L); r.rotation.z = PI / 2; G.add(r); }); });
    const rm = mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.3, 12), scuro, 0, -R - 0.2, L * 0.36); rm.rotation.z = PI / 2; G.add(rm);
    G.userData.eliche = eliche; G.userData.terra = R + 0.6; return G;
  }
  const mc130J = () => cargoBello({ L: 29.8, R: 2.15, ap: 40.4, corda: 4.2, motori: [-11.3, -5.4, 5.4, 11.3], pale: 6, elica: 2.05, deriva: 6.6, col: 0x3d4246 });
  const rimpiazzo = () => cargoBello({ L: 24.5, R: 1.5, ap: 25.8, corda: 2.9, motori: [-4.4, 4.4], pale: 6, elica: 1.95, deriva: 5.0, col: 0x8b9298 });
  function mh6() {
    const G = new THREE.Group(), col = mStd(0x24282b, 0.5, 0.3), vetro = mStd(0x101820, 0.15, 0.6);
    const b = mesh(new THREE.SphereGeometry(1.05, 16, 12), col, 0, 1.25, 0.3); b.scale.set(0.85, 0.9, 1.25); G.add(b);
    { const v = mesh(new THREE.SphereGeometry(0.78, 14, 10, 0, PI * 2, 0, PI / 2), vetro, 0, 1.3, 1.0); v.rotation.x = PI / 2.6; G.add(v); }
    const tr = mesh(new THREE.CylinderGeometry(0.12, 0.2, 4.2, 8), col, 0, 1.45, -2.4); tr.rotation.x = PI / 2; G.add(tr); G.add(mesh(new THREE.BoxGeometry(0.08, 1.0, 0.5), col, 0, 1.8, -4.4));
    [-1, 1].forEach(s => { { const sk = mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.6, 6), col, s * 0.75, 0.08, 0.2); sk.rotation.x = PI / 2; G.add(sk); } [0.8, -0.6].forEach(z => G.add(mesh(new THREE.BoxGeometry(0.06, 0.5, 0.06), col, s * 0.7, 0.33, z))); });
    const rot = new THREE.Group(); rot.position.set(0, 2.15, 0.2); for (let k = 0; k < 5; k++) { const q = new THREE.Group(); q.rotation.y = k * PI * 2 / 5; q.add(mesh(new THREE.BoxGeometry(0.2, 0.04, 4.2), col, 0, 0, 2.1)); rot.add(q); } G.add(rot); G.userData.rotore = rot;
    return G;
  }
  function fuoristrada() {
    const G = new THREE.Group(), v = mStd(0x8a7f68), s = mStd(0x1e1e1e);
    G.add(mesh(new THREE.BoxGeometry(2.2, 0.9, 4.6), v, 0, 0.95, 0)); G.add(mesh(new THREE.BoxGeometry(2.0, 0.75, 2.2), v, 0, 1.75, -0.2)); G.add(mesh(new THREE.BoxGeometry(1.9, 0.5, 0.06), mStd(0x14202a, 0.2, 0.5), 0, 1.75, 0.92));
    [[-1, 1.5], [1, 1.5], [-1, -1.5], [1, -1.5]].forEach(([x, z]) => { const r = mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.35, 12), s, x, 0.45, z); r.rotation.z = PI / 2; G.add(r); });
    { const mg = mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.3, 6), s, 0, 2.5, -0.4); mg.rotation.x = PI / 2.3; G.add(mg); } return G;
  }
  function prepFOB(S) {
    chiudi(); seme = 8812;
    const sc = I().scene; if (!sc) return null; const T = texture();
    WF = { S, sc, oggetti: [], fumo: particelle(sc, 700, false, T.fumo), fuoco: particelle(sc, 600, true, T.luce), t: 0, esposizione: 0, espMax: 0 };
    const add = (o, p, yaw, dy) => { sc.add(o); WF.oggetti.push(o); if (p) { o.position.set(p.x, suolo(p.x, p.z) + (dy || 0), p.z); o.rotation.y = yaw || 0; } return o; };
    const yP = Math.atan2(asseP.x, asseP.z);   // rotazione per avere +Z lungo la pista
    // due MC-130J bloccati fuori dal bordo della pista, nel terreno molle
    WF.mc = [[-330, 44, 0.32], [-180, -46, -0.22]].map(([u, w, r]) => { const m = mc130J(); add(m, sulPista(u, w), yP + r, m.userData.terra - 0.75); m.rotation.z = r * 0.12; return m; });
    // tre aerei di rimpiazzo sulla pista, motori accesi, in fila per il decollo verso est
    WF.rp = [-520, -380, -240].map((u, i) => { const m = rimpiazzo(); add(m, sulPista(u, i % 2 ? 9 : -9), yP, m.userData.terra); return m; });
    // quattro MH-6 della 160a SOAR sul lato nord, che verranno distrutti
    WF.mh = [80, 110, 140, 170].map(u => { const m = mh6(); add(m, sulPista(u, 52), yP + PI / 2); return m; });
    // mezzi, perimetro di operatori, luci chimiche IR lungo i bordi
    WF.mezzi = [[-420, -60, 0.4], [-100, 70, 2.0], [260, -62, -0.6], [430, 58, 1.2], [-600, 20, 1.5]].map(([u, w, r]) => add(fuoristrada(), sulPista(u, w), yP + r));
    WF.operatori = [];
    for (let i = 0; i < 16; i++) { const a = i / 16 * PI * 2, u = Math.cos(a) * 720, w = Math.sin(a) * 140; const o = persona({ camo: true, giubbotto: 0x3f3d30, casco: 0x4d4b3c, fucile: true, nvg: true, zaino: 0x4a4637 }); add(o, sulPista(u, w), yP + a + PI / 2); posa(o, "ginocchio"); WF.operatori.push(o); }
    WF.ir = []; for (let u = -600; u <= 600; u += 60) [-31, 31].forEach(w => { const l = luceSprite(0x9dff9d, 3.2, 0.9); const p = sulPista(u, w); l.position.set(p.x, suolo(p.x, p.z) + 0.4, p.z); l.visible = false; add(l); WF.ir.push(l); });
    WF.lzLuci = [[-8, -8], [8, -8], [8, 8], [-8, 8]].map(([a, b]) => { const l = luceSprite(0x9dff9d, 2.6, 0.95); l.position.set(LF.lz.x + a, suolo(LF.lz.x + a, LF.lz.z + b) + 0.4, LF.lz.z + b); l.visible = false; add(l); return l; });
    WF.squadra = add(new THREE.Group(), LF.manpads); [0, 1, 2].forEach(i => { const q = persona({ tuta: 0x4d5340, giubbotto: 0x3a3e30, casco: 0x3f4434, fucile: true }); q.position.set(i * 3, 0, i * 2); posa(q, i ? "ginocchio" : "punta"); WF.squadra.add(q); });
    piazzaElicottero(S, LF.partenza, Math.atan2(LF.ip.x - LF.partenza.x, -(LF.ip.z - LF.partenza.z)) / D2R, 90, 30); S.pausa = true;
    return WF;
  }
  function riallineaFOB() { if (!WF) return; if (WF.tappeto && (WF.tapT = (WF.tapT || 0) + 1) % 3 === 1) WF.tappeto.userData.quote(); WF.oggetti.forEach(o => { if (o.isSprite || o === WF.tappeto) return; const y = suolo(o.position.x, o.position.z); if (o.userData.terra != null) o.position.y = y + o.userData.terra - (WF.mc.includes(o) ? 0.75 : 0); else o.position.y = y; }); }
  function infoFOB(S) {
    const P = S.pl, d = a => Math.hypot(P.pos.x - a.x, P.pos.z - a.z), brg = a => (Math.atan2(a.x - P.pos.x, -(a.z - P.pos.z)) / D2R + 360) % 360, agl = P.pos.y - suolo(P.pos.x, P.pos.z), v = Math.hypot(P.vel.x, P.vel.z);
    return { dLZ: d(LF.lz), brgLZ: brg(LF.lz), dIP: d(LF.ip), brgIP: brg(LF.ip), dMan: d(LF.manpads), agl, aglFt: agl * FT, kt: v * KT, esposto: d(LF.manpads) < R_MAN_F && agl > AGL_MANPADS, inMan: d(LF.manpads) < R_MAN_F, esposizione: WF ? WF.esposizione : 0, aTerra: !!P.aTerra, nvg: !!(S.nvg && S.cam === "cockpit") };
  }
  function aggiornaFOB(dt, S) {
    if (!WF || WF.S !== S) return; WF.t += dt; allinea(LF.lz); if ((WF.allT = (WF.allT || 0) - dt) <= 0) { WF.allT = 2; riallineaFOB(); }
    const k = infoFOB(S);
    if (k.esposto) { WF.esposizione += dt; if ((WF.avvisoT = (WF.avvisoT || 0) - dt) <= 0) { WF.avvisoT = 3; messaggio("MANPADS IN VISTA · scendi sotto 300 ft", 2.5, "warn"); } } else WF.esposizione = Math.max(0, WF.esposizione - dt * 0.5);
    WF.espMax = Math.max(WF.espMax, WF.esposizione);
    WF.rp.forEach(m => m.userData.eliche.forEach(e => { e.rotation.z += dt * 30; e.userData.disco.material.opacity = 0.25; }));
    const vis = k.nvg; WF.ir.forEach(l => l.visible = vis); WF.lzLuci.forEach(l => l.visible = vis && (WF.t % 1.2) < 0.9);
    // navigatore semplice: punto attivo, distanza, rotta, minaccia
    const ov = I().overlay; if (!ov) return;
    if (!WF.nav) { WF.nav = document.createElement("canvas"); WF.nav.id = "zg-gps"; Object.assign(WF.nav.style, { position: "absolute", left: "12px", top: "70px", pointerEvents: "none", zIndex: 30, width: "140px", height: "150px" }); WF.nav.width = 280; WF.nav.height = 300; ov.appendChild(WF.nav); }
    if ((WF.uiT = (WF.uiT || 0) - 1) > 0) return; WF.uiT = 3;
    const g = WF.nav.getContext("2d"), P = S.pl, f = V3(0, 0, 1).applyQuaternion(P.Q), hdg = (Math.atan2(f.x, -f.z) / D2R + 360) % 360, att = WF.fase >= 2 ? { n: "LZ", p: LF.lz, d: k.dLZ, b: k.brgLZ } : { n: "IP", p: LF.ip, d: k.dIP, b: k.brgIP };
    g.clearRect(0, 0, 280, 300); g.fillStyle = "rgba(6,10,8,0.82)"; g.strokeStyle = "rgba(120,255,150,0.55)"; g.lineWidth = 2; g.fillRect(1, 1, 278, 298); g.strokeRect(1, 1, 278, 298);
    g.font = "700 22px Consolas, monospace"; g.fillStyle = "#5dff8f"; g.textAlign = "left"; g.fillText("GPS · FOB", 14, 29);
    const cx = 140, cy = 140, sc2 = 1 / 50, rot = -hdg * D2R, scr = p => { const dx = (p.x - P.pos.x) * sc2, dz = (p.z - P.pos.z) * sc2; return { x: cx + dx * Math.cos(rot) - dz * Math.sin(rot), y: cy + dx * Math.sin(rot) + dz * Math.cos(rot) }; };
    g.save(); g.beginPath(); g.rect(8, 40, 264, 200); g.clip();
    const sm = scr(LF.manpads); g.fillStyle = "rgba(255,60,60,0.15)"; g.strokeStyle = "rgba(255,90,90,0.9)"; g.beginPath(); g.arc(sm.x, sm.y, R_MAN_F * sc2, 0, PI * 2); g.fill(); g.stroke();
    const a1 = scr(sulPista(-610, 0)), a2 = scr(sulPista(610, 0)); g.strokeStyle = "#cfd8dc"; g.lineWidth = 4; g.beginPath(); g.moveTo(a1.x, a1.y); g.lineTo(a2.x, a2.y); g.stroke();
    const a = scr(att.p); g.strokeStyle = "#ff6ae6"; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(a.x, a.y); g.stroke(); g.fillStyle = "#64e1ff"; g.beginPath(); g.arc(a.x, a.y, 5, 0, PI * 2); g.fill();
    g.restore(); g.fillStyle = "#e9fff0"; g.beginPath(); g.moveTo(cx, cy - 9); g.lineTo(cx + 6, cy + 7); g.lineTo(cx, cy + 3); g.lineTo(cx - 6, cy + 7); g.fill();
    g.font = "700 20px Consolas, monospace"; g.fillStyle = "#ff8af0"; g.fillText(att.n, 14, 268); g.textAlign = "right"; g.fillStyle = "#e9fff0"; g.fillText(km(att.d), 266, 268);
    g.textAlign = "left"; g.font = "600 15px Consolas, monospace"; g.fillStyle = "#cfe9d6"; g.fillText(`RTA ${String(Math.round(att.b)).padStart(3, "0")}°  ${Math.round(k.aglFt)} ft  ${Math.round(k.kt)} kt`, 14, 290);
  }
  function chiudiFOBMondo() { disallinea(); if (!WF) return; const sc = WF.sc; WF.oggetti.forEach(o => sc.remove(o)); WF.fumo.dispose(); WF.fuoco.dispose(); if (WF.nav) WF.nav.remove(); WF = null; }
  /* ---- filmato finale nel mondo 3D della base: trasferimento, partenze, distruzione di MC-130J e MH-6 ---- */
  function filmatoPartenza(S, fine) {
    if (!WF) { fine && fine(); return; }
    const P = S.pl, H0 = P.pos.clone(), Q0 = P.Q.clone(), sc = WF.sc;
    const porta = V3(LF.lz.x, 0, LF.lz.z); const rp0 = WF.rp[0], dest = rp0.position.clone().addScaledVector(asseP, -9).addScaledVector(latP, -6);
    const barella = [0, 1, 2].map(i => { const o = persona({ camo: true, giubbotto: 0x3f3d30, casco: 0x4d4b3c, nvg: true, zaino: 0x4a4637 }); sc.add(o); WF.oggetti.push(o); return o; });
    const wso = persona({ tuta: 0x5d6447, giubbotto: 0x3b4230, casco: 0x8b8d84 }); sc.add(wso); WF.oggetti.push(wso);
    const corsa = WF.operatori.map(o => ({ o, a: o.position.clone() }));
    const yP = Math.atan2(asseP.x, asseP.z); let esploso = false;
    const tDec = [11, 14.5, 18];
    cinema(32, (t, dt, cam) => {
      etichetta(t < 22 ? "05 APR 2026 · 05:10 · BASE AVANZATA" : "05 APR 2026 · 05:40");
      WF.rp.forEach(m => m.userData.eliche.forEach(e => { e.rotation.z += dt * 34; e.userData.disco.material.opacity = 0.25; }));
      P.pos.copy(H0); P.Q.copy(Q0); if (P.obj) { P.obj.visible = true; P.obj.position.copy(H0); P.obj.quaternion.copy(Q0); }
      // il WSO in barella fino al primo aereo
      const k = ss(1, 8, t), b = porta.clone().lerp(dest, k); b.y = suolo(b.x, b.z);
      barella.forEach((o, i) => { const p = b.clone().addScaledVector(latP, (i - 1) * 0.9).addScaledVector(asseP, i === 1 ? 1.2 : -0.6); p.y = suolo(p.x, p.z); o.position.copy(p); o.visible = k < 0.98 && t > 0.8; o.rotation.y = Math.atan2(dest.x - porta.x, dest.z - porta.z); posa(o, "cammina", t * 1.2); });
      wso.position.copy(b).add(V3(0, 0.15, 0)); wso.visible = k < 0.98 && t > 0.8; wso.rotation.set(0, Math.atan2(dest.x - porta.x, dest.z - porta.z), 0); posa(wso, "sostenuto", t);
      // gli operatori del perimetro corrono agli aerei dopo il primo decollo
      corsa.forEach((c, i) => { const kk = ss(9 + (i % 8) * 0.3, 15 + (i % 8) * 0.3, t); const d2 = WF.rp[1 + (i % 2)].position.clone().addScaledVector(latP, -5); const p = c.a.clone().lerp(d2, kk); p.y = suolo(p.x, p.z); c.o.position.copy(p); c.o.visible = kk < 0.98; if (kk > 0 && kk < 1) { c.o.rotation.y = Math.atan2(d2.x - c.a.x, d2.z - c.a.z); posa(c.o, "corsa", t * 1.6 + i); } });
      // decolli verso est-sud-est lungo la pista
      WF.rp.forEach((m, i) => { const tp = tDec[i]; if (t < tp) return; const u = t - tp, s = 5 * u * u, h = Math.max(0, u - 4.2) ** 2 * 2.6; const p0 = m.userData.p0 || (m.userData.p0 = m.position.clone()); m.position.copy(p0).addScaledVector(asseP, s); m.position.y = p0.y + h; m.rotation.set(-Math.min(0.2, Math.max(0, u - 4.2) * 0.07), yP, 0, "YXZ"); });
      // dopo l'ultima partenza: attacco aereo amico sugli MC-130J e sugli MH-6 rimasti
      if (!esploso && t >= 24) { esploso = true; [...WF.mc, ...WF.mh].forEach(m => { const mp = m.position.clone(); for (let i = 0; i < 70; i++) WF.fuoco.emetti({ pos: mp.clone().add(V3(rnd(-8, 8), rnd(0, 5), rnd(-8, 8))), vel: V3(rnd(-25, 25), rnd(8, 45), rnd(-25, 25)), vita: rnd(0.6, 1.5), s0: rnd(8, 18), s1: 4, a0: 1, col: 0xfff0b0, col1: 0xff4010, drag: 1 }); }); lampo(0.8); }
      if (esploso) { lampo(Math.max(0, 0.8 - (t - 24) * 1.6)); [...WF.mc, ...WF.mh].forEach(m => { const mp = m.position; if (Math.random() < 0.6) { WF.fuoco.emetti({ pos: mp.clone().add(V3(rnd(-8, 8), rnd(0, 4), rnd(-8, 8))), vel: V3(0, rnd(4, 9), 0), vita: rnd(0.5, 1.1), s0: rnd(5, 9), s1: 2, a0: 0.9, col: 0xffc060, col1: 0xff3a08, drag: 0.4 }); WF.fumo.emetti({ pos: mp.clone().add(V3(rnd(-6, 6), 5, rnd(-6, 6))), vel: V3(rnd(-2, 2), rnd(10, 16), rnd(-2, 2)), vita: rnd(10, 14), s0: 10, s1: 45, a0: 0.45, col: 0x1e1c1a, col1: 0x56524e, drag: 0.2, su: 0.2 }); } }); }
      WF.fumo.aggiorna(dt); WF.fuoco.aggiorna(dt);
      // inquadrature e didascalie
      const L2 = (u, w, y) => { const p = sulPista(u, w); return V3(p.x, suolo(p.x, p.z) + y, p.z); };
      if (t < 8) { didascalia(t < 4 ? "Base avanzata, 160 km a nord" : "DUDE 44 Bravo passa al primo aereo", t < 4 ? "Una pista agricola abbandonata presa e difesa dalle forze speciali" : "Il WSO viene imbarcato; il personale aspetta il suo turno"); visore(t < 4);
        inquadra(cam, L2(-560, -95, 9), V3(b.x, b.y + 1, b.z), 44, t < 0.05 ? 0 : 1.5, dt); dissolvenza(Math.max(0, 1 - t * 1.5)); }
      else if (t < 12) { didascalia("Due MC-130J bloccati", "Impantanati a lato della pista: per circa due ore il personale resta senza un'uscita"); visore(false); inquadra(cam, L2(-300, 95, 6), V3(WF.mc[0].position.x, WF.mc[0].position.y + 2, WF.mc[0].position.z), 40, 2, dt); }
      else if (t < 21) { didascalia("Arrivano gli aerei di rimpiazzo", "Imbarcano il WSO e circa cento operatori e partono uno dopo l'altro"); const r = WF.rp[Math.min(2, Math.floor((t - 12) / 3.3))].position; inquadra(cam, L2(-100, -80, 5), V3(r.x, r.y + 3, r.z), 46, 1.6, dt); }
      else if (t < 27) { didascalia("Niente resta al nemico", "Dopo l'ultima partenza un attacco aereo amico distrugge gli MC-130J e gli MH-6"); inquadra(cam, L2(-650, 260, 70), L2(-100, 0, 8), 36, 1, dt); }
      else { didascalia("DUDE 44 Bravo è a casa", "Recuperato vivo dopo quasi due giorni: nessun soldato americano ucciso nell'operazione"); const r = WF.rp[2].position; inquadra(cam, L2(200, -260, 60), V3(r.x, r.y, r.z), 44, 1, dt); dissolvenza(ss(31, 32, t)); }
    }, () => { fine && fine(); });
  }
  function convertiScenarioFOB(sc) {
    Object.assign(sc.tempo || (sc.tempo = {}), { inizio: "04:40", fine: "06:00" });
    Object.assign(sc.mappa, { centro: FOB_C.slice(), zoom: 11, bounds: [[31.95, 51.60], [32.50, 52.20]], bullseye: { nome: "SHAHREZA", lat: 32.03, lon: 51.87 } });
    sc.mappa5 = { id: "fob-mahyar", nome: "Isfahan · pista agricola vicino a Mahyar", centro: FOB_C.slice(), lato_m: 50000, area_km2: 2500, quotaInizioM: 2000 };
    sc.meteo = Object.assign({}, sc.meteo, { vento_da_gradi: 290, vento_kt: 6, umidita: 20, descrizione: "Fine della notte, cielo sereno, vento debole (condizioni illustrative)" });
    sc.basi = [{ id: "FOB", nome: "Pista agricola abbandonata", lato: "BLUE", lat: FOB_C[0], lon: FOB_C[1], nazione: "—", pista_ft: 4000, pista_hdg: 110 }];
    (sc.formazioni || []).forEach(f => { f.base = "FOB"; f.tipo = "UH60"; });
    sc.target = []; sc.zagros = "fob"; return sc;
  }
  const LEZIONE_FOB = {
    id: FOB_ID, modulo: "soccorso", titolo: "DUDE 44 · La base avanzata", sotto: "Seguito della S2: porta il WSO alla pista abbandonata dove lo aspettano gli aerei, poi la partenza (aprile 2026)", durata: "8 min", aereo: "UH60", partenza: "volo", ora: "notte",
    target: [{ id: "ZG-FOB", nome: "Base avanzata", lat: FOB_C[0], lon: FOB_C[1], zagros: "fob", categoria: "base", descrizione: "Pista agricola abbandonata" }],
    obiettivo: "Portare JOLLY 11 con il WSO fino alla pista agricola abbandonata vicino a Mahyar, evitando la squadra con il MANPADS a sud-est, e atterrare accanto agli aerei di rimpiazzo, sulle luci chimiche IR.",
    teoria: [
      ["La base avanzata", "Secondo la fonte, gli Stati Uniti usarono come base avanzata una pista agricola abbandonata, lunga circa 1.200 m e larga 60, una ventina di chilometri a nord di Shahreza, nella provincia di Isfahan, protetta dalle forze speciali. Due MC-130J rimasero bloccati: per circa due ore il personale fu senza un'uscita, finché aerei di rimpiazzo portarono via il WSO e circa cento operatori. Gli MC-130J e quattro elicotteri leggeri furono distrutti per non lasciarli al nemico. (Fonte: Wikipedia.)"],
      ["Ricostruzione", "La pista, il rilievo e le immagini satellitari sono quelli reali; aerei, mezzi, persone e luci sono ricostruiti. Il tipo degli aerei di rimpiazzo è incerto nelle fonti (C-295W o Dash 8): qui un bimotore generico."],
      ["Una decisione che costa", "Distruggere i propri aerei è una scelta dolorosa ma chiara: il materiale si ricompra, le persone no, e la tecnologia non deve finire in mano all'avversario."]
    ],
    numeri: [["Pista", "circa 1.220 x 60 m, orientata 110/290°"], ["MANPADS (rosso)", "squadra a sud-est della pista: entro 3 km sopra 300 ft sei esposto, 12 s e ti ingaggiano"], ["LZ", "a sud-ovest della testata ovest, quattro luci chimiche IR: hovering sotto 15 m e 10 kt per 3 s, o posati entro 40 m"]],
    setup(S, c) { c.t0 = S.t; if (!VOLO._int) return; prepFOB(S); WF.fase = 0; c.pronto = true;
      const attesa = () => { if (VOLO.stato !== S) return; if (terrenoPronto() || S.t - c.t0 > 0 || (c.att = (c.att || 0) + 1) > 30) { riallineaFOB(); piazzaElicottero(S, LF.partenza, Math.atan2(LF.ip.x - LF.partenza.x, -(LF.ip.z - LF.partenza.z)) / D2R, 90, 30); S.pausa = false; c.via = true; messaggio("JOLLY 11: «DUDE 44 Bravo a bordo, base avanzata in vista tra dieci minuti»", 4); } else setTimeout(attesa, 300); };
      setTimeout(attesa, 600); },
    sempre(s, c, dt) { if (!WF) return; aggiornaFOB(dt, VOLO.stato); c.espMax = Math.max(c.espMax || 0, WF.esposizione); },
    chiusura() { chiudiFOBMondo(); finisci(true); },
    fasi: [
      { titolo: "Verso la base avanzata", testo: "Vola sul punto IP del GPS, a sud-ovest della pista. Il cerchio rosso a sud-est è una squadra con il MANPADS: stagli lontano o resta sotto 300 ft.",
        inizio: () => { if (WF) WF.fase = 1; },
        check: (s, c) => { const k = infoFOB(VOLO.stato); return { ok: !!c.via && k.dIP < 1200, dati: [D("IP (GPS)", fmt(k.dIP / 1000, 1) + " km", k.dIP < 1200, "< 1,2"), D("Quota", fmt(k.aglFt) + " ft", !k.esposto, k.inMan ? "< 300" : ""), D("Esposizione", fmt(k.esposizione, 1) + " s", k.esposizione < 6, "< 12")], msg: k.esposto ? "In vista del MANPADS: giù sotto 300 ft!" : "Tieni la linea viola." }; } },
      { titolo: "Atterraggio alla base", testo: "Con il visore cerca le quattro luci chimiche IR a sud-ovest della testata ovest, accanto agli aerei di rimpiazzo. Hovering sotto 15 m e 10 kt per 3 secondi, o posati entro 40 m.", tenere: 3,
        inizio: () => { if (WF) WF.fase = 2; },
        check: (s, c) => { const k = infoFOB(VOLO.stato), posato = k.aTerra && k.dLZ < 45, hover = k.dLZ < 40 && k.agl < 15 && k.kt < 10; return { ok: posato || hover, dati: [D("Distanza LZ", fmt(k.dLZ) + " m", k.dLZ < 40, "< 40"), D("Altezza", fmt(k.agl) + " m", k.agl < 15 || k.aTerra, "< 15"), D("Velocità", fmt(k.kt) + " kt", k.kt < 10, "< 10")], msg: k.kt > 10 ? "Rallenta sopra le luci." : k.agl > 15 ? "Scendi piano." : "Così: tieni fermo." }; } },
      { titolo: "La partenza", testo: "Il WSO passa al primo aereo; gli aerei di rimpiazzo partono, poi gli MC-130J e gli MH-6 vengono distrutti.",
        inizio: (s, c) => { if (WF) WF.fase = 3; filmatoPartenza(VOLO.stato, () => { c.film = true; }); },
        check: (s, c) => ({ ok: !!c.film, dati: [D("Partenza", c.film ? "conclusa" : "in corso", !!c.film, "")], msg: "" }) }
    ],
    fallimento: (s, c) => { if (!WF) return null; const k = infoFOB(VOLO.stato); if (k.esposizione >= 12) return "Ingaggiato dal MANPADS a sud-est della pista: stai basso o giralo attorno."; return null; },
    debrief: c => [c.espMax > 0.5 ? `Esposizione massima al MANPADS: ${fmt(c.espMax, 1)} s.` : "Mai esposto al MANPADS.", "Da discutere: perché distruggere aerei integri? Quali informazioni servono per decidere, e quando è troppo tardi per aspettare?"],
    stelle: (c, R) => 1 + ((c.espMax || 0) < 4 ? 1 : 0) + (R.durata < 480 ? 1 : 0)
  };

  /* ======================= scenario: mappa dei monti Zagros, notte ======================= */
  function convertiScenario(sc) {
    Object.assign(sc.tempo || (sc.tempo = {}), { inizio: "02:40", fine: "04:00" });
    Object.assign(sc.mappa, { centro: CENTRO.slice(), zoom: 10, bounds: [[30.30, 51.00], [31.30, 52.20]], bullseye: { nome: "YASUJ", lat: 30.668, lon: 51.588 } });
    sc.mappa5 = { id: "zagros", nome: "Monti Zagros · Kohgiluyeh e Boyer-Ahmad", centro: CENTRO.slice(), lato_m: 110000, area_km2: 12100, quotaInizioM: 3200 };
    sc.meteo = Object.assign({}, sc.meteo, { vento_da_gradi: 300, vento_kt: 8, umidita: 25, descrizione: "Notte serena, luna calante, vento debole da nord-ovest sulle creste (condizioni illustrative)" });
    sc.basi = [{ id: "FOB", nome: "Base avanzata (pista agricola)", lato: "BLUE", lat: 32.2213, lon: 51.9014, nazione: "—", pista_ft: 3900, pista_hdg: 0 }];
    (sc.formazioni || []).forEach(f => { f.base = "FOB"; f.tipo = "UH60"; });
    sc.target = []; sc.zagros = true; return sc;
  }
  function agganciaScenario() {
    if (typeof APP === "undefined" || !APP.ricostruisci || APP.ricostruisci._zagros) return;
    const orig = APP.ricostruisci;
    const nuova = function () { try { const tz = APP.sc && APP.sc.target && APP.sc.target.find(t => t && t.zagros); if (tz) (tz.zagros === "fob" ? convertiScenarioFOB : convertiScenario)(APP.sc); } catch (e) { console.warn("ZAGROS scenario", e); } return orig.apply(this, arguments); };
    nuova._zagros = true; APP.ricostruisci = nuova;
  }

  /* ======================= lezione dell'Accademia ======================= */
  const fmt = (n, d) => Number(n).toLocaleString("it-IT", { maximumFractionDigits: d || 0, minimumFractionDigits: d || 0 });
  const D = (n, v, ok, obj) => ({ n, v, ok, obj });
  const LEZIONE = {
    id: ID, modulo: "soccorso", titolo: "DUDE 44 · CSAR sui monti Zagros", sotto: "Di notte, con il visore: ritrovare e recuperare il WSO di un F-15E abbattuto (ispirata all'aprile 2026)", durata: "15 min", aereo: "UH60", partenza: "volo", ora: "notte",
    target: [{ id: "ZG-WSO", nome: "DUDE 44 Bravo", lat: 30.7371, lon: 51.5753, zagros: true, categoria: "personale isolato", descrizione: "WSO dell'F-15E nascosto sulla cresta" }],
    obiettivo: "Entrare di notte nella valle a bassa quota, evitare il MANPADS e le armi leggere, trovare il WSO con i brevi impulsi del suo radiofaro e lo strobo infrarosso, atterrare sulla cresta a 2.200 m, recuperarlo con i Pararescue e uscire lungo la valle verso ovest.",
    teoria: [
      ["La storia vera", "Il 3 aprile 2026 un F-15E Strike Eagle statunitense (nominativo DUDE 44) viene abbattuto sull'Iran da un missile spalleggiabile. Pilota e WSO si eiettano. Il pilota viene recuperato dopo circa sette ore; il WSO, ferito, resta isolato per quasi due giorni sui monti Zagros. Lo cercano i soccorritori, le forze iraniane e nomadi armati attirati da una taglia. Viene recuperato vivo nella notte del 5 aprile, al termine di un'operazione con oltre un centinaio di aerei. (Fonte: Wikipedia, «2026 United States F-15E rescue operation in Iran».)"],
      ["Combat Search and Rescue", "Il CSAR è il recupero di personale isolato in territorio ostile. Si combina un elicottero di soccorso con a bordo i Pararescue (PJ), una scorta armata (i «SANDY», per tradizione A-10), caccia che tengono lo spazio aereo, aerei cisterna e sensori che localizzano il superstite. Il comandante della missione decide quanto rischio accettare: il valore di una persona contro aerei ed equipaggi."],
      ["Farsi trovare solo dagli amici", "Il WSO usa il radiofaro pochissimo: ogni trasmissione potrebbe portare il nemico da lui. Così i soccorritori ricevono la sua posizione solo a brevi impulsi e con un errore: si vola verso un cerchio che si stringe a ogni impulso. Da vicino conta il visore notturno: lo strobo e le luci chimiche infrarosse si vedono solo con l'NVG."],
      ["È davvero lui?", "Il nemico può usare un radiofaro catturato per tendere una trappola. Per questo la posizione va confermata e la persona autenticata con le domande personali preparate prima della missione (scheda ISOPREP)."],
      ["Montagna e notte", "A 2.200 m l'aria è rarefatta: il rotore rende meno e la riserva di potenza è piccola. L'avvicinamento va fatto lento e controvento; in hovering serve più collettivo. Di notte si vola con il visore, bassi nelle valli, lontano dalle luci dei campi."],
      ["Lo scontro alla LZ", "Nella realtà i commando spararono per tenere lontane le forze iraniane senza un vero scontro, e due elicotteri furono colpiti da armi leggere. Qui la difesa della LZ è una drammatizzazione: serve a provare il fuoco di soppressione, il coordinamento con i PJ e l'uso della scorta armata. Nessuna vittima è mostrata in modo cruento."],
      ["Leadership", "«Nessuno resta indietro»: è un valore, ma anche una scelta che costa. Nell'operazione reale furono distrutti due MC-130J e alcuni elicotteri pur di non lasciarli al nemico; nessun soldato americano morì. Chi comanda deve decidere con informazioni incomplete, sotto pressione, sapendo che anche non decidere è una decisione."]
    ],
    numeri: [["Superstite", "DUDE 44 Bravo (WSO), cresta a ~2.195 m (7.200 ft), 4,8 km a nord-ovest del relitto"], ["Radiofaro", "impulsi ogni 25–35 s, incertezza 1.200 → 520 → 220 → 90 m"], ["MANPADS (rosso)", "posto di osservazione a nord della valle e squadra al relitto: entro 3 km sopra 300 ft sei esposto; 12 s e ti ingaggiano"], ["Armi leggere (arancio)", "campi nomadi e convoglio: entro 900 m sotto 800 ft ti colpiscono; 8 colpi e la missione fallisce"], ["Visore notturno", "tasto N (in cabina, tasto V): strobo e luci chimiche IR si vedono solo così"], ["LZ", "spiazzo sulla cresta a 160 m dal WSO: hovering sotto 15 m e 10 kt per 3 s, oppure posati entro 60 m"], ["Mitragliatrici di porta", "tasto 1 armi in sicura/libere (i mitraglieri ingaggiano nel loro settore, 30°-150° per lato); tasto 2 prendi la destra, poi la sinistra, poi la restituisci (frecce o trascina per mirare, Spazio o FUOCO); Q/E ruota l'elicottero a terra"], ["SANDY (A-10)", "tasto 3: un passaggio con il cannone sul gruppo più vicino alla LZ, tre passaggi, uno ogni 35 s"], ["Difesa della LZ", "circa 75 s; fallisce con 8 colpi subiti o con 3 ostili a meno di 40 m dalla LZ"]],
    setup(S, c) { c.t0 = S.t; if (!VOLO._int) return; prepara(S); W.fase = 0; c.pronto = true; setTimeout(() => { if (VOLO.stato === S) filmatoAbbattimento(S, () => { c.film1 = true; }); }, 600); },
    sempre(s, c, dt) { if (!W) return; aggiorna(dt, s.S || VOLO.stato); const k = info(VOLO.stato); c.espMax = Math.max(c.espMax || 0, k.esposizione); c.colpi = W.colpi; c.nvgUsato = c.nvgUsato || k.nvg; },
    chiusura() { chiudi(); },
    fasi: [
      { titolo: "DUDE 44 abbattuto", testo: "Il WSO di un F-15E è isolato sui monti Zagros da quasi due giorni. È notte: JOLLY 11 entra per recuperarlo.",
        check: (s, c) => ({ ok: !!c.film1, dati: [D("Filmato", c.film1 ? "concluso" : "in corso", !!c.film1, "")], msg: "Guarda il filmato, poi si parte." }) },
      { titolo: "Ingresso notturno", testo: "Vola sul punto IP del GPS, basso nelle valli. Segui la valle tratteggiata: il cerchio rosso a nord è un posto di osservazione con MANPADS, i cerchi arancio sono campi di nomadi armati. Accendi il visore (N, in cabina).",
        inizio: () => { if (W) W.fase = 1; },
        check: (s, c) => { const k = info(VOLO.stato); return { ok: k.dIP < 1200, dati: [D("IP (GPS)", fmt(k.dIP / 1000, 1) + " km", k.dIP < 1200, "< 1,2"), D("Quota", fmt(k.aglFt) + " ft", !k.esposto, k.inManpads ? "< 300" : ""), D("Esposizione", fmt(k.esposizione, 1) + " s", k.esposizione < 6, "< 12"), D("NVG", k.nvg ? "acceso" : "spento", k.nvg, "")],
          msg: k.esposto ? "Sei in vista del MANPADS: giù sotto 300 ft!" : !k.nvg ? "In cabina (V) accendi il visore notturno (N)." : "Tieni la linea viola del navigatore." }; } },
      { titolo: "Impulsi del radiofaro", testo: "DUDE 44 Bravo trasmette pochissimo: a ogni impulso il GPS mostra un cerchio di incertezza più stretto. Vola dentro il cerchio arancio. Sulla strada da Yasuj sale un convoglio: SANDY 1 lo fermerà.",
        inizio: () => { if (W) W.fase = 2; },
        check: (s, c) => { const k = info(VOLO.stato), e = stima(), P = VOLO.stato.pl.pos, de = e ? Math.hypot(e.x - P.x, e.z - P.z) : 1e9; return { ok: !!e && e.r <= 520 && de < 900, dati: [D("Stima WSO", e ? `±${e.r} m` : "attesa impulso", !!e, ""), D("Distanza", e ? fmt(de) + " m" : "—", de < 900, "< 900"), D("Colpi", String(k.colpi), k.colpi === 0, "< 4"), D("Quota", fmt(k.aglFt) + " ft", !k.esposto, "")],
          msg: !e ? "Attendi il primo impulso del radiofaro." : k.sottoTiro ? "Sotto il fuoco di armi leggere: allontanati o sali!" : "Vola verso il rombo arancio: il prossimo impulso stringerà il cerchio." }; } },
      { titolo: "Ricerca con il visore", testo: "Con l'NVG cerca lo strobo infrarosso che lampeggia sulla cresta e le quattro luci chimiche della LZ. Arriva lento, controvento.",
        inizio: () => { if (W) W.fase = 3; },
        check: (s, c) => { const k = info(VOLO.stato); return { ok: k.dWSO < 600 && k.nvg, dati: [D("Strobo IR", k.dWSO < 3000 ? (k.nvg ? "visibile" : "serve l'NVG") : "fuori portata", k.nvg && k.dWSO < 3000, ""), D("Distanza", fmt(k.dWSO) + " m", k.dWSO < 600, "< 600"), D("Velocità", fmt(k.kt) + " kt", k.kt < 90, "")],
          msg: !k.nvg ? "Lo strobo è infrarosso: in cabina (V) accendi l'NVG (N)." : "Cerca il lampeggio sulla cresta." }; } },
      { titolo: "Atterraggio in quota", testo: "LZ sulla cresta a 2.200 m: aria rarefatta, poca potenza di riserva. Hovering sotto 15 m e 10 kt per 3 secondi tra le luci chimiche, oppure posati entro 60 m.", tenere: 3,
        inizio: () => { if (W) W.fase = 4; },
        check: (s, c) => { const k = info(VOLO.stato), posato = k.aTerra && k.dLZ < 70, hover = k.dLZ < 60 && k.agl < 15 && k.kt < 10; return { ok: posato || hover, dati: [D("Distanza LZ", fmt(k.dLZ) + " m", k.dLZ < 60, "< 60"), D("Altezza", fmt(k.agl) + " m", k.agl < 15 || k.aTerra, "< 15"), D("Velocità", fmt(k.kt) + " kt", k.kt < 10, "< 10")],
          msg: k.kt > 10 ? "Ciclico indietro: rallenta sopra le luci." : k.agl > 15 ? "Collettivo giù piano: a questa quota la potenza è poca." : "Così: tieni fermo l'elicottero." }; } },
      { titolo: "Difendi la LZ", testo: "I PJ scendono e l'elicottero si alza in hovering di copertura, 70 ft sopra la LZ: due PJ salgono dal WSO, due tengono il perimetro. Da tre direzioni arrivano Pasdaran e nomadi armati, poi un pick-up con mitragliatrice pesante. Tasto 1 armi libere, tasto 2 prendi la mitragliatrice, tasto 3 chiama SANDY, Q/E ruoti l'elicottero. Resisti finché i PJ tornano con il WSO.",
        inizio: (s, c) => { if (!W) return; W.fase = 5; const S = VOLO.stato, P = S.pl, L = LUOGHI, f = V3(0, 0, 1).applyQuaternion(P.Q).setY(0).normalize(), gh = (P.A && P.A.gearHeight) || 1.85;
          const pos = V3(P.pos.x, suolo(P.pos.x, P.pos.z) + 22, P.pos.z), Q = VOLO._acc.assetto(Math.atan2(f.x, -f.z), 0, 0), brg = q => Math.atan2(q.x - L.lz.x, -(q.z - L.lz.z)) / D2R;   // hovering di copertura: da terra i bordi della cresta coprono la vista
          preparaPJ(); W.F.difesa = { t: 0, pos, Q, salita: P.pos.clone(), dir: [brg(lungoStrada(LSTRADA - 400)), brg(CAMPI[0]), brg(CAMPI[2])] };
          messaggio("PJ a terra · JOLLY 11 in hovering di copertura · contatto! Ostili da sud e da ovest", 4, "warn"); },
        check: (s, c) => { const F = W && W.F, d = F && F.difesa, vicini = F ? F.nemici.filter(q => q.vivo && Math.hypot(q.pos.x - LUOGHI.lz.x, q.pos.z - LUOGHI.lz.z) < 120).length : 0, vivi = F ? F.nemici.filter(q => q.vivo).length : 0;
          return { ok: !!d && d.t >= 76, dati: [D("PJ e WSO", d ? (d.t < 20 ? "salgono" : d.t < 55 ? "cure" : d.t < 76 ? "rientrano" : "a bordo") : "—", !!d && d.t >= 76, ""), D("Ostili", String(vivi), vivi < 6, ""), D("Entro 120 m", String(vicini), vicini === 0, "0"), D("Abbattuti", String(F ? F.uccisi : 0), true, ""), D("Colpi subiti", String(W ? W.colpi : 0), (W ? W.colpi : 0) < 4, "< 8")],
            msg: !F ? "" : !F.libere && !F.manuale ? "Tasto 1: armi libere, i mitraglieri ingaggiano da soli." : vicini ? "Ostili vicini alla LZ: tasto 3 per SANDY, o prendi la mitragliatrice (2)." : "Q/E ruota l'elicottero per mettere i nemici nel settore delle armi." }; } },
      { titolo: "Imbarco sotto il fuoco", testo: "Il perimetro rientra, il WSO è a bordo: stacco dalla cresta coperti dai mitraglieri e da SANDY.",
        inizio: (s, c) => { if (W) W.fase = 6; filmatoImbarco(VOLO.stato, () => { c.film2 = true; }); },
        check: (s, c) => ({ ok: !!c.film2, dati: [D("Imbarco", c.film2 ? "decollati" : "in corso", !!c.film2, "")], msg: "" }) },
      { titolo: "Esfiltrazione", testo: "Il GPS passa al punto «USCITA», 12 km a ovest lungo la stessa valle: bassi, lontano dai campi e dal MANPADS.",
        inizio: () => { if (W) W.fase = 7; },
        check: (s, c) => { const k = info(VOLO.stato); return { ok: k.dUscita < 1500, dati: [D("Uscita (GPS)", fmt(k.dUscita / 1000, 1) + " km", k.dUscita < 1500, "< 1,5"), D("Quota", fmt(k.aglFt) + " ft", !k.esposto, k.inManpads ? "< 300" : ""), D("Colpi", String(k.colpi), k.colpi < 4, "< 4")],
          msg: k.esposto ? "Esposto al MANPADS: giù!" : "Verso ovest lungo la valle, bassi e veloci." }; } },
    ],
    fallimento: (s, c) => { if (!W) return null; const k = info(VOLO.stato);
      if (k.esposizione >= 12) return "Ingaggiato da un MANPADS: nelle valli si vola bassi, nascosti dal rilievo.";
      if (W.colpi >= 8) return "Troppi colpi: l'elicottero è danneggiato e deve rientrare. Usa i mitraglieri e SANDY, e stai lontano dai campi.";
      if (W.F && W.F.difesa && W.F.nemici.filter(q => q.vivo && Math.hypot(q.pos.x - LUOGHI.lz.x, q.pos.z - LUOGHI.lz.z) < 40).length >= 3) return "La LZ è stata raggiunta dagli ostili: il fuoco di soppressione deve tenerli lontani.";
      return Math.hypot(VOLO.stato.pl.pos.x - LUOGHI.wso.x, VOLO.stato.pl.pos.z - LUOGHI.wso.z) > 30000 ? "Troppo lontano dall'area del superstite: il recupero è fallito." : null; },
    debrief: c => [
      c.espMax > 0.5 ? `Esposizione massima al MANPADS: ${fmt(c.espMax, 1)} s.` : "Mai esposto al MANPADS: ingresso mascherato dal rilievo.",
      c.colpi ? `Colpi subiti: ${c.colpi}. Nella realtà due elicotteri furono colpiti da armi leggere, con feriti a bordo.` : "Nessun colpo subito.",
      W && W.F ? `Ostili fermati alla LZ: ${W.F.uccisi}; passaggi di SANDY usati: ${3 - W.F.sandyResidui}.` : "",
      "La storia continua nella lezione S3: la base avanzata.",
      "Da discutere: quanto rischio è giusto accettare per una persona? Chi decide, con quali informazioni, e come si comunica una scelta che costa aerei e mette in pericolo altri equipaggi?"],
    stelle: (c, R) => 1 + ((c.espMax || 0) < 4 ? 1 : 0) + ((c.colpi || 0) < 3 ? 1 : 0)
  };
  /* ======================= catalogo missioni: le missioni di Personnel Recovery dell'Accademia ======================= */
  // Le missioni pilotate dell'Accademia (STOS sul Grappa, DUDE 44 sugli Zagros) compaiono anche nel catalogo missioni:
  // «Pilota» avvia il volo guidato, «Briefing» apre la scheda della lezione. missioni.js non viene toccato.
  const VOCI = [
    { id: "PR1", lez: "S1", codice: "SOS GRAPPA", titolo: "SOS Grappa \u00b7 Personnel Recovery con gli STOS", tipo: "Personnel Recovery \u00b7 volo guidato in elicottero", difficolta: 2, durata: "10 min",
      focus: "Localizzare senza farsi localizzare, entrare nascosti dal rilievo, lavorare in squadra a terra: report, locate, support, recover, reintegrate.",
      descrizione: "Un Typhoon viene abbattuto da un MANPADS sul Monte Grappa. Con l'UH-60 e il team STOS Pararescue dell'Aeronautica Militare si vola a bassa quota sulle coordinate GPS del pilota, si atterra nella zona indicata e lo si riporta indietro.",
      domande: ["Perché il pilota tiene spento il radiofaro?", "Cosa cambia volare sotto 300 ft nella zona della minaccia?", "Chi decide quando l'elicottero può atterrare?"] },
    { id: "PR2", lez: "S2", codice: "DUDE 44", titolo: "DUDE 44 \u00b7 CSAR sui monti Zagros", tipo: "Combat Search and Rescue \u00b7 notte, volo guidato", difficolta: 4, durata: "15 min",
      focus: "Decidere con informazioni incomplete e sotto pressione: quanto rischio accettare per una persona, come verificare che non sia una trappola, come spiegare una scelta che costa.",
      descrizione: "Ispirata al recupero del WSO di un F-15E abbattuto in Iran nell'aprile 2026. Di notte, con il visore, si cerca il superstite grazie ai brevi impulsi del suo radiofaro, si evitano MANPADS e armi leggere, si atterra su una cresta a 2.200 m e si chiude alla base avanzata con gli MC-130J.",
      domande: ["Quanto rischio è giusto accettare per recuperare una persona?", "Come si decide quando la posizione del superstite è incerta?", "Chi decide quando usare il fuoco, e con quali regole?"] },
    { id: "PR3", lez: "S3", codice: "DUDE 44 · FOB", titolo: "DUDE 44 \u00b7 La base avanzata", tipo: "Esfiltrazione \u00b7 notte, volo guidato", difficolta: 3, durata: "8 min",
      focus: "Chiudere una missione quando le cose vanno storte: aerei bloccati, tempo che scade, scelte che costano materiale per salvare persone.",
      descrizione: "Seguito di DUDE 44: con il WSO a bordo si raggiunge la pista agricola abbandonata vicino a Mahyar, ricostruita sul rilievo e sulle immagini reali, con gli MC-130J bloccati e gli aerei di rimpiazzo. Atterraggio di notte sulle luci IR, poi la partenza e la distruzione degli aerei rimasti.",
      domande: ["Perché distruggere aerei integri?", "Quando smettere di aspettare una soluzione migliore?", "Chi deve sapere che cosa, e quando, mentre la base è senza uscita?"] }
  ];
  function registraCatalogo() {
    if (typeof MISSIONI === "undefined" || !MISSIONI.ELENCO || typeof ACCADEMIA === "undefined") return false;
    VOCI.forEach(v => { if (MISSIONI.ELENCO.some(m => m.id === v.id)) return; const L = ACCADEMIA.LEZIONI.find(l => l.id === v.lez); if (!L) return;
      MISSIONI.ELENCO.push(Object.assign({ accademia: v.lez, applica: sc => { sc.obiettivi = (L.fasi || []).slice(1).map(f => ({ primario: true, testo: f.titolo })); return sc; } }, v)); });
    if (MISSIONI.apriCatalogo && !MISSIONI.apriCatalogo._zagros) {
      const orig = MISSIONI.apriCatalogo, nuova = function () { const r = orig.apply(this, arguments); try { decoraCatalogo(); } catch (e) { console.warn("ZAGROS catalogo", e); } return r; };
      nuova._zagros = true; MISSIONI.apriCatalogo = nuova;
    }
    return true;
  }
  function decoraCatalogo() {
    const modal = document.getElementById("missioni"); if (!modal) return;
    MISSIONI.ELENCO.filter(m => m.accademia).forEach(m => {
      const g = modal.querySelector(`[data-gioca="${m.id}"]`), d = modal.querySelector(`[data-demo="${m.id}"]`);
      if (g) { g.textContent = "\u25b6 Pilota"; g.title = "Volo guidato dell'Accademia"; g.onclick = e => { e.stopPropagation(); MISSIONI.chiudiCatalogo(); ACCADEMIA.avvia(m.accademia); }; }
      if (d) { d.textContent = "\ud83d\udcd6 Briefing"; d.title = "Scheda della lezione"; d.onclick = e => { e.stopPropagation(); MISSIONI.chiudiCatalogo(); try { ACCADEMIA.apri(); } catch (x) {} ACCADEMIA.briefing(m.accademia); }; }
    });
  }
  function registra() {
    if (typeof ACCADEMIA === "undefined" || !ACCADEMIA.LEZIONI) return false;
    agganciaScenario();
    if (!ACCADEMIA.LEZIONI.some(l => l.id === ID)) ACCADEMIA.LEZIONI.push(LEZIONE);
    if (!ACCADEMIA.LEZIONI.some(l => l.id === FOB_ID)) ACCADEMIA.LEZIONI.push(LEZIONE_FOB);
    registraCatalogo();
    return true;
  }
  if (!registra()) { let n = 0; const prova = setInterval(() => { if (registra() || ++n > 60) clearInterval(prova); }, 250); }
  return { suolo, allinea, LUOGHI, CAMPI, STRADA, ROTTA, VOCI, FOB: { LF, PISTA, sulPista: (u, w) => sulPista(u, w), get mondo() { return WF; } }, prepara, aggiorna, info, stima, filmatoAbbattimento, filmatoRecupero, filmatoFOB, chiudi, registra, convertiScenario,
    get mondo() { return W; }, get inFilmato() { return !!C || !!FOB; }, get tFilmato() { return C ? C.t : null; }, get fob() { return FOB; } };
})();
