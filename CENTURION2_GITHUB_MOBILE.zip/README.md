# CENTURION2 — versione browser mobile

Questa è l'app web statica, aggiornata per Chrome Android e Safari iPhone. Non è un APK.

## Avvio

Pubblica **tutti i file estratti** nella stessa cartella su un sito HTTPS (GitHub Pages, Netlify o hosting statico).
Apri l'indirizzo del sito direttamente nel browser dello smartphone. Scegli TRAINER, BLUE o RED.

La pagina non necessita di server di elaborazione. Le funzioni che usano API locali (/api/) restano non disponibili
su hosting statici; gli scenari e i salvataggi usano localStorage e download/importazione.
Le mappe di base online, le risorse 3D remote e il meteo remoto richiedono rete.

## Ottimizzazioni smartphone (15 novembre 2026)

- Barra comandi compatta e fasi scorribili orizzontalmente; niente scorrimento orizzontale dell'intera pagina.
- Mappa ampliata; livelli nascosti fino al tocco di "Livelli".
- Pannelli missione e log a scomparsa con pulsanti Chiudi e sfondo di chiusura.
- Schermata iniziale scorrevole anche sugli schermi bassi e orientamento orizzontale.
- Altezza dinamica (dvh) e rispetto delle aree di sicurezza dei telefoni con notch.
- Campi con caratteri abbastanza grandi per evitare zoom automatico su iOS, tabelle a scorrimento, modali adattive.
- Versione cache PWA aggiornata per ricaricare CSS/JS nuovi.

## Verifica

Verificate in Chromium con emulazione touch le larghezze 320, 360, 390 e 844 pixel: inizializzazione,
selezione ruolo, livelli mappa, pannelli, fasi, avanzamento orologio, play/pausa e assenza di scorrimento orizzontale.
Non è stato eseguito un test su dispositivo fisico iOS/Android né su un URL HTTPS pubblicato.

## Github Pages

Crea un repository e carica questi file mantenendo le cartelle `.github/` e `site/`. In Settings → Pages scegli **GitHub Actions**. URL previsto (non ancora pubblicato): `https://stefanopasqual.github.io/centurion2/`.

## Creazione repository centurion2

1. Da https://github.com/new?name=centurion2 crea un repository **pubblico** chiamato `centurion2`.
2. Estrai l'archivio `CENTURION2_GITHUB_MOBILE.zip` sul computer.
3. In una shell con Git configurato:

   ```sh
   cd CENTURION2_GITHUB_MOBILE
   git init -b main
   git add .
   git commit -m "Publish CENTURION2 mobile web app"
   git remote add origin https://github.com/stefanopasqual/centurion2.git
   git push -u origin main
   ```

4. In **Settings > Pages > Build and deployment** seleziona **GitHub Actions**.
5. Controlla la scheda Actions e apri https://stefanopasqual.github.io/centurion2/ una volta completato il deploy.

**Nota**: non caricare il file ZIP come singolo file nel repository: GitHub Pages non lo estrae.
Non sono inclusi backend e API locali, perciò le funzionalità `/api/` non funzionano su Pages.
